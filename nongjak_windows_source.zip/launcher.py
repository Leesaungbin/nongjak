from __future__ import annotations

import json
import os
import platform
import subprocess
import sys
import traceback
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent
LOG_DIR = ROOT / "logs"
LOG_DIR.mkdir(exist_ok=True)
LOG_FILE = LOG_DIR / "launcher.log"
ERROR_FILE = LOG_DIR / "startup_error.log"


def log(message: str) -> None:
    line = f"[{datetime.now().isoformat(timespec='seconds')}] {message}"
    print(line)
    with LOG_FILE.open("a", encoding="utf-8") as file:
        file.write(line + "\n")


def fail(message: str, error: BaseException | None = None) -> int:
    log("ERROR: " + message)
    with ERROR_FILE.open("a", encoding="utf-8") as file:
        file.write("\n" + "=" * 72 + "\n")
        file.write(datetime.now().isoformat(timespec="seconds") + "\n")
        file.write(message + "\n")
        if error:
            file.write("".join(traceback.format_exception(type(error), error, error.__traceback__)))
    try:
        import tkinter as tk
        from tkinter import messagebox
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror(
            "Nongjak AI startup error",
            message + "\n\nLog file:\n" + str(ERROR_FILE),
        )
        root.destroy()
    except Exception:
        pass
    return 1


def preflight() -> tuple[bool, list[dict[str, object]]]:
    checks: list[dict[str, object]] = []

    def add(name: str, ok: bool, detail: str) -> None:
        checks.append({"name": name, "ok": ok, "detail": detail})
        log(f"{name}: {'OK' if ok else 'FAIL'} - {detail}")

    add("Python", sys.version_info >= (3, 10), platform.python_version())

    try:
        import tkinter as tk
        root = tk.Tk()
        root.withdraw()
        root.update_idletasks()
        root.destroy()
        add("Tkinter GUI", True, "window creation OK")
    except Exception as error:
        add("Tkinter GUI", False, str(error))

    try:
        from PIL import Image
        add("Pillow", True, getattr(Image, "__version__", "installed"))
    except Exception as error:
        add("Pillow", False, str(error))

    try:
        import py_compile
        for rel in ["app.py", "nongjak/core.py", "nongjak/ui.py"]:
            py_compile.compile(str(ROOT / rel), doraise=True)
        add("Python files", True, "syntax OK")
    except Exception as error:
        add("Python files", False, str(error))

    try:
        from nongjak.core import APP_VERSION, Project, Cut
        add("Core import", True, f"version {APP_VERSION}")
    except Exception as error:
        add("Core import", False, str(error))

    try:
        from nongjak.ui import App
        add("UI import", True, "App class loaded")
    except Exception as error:
        add("UI import", False, str(error))

    report = {
        "ready": all(bool(item["ok"]) for item in checks),
        "python": platform.python_version(),
        "platform": platform.platform(),
        "checks": checks,
    }
    (ROOT / "startup_check.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return bool(report["ready"]), checks


def main() -> int:
    os.chdir(ROOT)
    log("Launcher started")
    ready, checks = preflight()
    if "--check-only" in sys.argv:
        return 0 if ready else 1
    if not ready:
        failed = [str(item["name"]) + ": " + str(item["detail"]) for item in checks if not item["ok"]]
        return fail("Startup check failed:\n" + "\n".join(failed))

    try:
        from app import main as app_main
        log("Starting GUI")
        result = int(app_main())
        log(f"GUI closed with code {result}")
        return result
    except Exception as error:
        return fail("The program could not start.", error)


if __name__ == "__main__":
    raise SystemExit(main())
