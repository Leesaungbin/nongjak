@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Nongjak AI Diagnostic

set "PY_CMD="
py -3 -c "import sys; assert sys.version_info >= (3,10)" >nul 2>&1
if not errorlevel 1 set "PY_CMD=py -3"
if not defined PY_CMD (
  python -c "import sys; assert sys.version_info >= (3,10)" >nul 2>&1
  if not errorlevel 1 set "PY_CMD=python"
)
if not defined PY_CMD (
  echo Python not found.
  pause
  exit /b 1
)

%PY_CMD% "%~dp0launcher.py" --check-only
echo.
echo Diagnostic report: startup_check.json
echo Launcher log: logs\launcher.log
pause
