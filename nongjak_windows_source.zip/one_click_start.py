from __future__ import annotations

import importlib.util
import json
import os
import platform
import subprocess
import sys
import traceback
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent
LOG_DIR = ROOT / "logs"
LOG_DIR.mkdir(parents=True, exist_ok=True)
BOOT_LOG = LOG_DIR / "one_click_start.log"
ERROR_LOG = LOG_DIR / "startup_error.log"


def log(message: str) -> None:
    line = f"[{datetime.now().isoformat(timespec='seconds')}] {message}"
    print(line, flush=True)
    with BOOT_LOG.open("a", encoding="utf-8") as file:
        file.write(line + "\n")


def install_requirement(requirement: str) -> None:
    log(f"Installing requirement: {requirement}")
    subprocess.check_call([
        sys.executable, "-m", "pip", "install", "--user", requirement
    ], cwd=ROOT)


def ensure_runtime() -> None:
    if sys.version_info < (3, 10):
        raise RuntimeError(f"Python 3.10 or newer is required. Current: {platform.python_version()}")

    try:
        import tkinter as tk
        root = tk.Tk()
        root.withdraw()
        root.update_idletasks()
        root.destroy()
    except Exception as error:
        raise RuntimeError(
            "Tkinter GUI is unavailable. Reinstall Python with Tcl/Tk support. " + str(error)
        ) from error

    if importlib.util.find_spec("PIL") is None:
        install_requirement("Pillow>=10.0.0")

    from PIL import Image  # noqa: F401


def show_error(message: str) -> None:
    with ERROR_LOG.open("a", encoding="utf-8") as file:
        file.write("\n" + "=" * 72 + "\n")
        file.write(datetime.now().isoformat(timespec="seconds") + "\n")
        file.write(message + "\n")
        file.write(traceback.format_exc())
    try:
        import tkinter as tk
        from tkinter import messagebox
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror(
            "농작 AI 실행 오류",
            message + "\n\n오류 기록:\n" + str(ERROR_LOG),
        )
        root.destroy()
    except Exception:
        pass


def main() -> int:
    os.chdir(ROOT)
    log("One-click startup began")
    try:
        ensure_runtime()
        log("Runtime check completed")
        from app import main as app_main
        log("Opening Nongjak AI window")
        code = int(app_main())
        log(f"Nongjak AI closed with code {code}")
        return code
    except Exception as error:
        log(f"Startup failed: {error}")
        show_error(str(error))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
