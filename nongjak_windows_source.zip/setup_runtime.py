from __future__ import annotations

import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def run(args: list[str]) -> None:
    print(">", " ".join(args))
    subprocess.check_call(args, cwd=ROOT)

if sys.version_info < (3, 10):
    raise SystemExit("Python 3.10 or newer is required.")

try:
    import pip  # noqa: F401
except Exception:
    run([sys.executable, "-m", "ensurepip", "--upgrade"])

run([sys.executable, "-m", "pip", "install", "--user", "--upgrade", "pip"])
run([sys.executable, "-m", "pip", "install", "--user", "-r", str(ROOT / "requirements.txt")])
run([sys.executable, str(ROOT / "launcher.py"), "--check-only"])
print("SETUP_OK")
