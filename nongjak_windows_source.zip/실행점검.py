from __future__ import annotations

import importlib.util
import json
import platform
import py_compile
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
checks = []


def add(name: str, ok: bool, detail: str) -> None:
    checks.append({"name": name, "ok": bool(ok), "detail": detail})
    print(f"[{'정상' if ok else '오류'}] {name}: {detail}")


add("Python 버전", sys.version_info >= (3, 10), platform.python_version())
add("Tkinter", importlib.util.find_spec("tkinter") is not None, "설치됨" if importlib.util.find_spec("tkinter") else "없음")
add("Pillow", importlib.util.find_spec("PIL") is not None, "설치됨" if importlib.util.find_spec("PIL") else "없음")

for relative in ["app.py", "nongjak/core.py", "nongjak/ui.py"]:
    path = ROOT / relative
    try:
        py_compile.compile(str(path), doraise=True)
        add(f"문법 검사 {relative}", True, "정상")
    except Exception as error:
        add(f"문법 검사 {relative}", False, str(error))

try:
    from nongjak.core import APP_VERSION, Project, Cut, project_design_quality
    project = Project(
        fields={"product": "점검 상품", "category": "식품"},
        images=[],
        cuts=[Cut("소개", "프로그램 점검용 문구", 0)],
    )
    quality = project_design_quality(project)
    add("핵심 엔진 불러오기", True, f"v{APP_VERSION}, 품질점수 {quality['score']}")
except Exception as error:
    add("핵심 엔진 불러오기", False, str(error))

report = {
    "python": platform.python_version(),
    "platform": platform.platform(),
    "ready": all(item["ok"] for item in checks),
    "checks": checks,
}
(ROOT / "실행점검결과.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
print("\n점검 결과:", "실행 준비 완료" if report["ready"] else "오류 항목을 확인하세요")
raise SystemExit(0 if report["ready"] else 1)
