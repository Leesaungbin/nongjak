﻿@echo off
cd /d "%~dp0"
call "DIAGNOSE_STARTUP.cmd"
