from __future__ import annotations

import base64
import copy
import json
import os
import re
import urllib.error
import urllib.request
import hashlib
import re
import csv
import shutil
import sys
import zipfile
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

from PIL import Image, ImageColor, ImageDraw, ImageFont, ImageOps, ImageStat

APP_VERSION = "6.3.1"
CONFIG_DIR = Path.home() / ".nongjak_ai"
AI_CONFIG_FILE = CONFIG_DIR / "ai_config.json"

STYLE_PRESETS = {
    "프리미엄": {"bg": (246, 242, 232), "panel": (255, 255, 255), "accent": (86, 66, 44), "text": (35, 35, 35)},
    "홈쇼핑": {"bg": (255, 244, 222), "panel": (255, 255, 255), "accent": (194, 55, 35), "text": (30, 25, 20)},
    "심플": {"bg": (248, 248, 248), "panel": (255, 255, 255), "accent": (55, 55, 55), "text": (24, 24, 24)},
    "감성": {"bg": (242, 234, 226), "panel": (252, 248, 243), "accent": (119, 82, 68), "text": (45, 38, 35)},
}

CUT_LIBRARY = [
    ("메인 배너", "{product}\n{feature1}"),
    ("핵심 장점", "{feature1}\n{feature2}"),
    ("상품 소개", "{product}의 특징을 한눈에 확인하세요."),
    ("산지·원산지", "{origin}에서 정성껏 준비했습니다."),
    ("품질 포인트", "사진으로 확인하는 신선함과 품질"),
    ("활용 방법", "다양하게 즐기기 좋은 {product}"),
    ("포장 안내", "상품 특성에 맞춰 꼼꼼하게 포장합니다."),
    ("배송 안내", "{shipping}으로 안전하게 발송합니다."),
    ("보관 안내", "상품 수령 후 알맞은 방법으로 보관해 주세요."),
    ("구매 유도", "지금 {product}을 만나보세요."),
]

DEFAULTS = {
    "product": "상품",
    "category": "식품",
    "origin": "국내 산지",
    "feature1": "신선한 품질",
    "feature2": "꼼꼼한 선별",
    "shipping": "택배",
}


@dataclass
class Cut:
    title: str
    body: str
    photo_index: int = 0
    approved: bool = False
    image_scale: float = 1.0
    image_offset_x: int = 0
    image_offset_y: int = 0
    title_size: int = 33
    body_size: int = 39
    text_align: str = "center"
    body_offset_y: int = 0
    layout_variant: str = "기본 카드형"
    story_stage: str = "상품 소개"
    review_status: str = "검수 전"
    review_note: str = ""
    reviewed_at: str = ""


@dataclass
class Project:
    fields: dict[str, str]
    images: list[str]
    cuts: list[Cut]
    style: str = "프리미엄"
    layout: str = "균형형"
    custom_background: str = ""
    ai_analysis: dict[str, Any] | None = None

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["app_version"] = APP_VERSION
        data["saved_at"] = datetime.now().isoformat(timespec="seconds")
        return data

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Project":
        return cls(
            fields=data.get("fields", {}),
            images=data.get("images", []),
            cuts=[Cut(**cut) for cut in data.get("cuts", [])],
            style=data.get("style", "프리미엄"),
            layout=data.get("layout", "균형형"),
            custom_background=data.get("custom_background", ""),
            ai_analysis=data.get("ai_analysis"),
        )


@dataclass
class AIConfig:
    mode: str = "offline"
    endpoint: str = ""
    api_key: str = ""
    model: str = ""
    timeout_seconds: int = 45

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "AIConfig":
        return cls(
            mode=data.get("mode", "offline"),
            endpoint=data.get("endpoint", ""),
            api_key=data.get("api_key", ""),
            model=data.get("model", ""),
            timeout_seconds=int(data.get("timeout_seconds", 45)),
        )


def save_ai_config(config: AIConfig, path: str | Path = AI_CONFIG_FILE) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(config.to_dict(), ensure_ascii=False, indent=2), encoding="utf-8")


def load_ai_config(path: str | Path = AI_CONFIG_FILE) -> AIConfig:
    path = Path(path)
    if not path.exists():
        return AIConfig()
    try:
        return AIConfig.from_dict(json.loads(path.read_text(encoding="utf-8")))
    except Exception:
        return AIConfig()


def save_project(project: Project, path: str | Path) -> None:
    Path(path).write_text(json.dumps(project.to_dict(), ensure_ascii=False, indent=2), encoding="utf-8")


def load_project(path: str | Path) -> Project:
    return Project.from_dict(json.loads(Path(path).read_text(encoding="utf-8")))


def duplicate_cut(cut: Cut) -> Cut:
    return copy.deepcopy(cut)


def build_cuts(fields: dict[str, str], count: int) -> list[Cut]:
    context = {key: fields.get(key, "").strip() or default for key, default in DEFAULTS.items()}
    count = max(1, min(int(count), len(CUT_LIBRARY)))
    return [Cut(title=title, body=template.format(**context)) for title, template in CUT_LIBRARY[:count]]


def _font(size: int, bold: bool = False):
    candidates = [
        "C:/Windows/Fonts/malgunbd.ttf" if bold else "C:/Windows/Fonts/malgun.ttf",
        "C:/Windows/Fonts/NanumGothicBold.ttf" if bold else "C:/Windows/Fonts/NanumGothic.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    ]
    for path in candidates:
        if os.path.exists(path):
            return ImageFont.truetype(path, size)
    return ImageFont.load_default()


def _wrap(draw: ImageDraw.ImageDraw, text: str, font, width: int) -> str:
    lines: list[str] = []
    for paragraph in text.splitlines() or [""]:
        line = ""
        for char in paragraph:
            candidate = line + char
            if draw.textbbox((0, 0), candidate, font=font)[2] <= width:
                line = candidate
            else:
                if line:
                    lines.append(line)
                line = char
        lines.append(line)
    return "\n".join(lines)


def _parse_hex(value: str, fallback: tuple[int, int, int]) -> tuple[int, int, int]:
    try:
        value = value.lstrip("#")
        if len(value) != 6:
            return fallback
        return tuple(int(value[index:index + 2], 16) for index in (0, 2, 4))
    except Exception:
        return fallback



CUT_LAYOUT_VARIANTS = ["기본 카드형", "풀블리드형", "좌우 분할형", "상단 카피형", "포인트 카드형"]


def recommend_cut_layout(title: str, index: int) -> str:
    text = (title or "").strip()
    if index == 0 or any(key in text for key in ["메인", "구매 유도"]):
        return "풀블리드형"
    if any(key in text for key in ["장점", "특징", "품질", "당도", "맛"]):
        return "좌우 분할형"
    if any(key in text for key in ["산지", "원산지", "배송", "포장", "보관"]):
        return "상단 카피형"
    if any(key in text for key in ["활용", "선별", "손질"]):
        return "포인트 카드형"
    return "기본 카드형"


def auto_assign_cut_layouts(project: Project) -> list[str]:
    assigned = []
    for index, cut in enumerate(project.cuts):
        cut.layout_variant = recommend_cut_layout(cut.title, index)
        assigned.append(cut.layout_variant)
    return assigned

def render_cut(
    image_path: str | Path,
    index: int,
    cut: Cut,
    style: str,
    layout: str,
    custom_background: str = "",
) -> Image.Image:
    width, height = 900, 1200
    preset = STYLE_PRESETS.get(style, STYLE_PRESETS["프리미엄"])
    background = _parse_hex(custom_background, preset["bg"]) if custom_background else preset["bg"]
    canvas = Image.new("RGB", (width, height), background)
    draw = ImageDraw.Draw(canvas)
    source = Image.open(image_path).convert("RGB")
    variant = cut.layout_variant if cut.layout_variant in CUT_LAYOUT_VARIANTS else "기본 카드형"
    scale = max(0.5, min(float(cut.image_scale), 2.5))
    title_font = _font(max(18, min(int(cut.title_size), 60)), True)
    body_font = _font(max(18, min(int(cut.body_size), 70)), True)
    align = cut.text_align if cut.text_align in {"left", "center", "right"} else "center"

    if variant == "풀블리드형":
        photo = ImageOps.fit(source, (width, height), method=Image.Resampling.LANCZOS)
        if scale != 1.0:
            enlarged = photo.resize((int(width * scale), int(height * scale)), Image.Resampling.LANCZOS)
            left = max(0, (enlarged.width-width)//2 - int(cut.image_offset_x))
            top = max(0, (enlarged.height-height)//2 - int(cut.image_offset_y))
            photo = enlarged.crop((left, top, left+width, top+height))
        canvas.paste(photo, (0, 0))
        overlay = Image.new("RGBA", (width, height), (0, 0, 0, 0))
        od = ImageDraw.Draw(overlay)
        od.rectangle((0, 650, width, height), fill=(0, 0, 0, 125))
        canvas = Image.alpha_composite(canvas.convert("RGBA"), overlay).convert("RGB")
        draw = ImageDraw.Draw(canvas)
        draw.multiline_text((450, 790), cut.title, font=title_font, fill="white", anchor="mm", align="center", spacing=10)
        draw.multiline_text((450, 950 + int(cut.body_offset_y)), _wrap(draw, cut.body, body_font, 720), font=body_font, fill="white", anchor="mm", align="center", spacing=14)

    elif variant == "좌우 분할형":
        draw.rounded_rectangle((45, 45, 855, 1155), radius=34, fill=preset["panel"])
        photo = ImageOps.fit(source, (430, 1010), method=Image.Resampling.LANCZOS)
        canvas.paste(photo, (55 + int(cut.image_offset_x), 95 + int(cut.image_offset_y)))
        draw.text((650, 245), cut.title, font=title_font, fill=preset["accent"], anchor="mm")
        draw.multiline_text((650, 610 + int(cut.body_offset_y)), _wrap(draw, cut.body, body_font, 300), font=body_font, fill=preset["text"], anchor="mm", align="center", spacing=16)
        draw.rounded_rectangle((535, 910, 765, 980), radius=20, fill=preset["accent"])
        draw.text((650, 945), "POINT", font=_font(24, True), fill="white", anchor="mm")

    elif variant == "상단 카피형":
        draw.rounded_rectangle((50, 45, 850, 340), radius=32, fill=preset["accent"])
        draw.text((450, 125), cut.title, font=title_font, fill="white", anchor="mm")
        draw.multiline_text((450, 235 + int(cut.body_offset_y)), _wrap(draw, cut.body, body_font, 700), font=body_font, fill="white", anchor="mm", align="center", spacing=12)
        photo = ImageOps.fit(source, (800, 760), method=Image.Resampling.LANCZOS)
        canvas.paste(photo, (50 + int(cut.image_offset_x), 390 + int(cut.image_offset_y)))

    elif variant == "포인트 카드형":
        photo = ImageOps.fit(source, (800, 720), method=Image.Resampling.LANCZOS)
        canvas.paste(photo, (50 + int(cut.image_offset_x), 55 + int(cut.image_offset_y)))
        draw.rounded_rectangle((90, 690, 810, 1110), radius=38, fill=preset["panel"], outline=preset["accent"], width=4)
        draw.text((450, 785), cut.title, font=title_font, fill=preset["accent"], anchor="mm")
        draw.multiline_text((450, 930 + int(cut.body_offset_y)), _wrap(draw, cut.body, body_font, 620), font=body_font, fill=preset["text"], anchor="mm", align="center", spacing=14)

    else:
        panel = (55, 135, 845, 825)
        draw.rounded_rectangle(panel, radius=30, fill=preset["panel"])
        if layout == "사진 크게":
            photo = ImageOps.fit(source, (760, 650), method=Image.Resampling.LANCZOS)
        else:
            photo = source.copy()
            photo.thumbnail((720, 590), Image.Resampling.LANCZOS)
        if scale != 1.0:
            photo = photo.resize((max(1, int(photo.width*scale)), max(1, int(photo.height*scale))), Image.Resampling.LANCZOS)
        px = (width-photo.width)//2 + int(cut.image_offset_x)
        py = panel[1] + ((panel[3]-panel[1])-photo.height)//2 + int(cut.image_offset_y)
        canvas.paste(photo, (px, py))
        draw.rounded_rectangle((55, 38, 845, 115), radius=22, fill=preset["accent"])
        draw.text((450, 77), cut.title, font=title_font, fill="white", anchor="mm")
        anchor = {"left":"lm", "center":"mm", "right":"rm"}[align]
        x_position = {"left":100, "center":450, "right":800}[align]
        draw.multiline_text((x_position, 930 + int(cut.body_offset_y)), _wrap(draw, cut.body, body_font, 760), font=body_font, fill=preset["text"], anchor=anchor, align=align, spacing=14)

    draw.text((450, 1165), f"농작 AI v{APP_VERSION}", font=_font(16), fill=preset["accent"] if variant != "풀블리드형" else "white", anchor="mm")
    return canvas

def image_metrics(path: str | Path) -> dict[str, Any]:
    image = Image.open(path).convert("RGB")
    sample = image.resize((64, 64))
    mean = ImageStat.Stat(sample).mean
    brightness = round(sum(mean) / 3, 1)
    dominant = tuple(round(value) for value in mean)
    return {
        "width": image.width,
        "height": image.height,
        "orientation": "세로" if image.height > image.width else "가로" if image.width > image.height else "정사각형",
        "brightness": brightness,
        "average_rgb": dominant,
    }


def offline_analyze_images(paths: list[str], existing_fields: dict[str, str] | None = None) -> dict[str, Any]:
    existing_fields = existing_fields or {}
    metrics = [image_metrics(path) for path in paths if Path(path).exists()]
    names = " ".join(Path(path).stem for path in paths).lower()

    keyword_map = [
        (["옥수수", "corn"], ("초당옥수수", "농산물")),
        (["무화과", "fig"], ("무화과", "과일")),
        (["양파", "onion"], ("양파", "농산물")),
        (["김", "seaweed"], ("김", "수산가공식품")),
        (["액젓"], ("액젓", "수산가공식품")),
        (["홍어"], ("홍어", "수산물")),
        (["전복"], ("전복", "수산물")),
        (["단호박", "pumpkin"], ("단호박", "농산물")),
    ]

    detected_product = existing_fields.get("product", "").strip()
    detected_category = existing_fields.get("category", "").strip()
    if not detected_product:
        for keywords, result in keyword_map:
            if any(keyword in names for keyword in keywords):
                detected_product, detected_category = result
                break

    average_brightness = round(sum(item["brightness"] for item in metrics) / len(metrics), 1) if metrics else 0
    feature1 = existing_fields.get("feature1", "").strip() or "신선한 품질"
    feature2 = existing_fields.get("feature2", "").strip() or ("밝고 선명한 상품사진" if average_brightness >= 120 else "진한 색감과 선명한 특징")

    product = detected_product or "상품명 확인 필요"
    category = detected_category or "품목 확인 필요"
    origin = existing_fields.get("origin", "").strip() or "원산지 확인 필요"
    shipping = existing_fields.get("shipping", "").strip() or "배송정보 확인 필요"

    return {
        "provider": "offline",
        "confidence": 0.55 if detected_product else 0.25,
        "fields": {
            "product": product,
            "category": category,
            "origin": origin,
            "feature1": feature1,
            "feature2": feature2,
            "shipping": shipping,
        },
        "copy": {
            "recommended_product_name": f"{origin} {product} {feature1}"[:100],
            "main_copy": f"{feature1}, {feature2} — 믿고 선택하는 {product}",
            "search_keywords": [product, f"{origin} {product}", f"{product} 추천", f"{product} 산지직송"],
        },
        "image_summary": {
            "count": len(metrics),
            "average_brightness": average_brightness,
            "metrics": metrics,
        },
        "warnings": ["오프라인 분석 결과는 초안입니다. 상품명·원산지·표시사항을 반드시 확인하세요."],
    }


def _image_to_data_url(path: str | Path, max_size: int = 1200) -> str:
    image = Image.open(path).convert("RGB")
    image.thumbnail((max_size, max_size), Image.Resampling.LANCZOS)
    from io import BytesIO
    buffer = BytesIO()
    image.save(buffer, format="JPEG", quality=85)
    encoded = base64.b64encode(buffer.getvalue()).decode("ascii")
    return "data:image/jpeg;base64," + encoded


def remote_analyze_images(
    paths: list[str],
    fields: dict[str, str],
    config: AIConfig,
) -> dict[str, Any]:
    if not config.endpoint.strip():
        raise ValueError("AI API 주소가 입력되지 않았습니다.")

    payload = {
        "model": config.model,
        "task": "product_detail_analysis",
        "instructions": (
            "상품 사진과 기존 입력정보를 분석해 JSON으로 응답하세요. "
            "반드시 fields(product, category, origin, feature1, feature2, shipping), "
            "copy(recommended_product_name, main_copy, search_keywords), "
            "warnings 배열을 포함하세요. 사진만으로 확인할 수 없는 원산지·인증·중량은 추측하지 마세요."
        ),
        "existing_fields": fields,
        "images": [_image_to_data_url(path) for path in paths[:6]],
    }

    request = urllib.request.Request(
        config.endpoint,
        data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        headers={
            "Content-Type": "application/json",
            **({"Authorization": f"Bearer {config.api_key}"} if config.api_key else {}),
        },
        method="POST",
    )

    try:
        with urllib.request.urlopen(request, timeout=config.timeout_seconds) as response:
            raw = response.read().decode("utf-8")
    except urllib.error.HTTPError as error:
        details = error.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"AI API 오류 {error.code}: {details[:300]}") from error
    except Exception as error:
        raise RuntimeError(f"AI API 연결 실패: {error}") from error

    data = json.loads(raw)
    if "result" in data and isinstance(data["result"], dict):
        data = data["result"]
    if not isinstance(data, dict):
        raise ValueError("AI 응답이 JSON 객체 형식이 아닙니다.")
    data["provider"] = "remote"
    return data


def analyze_product(
    paths: list[str],
    fields: dict[str, str],
    config: AIConfig | None = None,
) -> dict[str, Any]:
    config = config or load_ai_config()
    if config.mode == "remote":
        try:
            result = remote_analyze_images(paths, fields, config)
            result.setdefault("warnings", [])
            return result
        except Exception as error:
            fallback = offline_analyze_images(paths, fields)
            fallback["provider"] = "offline-fallback"
            fallback.setdefault("warnings", []).insert(0, str(error))
            return fallback
    return offline_analyze_images(paths, fields)


def apply_analysis_fields(fields: dict[str, str], analysis: dict[str, Any], overwrite: bool = False) -> dict[str, str]:
    output = dict(fields)
    suggested = analysis.get("fields", {}) if isinstance(analysis, dict) else {}
    for key in DEFAULTS:
        value = str(suggested.get(key, "")).strip()
        if value and (overwrite or not output.get(key, "").strip()):
            output[key] = value
    return output


def validate_project(project: Project) -> list[dict[str, str]]:
    issues: list[dict[str, str]] = []
    for key, label in {
        "product": "상품명",
        "category": "품목",
        "origin": "원산지",
        "feature1": "핵심 특징 1",
        "feature2": "핵심 특징 2",
        "shipping": "배송정보",
    }.items():
        if not project.fields.get(key, "").strip():
            issues.append({"level": "오류", "message": f"{label}이 입력되지 않았습니다."})
    if not project.images:
        issues.append({"level": "오류", "message": "상품 사진이 없습니다."})
    if not project.cuts:
        issues.append({"level": "오류", "message": "상세페이지 컷이 없습니다."})
    elif any(not cut.approved for cut in project.cuts):
        issues.append({"level": "경고", "message": "승인되지 않은 컷이 남아 있습니다."})
    return issues or [{"level": "정상", "message": "필수 항목이 정상입니다."}]


PROJECT_LIBRARY_DIR = CONFIG_DIR / "projects"
RECENT_FILE = CONFIG_DIR / "recent_projects.json"
BACKUP_DIR = CONFIG_DIR / "backups"


def sanitize_name(value: str) -> str:
    forbidden = '<>:"/\\|?*'
    cleaned = "".join("_" if character in forbidden else character for character in value).strip()
    return cleaned or "새_프로젝트"


def project_library_path(project: Project, library_dir: str | Path = PROJECT_LIBRARY_DIR) -> Path:
    library_dir = Path(library_dir)
    product = sanitize_name(project.fields.get("product", "") or "새_프로젝트")
    return library_dir / f"{product}.nongjak.json"


def register_recent_project(path: str | Path, recent_file: str | Path = RECENT_FILE, limit: int = 15) -> None:
    path = str(Path(path).resolve())
    recent_file = Path(recent_file)
    recent_file.parent.mkdir(parents=True, exist_ok=True)
    items = []
    if recent_file.exists():
        try:
            items = json.loads(recent_file.read_text(encoding="utf-8"))
        except Exception:
            items = []
    items = [item for item in items if item.get("path") != path and Path(item.get("path", "")).exists()]
    items.insert(0, {
        "path": path,
        "name": Path(path).stem,
        "updated_at": datetime.now().isoformat(timespec="seconds"),
    })
    recent_file.write_text(json.dumps(items[:limit], ensure_ascii=False, indent=2), encoding="utf-8")


def load_recent_projects(recent_file: str | Path = RECENT_FILE) -> list[dict[str, str]]:
    recent_file = Path(recent_file)
    if not recent_file.exists():
        return []
    try:
        items = json.loads(recent_file.read_text(encoding="utf-8"))
    except Exception:
        return []
    valid = [item for item in items if Path(item.get("path", "")).exists()]
    if valid != items:
        recent_file.write_text(json.dumps(valid, ensure_ascii=False, indent=2), encoding="utf-8")
    return valid


def save_to_library(project: Project, library_dir: str | Path = PROJECT_LIBRARY_DIR, recent_file: str | Path = RECENT_FILE) -> Path:
    library_dir = Path(library_dir)
    library_dir.mkdir(parents=True, exist_ok=True)
    path = project_library_path(project, library_dir)
    if path.exists():
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        path = path.with_name(f"{path.stem}_{timestamp}{path.suffix}")
    save_project(project, path)
    register_recent_project(path, recent_file)
    return path


def list_library_projects(library_dir: str | Path = PROJECT_LIBRARY_DIR) -> list[dict[str, Any]]:
    library_dir = Path(library_dir)
    if not library_dir.exists():
        return []
    results = []
    for path in sorted(library_dir.glob("*.nongjak.json"), key=lambda item: item.stat().st_mtime, reverse=True):
        try:
            project = load_project(path)
            results.append({
                "path": str(path),
                "product": project.fields.get("product", "") or path.stem,
                "category": project.fields.get("category", ""),
                "cuts": len(project.cuts),
                "images": len(project.images),
                "updated_at": datetime.fromtimestamp(path.stat().st_mtime).isoformat(timespec="seconds"),
            })
        except Exception:
            continue
    return results


def search_library(query: str, library_dir: str | Path = PROJECT_LIBRARY_DIR) -> list[dict[str, Any]]:
    query = query.strip().lower()
    projects = list_library_projects(library_dir)
    if not query:
        return projects
    return [
        item for item in projects
        if query in str(item.get("product", "")).lower()
        or query in str(item.get("category", "")).lower()
        or query in Path(item.get("path", "")).name.lower()
    ]


def create_backup(
    project: Project,
    source_path: str | Path | None = None,
    backup_dir: str | Path = BACKUP_DIR,
    keep: int = 20,
) -> Path:
    backup_dir = Path(backup_dir)
    backup_dir.mkdir(parents=True, exist_ok=True)
    product = sanitize_name(project.fields.get("product", "") or "프로젝트")
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    backup_path = backup_dir / f"{product}_{timestamp}.nongjak.json"
    save_project(project, backup_path)

    backups = sorted(backup_dir.glob("*.nongjak.json"), key=lambda path: path.stat().st_mtime, reverse=True)
    for old_path in backups[keep:]:
        old_path.unlink(missing_ok=True)
    return backup_path


def export_all_formats(project: Project, output_folder: str | Path) -> dict[str, Any]:
    if not project.images or not project.cuts:
        raise ValueError("사진과 상세페이지 컷이 필요합니다.")

    output_folder = Path(output_folder)
    output_folder.mkdir(parents=True, exist_ok=True)
    png_folder = output_folder / "PNG"
    png_folder.mkdir(exist_ok=True)
    pages = []

    for index, cut in enumerate(project.cuts):
        if cut.photo_index >= len(project.images):
            raise ValueError(f"{index + 1}번 컷의 사진 연결이 잘못되었습니다.")
        rendered = render_cut(
            project.images[cut.photo_index],
            index,
            cut,
            project.style,
            project.layout,
            project.custom_background,
        )
        png_path = png_folder / f"{index + 1:02d}_{sanitize_name(cut.title)}.png"
        rendered.save(png_path)
        pages.append(rendered)

    product = sanitize_name(project.fields.get("product", "") or "상품")
    pdf_path = output_folder / f"{product}_상세페이지.pdf"
    pages[0].save(pdf_path, save_all=True, append_images=pages[1:])

    project_path = output_folder / f"{product}.nongjak.json"
    save_project(project, project_path)

    summary_path = output_folder / "export_summary.json"
    summary = {
        "app_version": APP_VERSION,
        "product": project.fields.get("product", ""),
        "exported_at": datetime.now().isoformat(timespec="seconds"),
        "png_count": len(pages),
        "pdf": str(pdf_path),
        "project": str(project_path),
        "approved_count": sum(1 for cut in project.cuts if cut.approved),
        "validation": validate_project(project),
    }
    summary_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    return summary


CATEGORY_TEMPLATES = {
    "농산물": {
        "style": "감성",
        "layout": "균형형",
        "cut_titles": ["메인 배너", "산지 소개", "핵심 장점", "신선도", "활용 방법", "포장 안내", "배송 안내", "구매 유도"],
    },
    "과일": {
        "style": "프리미엄",
        "layout": "사진 크게",
        "cut_titles": ["메인 배너", "당도 포인트", "산지 소개", "과육·식감", "선별 과정", "보관 안내", "배송 안내", "구매 유도"],
    },
    "수산물": {
        "style": "홈쇼핑",
        "layout": "사진 크게",
        "cut_titles": ["메인 배너", "신선도", "원산지", "손질 상태", "활용 방법", "포장 안내", "배송 안내", "구매 유도"],
    },
    "수산가공식품": {
        "style": "홈쇼핑",
        "layout": "균형형",
        "cut_titles": ["메인 배너", "제품 특징", "맛 포인트", "원재료·원산지", "활용 방법", "보관 안내", "배송 안내", "구매 유도"],
    },
    "식품": {
        "style": "프리미엄",
        "layout": "균형형",
        "cut_titles": ["메인 배너", "핵심 장점", "제품 소개", "품질 포인트", "활용 방법", "포장 안내", "배송 안내", "구매 유도"],
    },
}


def recommend_template(category: str, image_paths: list[str] | None = None) -> dict[str, Any]:
    category = (category or "").strip()
    template = CATEGORY_TEMPLATES.get(category, CATEGORY_TEMPLATES["식품"]).copy()

    if image_paths:
        portrait = 0
        landscape = 0
        for path in image_paths:
            try:
                with Image.open(path) as image:
                    if image.height > image.width:
                        portrait += 1
                    elif image.width > image.height:
                        landscape += 1
            except Exception:
                continue
        if portrait > landscape:
            template["layout"] = "균형형"
        elif landscape > portrait:
            template["layout"] = "사진 크게"

    template["category"] = category or "식품"
    return template


def apply_category_template(project: Project, overwrite_titles: bool = True) -> dict[str, Any]:
    recommendation = recommend_template(project.fields.get("category", ""), project.images)
    project.style = recommendation["style"]
    project.layout = recommendation["layout"]

    if overwrite_titles and project.cuts:
        titles = recommendation["cut_titles"]
        for index, cut in enumerate(project.cuts):
            if index < len(titles):
                cut.title = titles[index]

    auto_assign_cut_layouts(project)
    return recommendation


def score_project_quality(project: Project) -> dict[str, Any]:
    score = 100
    deductions = []
    issues = validate_project(project)

    for issue in issues:
        level = issue.get("level")
        message = issue.get("message", "")
        if level == "오류":
            score -= 15
            deductions.append({"points": 15, "reason": message})
        elif level == "경고":
            score -= 6
            deductions.append({"points": 6, "reason": message})

    if project.cuts:
        approved_ratio = sum(1 for cut in project.cuts if cut.approved) / len(project.cuts)
        if approved_ratio < 1:
            penalty = round((1 - approved_ratio) * 20)
            score -= penalty
            deductions.append({"points": penalty, "reason": "미승인 컷이 남아 있습니다."})

        text_lengths = [len(cut.body.strip()) for cut in project.cuts]
        if text_lengths and sum(text_lengths) / len(text_lengths) < 12:
            score -= 8
            deductions.append({"points": 8, "reason": "평균 본문 길이가 짧습니다."})

        unique_titles = len(set(cut.title for cut in project.cuts))
        if unique_titles < max(3, len(project.cuts) // 2):
            score -= 7
            deductions.append({"points": 7, "reason": "컷 제목 구성이 단조롭습니다."})

    if project.images:
        low_resolution = 0
        for path in project.images:
            try:
                with Image.open(path) as image:
                    if image.width < 1000 or image.height < 1000:
                        low_resolution += 1
            except Exception:
                low_resolution += 1
        if low_resolution:
            penalty = min(15, low_resolution * 3)
            score -= penalty
            deductions.append({"points": penalty, "reason": f"저해상도 또는 오류 이미지 {low_resolution}장"})

    score = max(0, min(100, score))
    grade = "A" if score >= 90 else "B" if score >= 80 else "C" if score >= 70 else "D" if score >= 60 else "F"

    return {
        "score": score,
        "grade": grade,
        "deductions": deductions,
        "summary": (
            "바로 사용 가능한 수준" if score >= 90
            else "소폭 수정 권장" if score >= 80
            else "검수와 보완 필요" if score >= 70
            else "수정 후 사용 권장"
        ),
    }


def export_quality_report(project: Project, path: str | Path) -> Path:
    report = {
        "app_version": APP_VERSION,
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "product": project.fields.get("product", ""),
        "category": project.fields.get("category", ""),
        "quality": score_project_quality(project),
        "validation": validate_project(project),
        "template_recommendation": recommend_template(project.fields.get("category", ""), project.images),
    }
    path = Path(path)
    path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    return path


STORY_FLOWS = {
    "농산물": [
        ("관심 유도", "메인 배너"),
        ("신뢰 형성", "산지 소개"),
        ("핵심 설득", "핵심 장점"),
        ("품질 증명", "신선도"),
        ("활용 제안", "활용 방법"),
        ("불안 해소", "포장 안내"),
        ("구매 조건", "배송 안내"),
        ("구매 전환", "구매 유도"),
    ],
    "과일": [
        ("관심 유도", "메인 배너"),
        ("맛 기대", "당도 포인트"),
        ("신뢰 형성", "산지 소개"),
        ("품질 증명", "과육·식감"),
        ("선별 신뢰", "선별 과정"),
        ("불안 해소", "보관 안내"),
        ("구매 조건", "배송 안내"),
        ("구매 전환", "구매 유도"),
    ],
    "수산물": [
        ("관심 유도", "메인 배너"),
        ("품질 증명", "신선도"),
        ("신뢰 형성", "원산지"),
        ("상품 상태", "손질 상태"),
        ("활용 제안", "활용 방법"),
        ("불안 해소", "포장 안내"),
        ("구매 조건", "배송 안내"),
        ("구매 전환", "구매 유도"),
    ],
    "수산가공식품": [
        ("관심 유도", "메인 배너"),
        ("핵심 설득", "제품 특징"),
        ("맛 기대", "맛 포인트"),
        ("신뢰 형성", "원재료·원산지"),
        ("활용 제안", "활용 방법"),
        ("불안 해소", "보관 안내"),
        ("구매 조건", "배송 안내"),
        ("구매 전환", "구매 유도"),
    ],
    "식품": [
        ("관심 유도", "메인 배너"),
        ("핵심 설득", "핵심 장점"),
        ("상품 이해", "제품 소개"),
        ("품질 증명", "품질 포인트"),
        ("활용 제안", "활용 방법"),
        ("불안 해소", "포장 안내"),
        ("구매 조건", "배송 안내"),
        ("구매 전환", "구매 유도"),
    ],
}


def get_story_flow(category: str, cut_count: int = 8) -> list[dict[str, str]]:
    category = (category or "").strip()
    flow = STORY_FLOWS.get(category, STORY_FLOWS["식품"])
    if cut_count <= len(flow):
        selected = flow[:cut_count]
    else:
        selected = list(flow)
        while len(selected) < cut_count:
            selected.insert(-1, ("보조 설득", f"추가 특징 {len(selected) - len(flow) + 1}"))
    return [{"stage": stage, "title": title} for stage, title in selected[:cut_count]]


def apply_story_flow(project: Project, overwrite_titles: bool = True, reorder: bool = True) -> list[dict[str, str]]:
    if not project.cuts:
        return []

    flow = get_story_flow(project.fields.get("category", ""), len(project.cuts))

    if reorder:
        remaining = list(project.cuts)
        reordered = []
        for item in flow:
            target_title = item["title"].replace("·", "").replace(" ", "")
            best_index = None
            for index, cut in enumerate(remaining):
                normalized = cut.title.replace("·", "").replace(" ", "")
                if target_title in normalized or normalized in target_title:
                    best_index = index
                    break
            if best_index is None:
                best_index = 0
            reordered.append(remaining.pop(best_index))
        reordered.extend(remaining)
        project.cuts = reordered[:len(flow)]

    for index, cut in enumerate(project.cuts):
        cut.story_stage = flow[index]["stage"]
        if overwrite_titles:
            cut.title = flow[index]["title"]
        cut.layout_variant = recommend_cut_layout(cut.title, index)

    return flow


def analyze_story_flow(project: Project) -> dict[str, Any]:
    expected = get_story_flow(project.fields.get("category", ""), len(project.cuts))
    actual_stages = [getattr(cut, "story_stage", "") for cut in project.cuts]
    missing = [
        item["stage"] for item in expected
        if item["stage"] not in actual_stages
    ]
    duplicate_stages = sorted({
        stage for stage in actual_stages
        if stage and actual_stages.count(stage) > 1
    })

    score = 100
    deductions = []
    if missing:
        penalty = min(30, len(missing) * 8)
        score -= penalty
        deductions.append({"points": penalty, "reason": "누락 단계: " + ", ".join(missing)})
    if duplicate_stages:
        penalty = min(20, len(duplicate_stages) * 5)
        score -= penalty
        deductions.append({"points": penalty, "reason": "중복 단계: " + ", ".join(duplicate_stages)})
    if project.cuts:
        if project.cuts[0].story_stage != "관심 유도":
            score -= 12
            deductions.append({"points": 12, "reason": "첫 컷이 관심 유도 단계가 아닙니다."})
        if project.cuts[-1].story_stage != "구매 전환":
            score -= 12
            deductions.append({"points": 12, "reason": "마지막 컷이 구매 전환 단계가 아닙니다."})

    return {
        "score": max(0, score),
        "expected": expected,
        "actual": [
            {
                "index": index + 1,
                "stage": getattr(cut, "story_stage", ""),
                "title": cut.title,
                "layout": getattr(cut, "layout_variant", "기본 카드형"),
            }
            for index, cut in enumerate(project.cuts)
        ],
        "missing_stages": missing,
        "duplicate_stages": duplicate_stages,
        "deductions": deductions,
    }


def export_storyboard(project: Project, path: str | Path) -> Path:
    report = {
        "app_version": APP_VERSION,
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "product": project.fields.get("product", ""),
        "category": project.fields.get("category", ""),
        "story": analyze_story_flow(project),
    }
    path = Path(path)
    path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    return path


def image_role_score(path: str | Path, story_stage: str, title: str = "") -> float:
    """
    컷 역할에 맞는 사진 적합도를 휴리스틱으로 계산합니다.
    해상도, 방향, 밝기, 파일명 키워드를 함께 사용합니다.
    """
    try:
        metrics = image_metrics(path)
    except Exception:
        return 0.0

    score = 0.0
    width = metrics["width"]
    height = metrics["height"]
    brightness = metrics["brightness"]
    name = Path(path).stem.lower()

    # 기본 품질 점수
    pixels = width * height
    score += min(pixels / 2_000_000, 1.0) * 35
    score += max(0.0, 1 - abs(brightness - 150) / 150) * 15

    # 스토리 단계별 방향 선호
    if story_stage in {"관심 유도", "맛 기대", "품질 증명", "상품 상태"}:
        if width >= height:
            score += 12
    elif story_stage in {"신뢰 형성", "선별 신뢰", "활용 제안", "불안 해소"}:
        if height >= width:
            score += 10

    # 파일명 키워드
    keywords = {
        "관심 유도": ["대표", "메인", "main", "hero"],
        "맛 기대": ["단면", "과육", "속", "cut"],
        "신뢰 형성": ["산지", "농장", "원산지", "생산", "밭"],
        "핵심 설득": ["특징", "포인트", "강점"],
        "상품 이해": ["제품", "구성", "전체"],
        "품질 증명": ["신선", "확대", "디테일", "detail"],
        "선별 신뢰": ["선별", "검수", "작업"],
        "상품 상태": ["손질", "상태", "포장전"],
        "활용 제안": ["요리", "활용", "조리", "recipe"],
        "불안 해소": ["포장", "박스", "완충", "packing"],
        "구매 조건": ["배송", "택배", "출고"],
        "구매 전환": ["구성", "세트", "상품", "패키지"],
    }
    for keyword in keywords.get(story_stage, []):
        if keyword in name:
            score += 18
            break

    # 제목 기반 보정
    normalized_title = title.lower()
    if any(token in name for token in ["포장", "배송", "산지", "활용", "단면", "선별"] if token in normalized_title):
        score += 10

    return round(score, 2)


def recommend_images_for_cuts(project: Project, avoid_duplicates: bool = True) -> list[dict[str, Any]]:
    if not project.images or not project.cuts:
        return []

    recommendations = []
    used_counts = {index: 0 for index in range(len(project.images))}

    for cut_index, cut in enumerate(project.cuts):
        candidates = []
        for image_index, path in enumerate(project.images):
            score = image_role_score(path, getattr(cut, "story_stage", ""), cut.title)
            if avoid_duplicates:
                score -= used_counts[image_index] * 12
            candidates.append({
                "image_index": image_index,
                "path": path,
                "score": round(score, 2),
            })

        candidates.sort(key=lambda item: item["score"], reverse=True)
        best = candidates[0]
        used_counts[best["image_index"]] += 1
        recommendations.append({
            "cut_index": cut_index,
            "cut_title": cut.title,
            "story_stage": getattr(cut, "story_stage", ""),
            "selected_image_index": best["image_index"],
            "selected_path": best["path"],
            "score": best["score"],
            "alternatives": candidates[1:4],
        })

    return recommendations


def apply_recommended_images(project: Project, avoid_duplicates: bool = True) -> list[dict[str, Any]]:
    recommendations = recommend_images_for_cuts(project, avoid_duplicates=avoid_duplicates)
    for item in recommendations:
        project.cuts[item["cut_index"]].photo_index = item["selected_image_index"]
    return recommendations


def analyze_image_usage(project: Project) -> dict[str, Any]:
    usage = {index: 0 for index in range(len(project.images))}
    invalid = []
    for cut_index, cut in enumerate(project.cuts):
        if 0 <= cut.photo_index < len(project.images):
            usage[cut.photo_index] += 1
        else:
            invalid.append(cut_index + 1)

    duplicate_images = [
        {
            "image_index": index,
            "path": project.images[index],
            "used_count": count,
        }
        for index, count in usage.items()
        if count > 1
    ]
    unused_images = [
        {
            "image_index": index,
            "path": project.images[index],
        }
        for index, count in usage.items()
        if count == 0
    ]

    score = 100
    deductions = []
    if duplicate_images:
        penalty = min(25, sum(item["used_count"] - 1 for item in duplicate_images) * 5)
        score -= penalty
        deductions.append({"points": penalty, "reason": "동일 사진이 여러 컷에 반복 사용되었습니다."})
    if invalid:
        penalty = min(40, len(invalid) * 15)
        score -= penalty
        deductions.append({"points": penalty, "reason": "사진 연결 오류가 있습니다."})

    return {
        "score": max(0, score),
        "usage": usage,
        "duplicate_images": duplicate_images,
        "unused_images": unused_images,
        "invalid_cuts": invalid,
        "deductions": deductions,
    }


def export_image_assignment_report(project: Project, path: str | Path) -> Path:
    report = {
        "app_version": APP_VERSION,
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "product": project.fields.get("product", ""),
        "recommendations": recommend_images_for_cuts(project),
        "usage_analysis": analyze_image_usage(project),
    }
    path = Path(path)
    path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    return path


def build_one_click_project(
    fields: dict[str, str],
    image_paths: list[str],
    cut_count: int = 8,
    ai_config: AIConfig | None = None,
) -> tuple[Project, dict[str, Any]]:
    """
    상품정보와 사진만으로 초안 생성 → 품목 템플릿 → 스토리 구성
    → 컷 레이아웃 → 사진 배치까지 한 번에 처리합니다.
    """
    if not image_paths:
        raise ValueError("상품 사진이 필요합니다.")

    analysis = analyze_product(image_paths, fields, ai_config)
    merged_fields = apply_analysis_fields(fields, analysis, overwrite=False)

    project = Project(
        fields=merged_fields,
        images=list(image_paths),
        cuts=build_cuts(merged_fields, cut_count),
        ai_analysis=analysis,
    )

    for index, cut in enumerate(project.cuts):
        cut.photo_index = index % len(project.images)

    template = apply_category_template(project, overwrite_titles=True)
    story = apply_story_flow(project, overwrite_titles=True, reorder=True)
    layouts = apply_auto_layouts(project)
    image_recommendations = apply_recommended_images(project, avoid_duplicates=True)

    result = {
        "analysis": analysis,
        "template": template,
        "story": story,
        "layouts": layouts,
        "image_recommendations": image_recommendations,
        "quality": score_project_quality(project),
        "story_quality": analyze_story_flow(project),
        "image_usage": analyze_image_usage(project),
    }
    return project, result


def create_workflow_summary(project: Project, workflow_result: dict[str, Any]) -> dict[str, Any]:
    return {
        "app_version": APP_VERSION,
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "product": project.fields.get("product", ""),
        "category": project.fields.get("category", ""),
        "image_count": len(project.images),
        "cut_count": len(project.cuts),
        "style": project.style,
        "layout": project.layout,
        "quality_score": workflow_result.get("quality", {}).get("score"),
        "story_score": workflow_result.get("story_quality", {}).get("score"),
        "image_usage_score": workflow_result.get("image_usage", {}).get("score"),
        "ai_provider": workflow_result.get("analysis", {}).get("provider"),
        "warnings": workflow_result.get("analysis", {}).get("warnings", []),
    }


def export_one_click_package(
    project: Project,
    workflow_result: dict[str, Any],
    output_folder: str | Path,
) -> dict[str, Any]:
    output_folder = Path(output_folder)
    output_folder.mkdir(parents=True, exist_ok=True)

    export_summary = export_all_formats(project, output_folder)
    workflow_summary = create_workflow_summary(project, workflow_result)
    workflow_path = output_folder / "workflow_summary.json"
    workflow_path.write_text(
        json.dumps(workflow_summary, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    storyboard_path = export_storyboard(project, output_folder / "storyboard.json")
    image_report_path = export_image_assignment_report(
        project,
        output_folder / "image_assignment.json",
    )
    quality_report_path = export_quality_report(
        project,
        output_folder / "quality_report.json",
    )

    return {
        **export_summary,
        "workflow_summary": str(workflow_path),
        "storyboard": str(storyboard_path),
        "image_assignment": str(image_report_path),
        "quality_report": str(quality_report_path),
    }


REVIEW_STATUSES = ["검수 전", "수정 필요", "승인"]


def set_cut_review(
    cut: Cut,
    status: str,
    note: str = "",
) -> None:
    if status not in REVIEW_STATUSES:
        raise ValueError(f"지원하지 않는 검수 상태입니다: {status}")
    cut.review_status = status
    cut.review_note = note.strip()
    cut.approved = status == "승인"
    cut.reviewed_at = datetime.now().isoformat(timespec="seconds")


def review_summary(project: Project) -> dict[str, Any]:
    counts = {status: 0 for status in REVIEW_STATUSES}
    notes = []
    for index, cut in enumerate(project.cuts, 1):
        status = getattr(cut, "review_status", "검수 전")
        if status not in counts:
            status = "검수 전"
        counts[status] += 1
        if getattr(cut, "review_note", "").strip():
            notes.append({
                "cut": index,
                "title": cut.title,
                "status": status,
                "note": cut.review_note.strip(),
                "reviewed_at": getattr(cut, "reviewed_at", ""),
            })

    total = len(project.cuts)
    approved = counts["승인"]
    progress = round((approved / total) * 100, 1) if total else 0.0
    return {
        "total": total,
        "counts": counts,
        "approved_progress": progress,
        "notes": notes,
        "complete": total > 0 and approved == total,
    }


def next_review_cut(project: Project, current_index: int = -1) -> int | None:
    if not project.cuts:
        return None
    total = len(project.cuts)
    for offset in range(1, total + 1):
        index = (current_index + offset) % total
        status = getattr(project.cuts[index], "review_status", "검수 전")
        if status != "승인":
            return index
    return None


def export_approved_only(project: Project, output_folder: str | Path) -> dict[str, Any]:
    output_folder = Path(output_folder)
    output_folder.mkdir(parents=True, exist_ok=True)
    approved_cuts = [
        (index, cut)
        for index, cut in enumerate(project.cuts)
        if getattr(cut, "review_status", "검수 전") == "승인" or cut.approved
    ]
    if not approved_cuts:
        raise ValueError("승인된 컷이 없습니다.")
    if not project.images:
        raise ValueError("상품 사진이 없습니다.")

    png_folder = output_folder / "approved_png"
    png_folder.mkdir(exist_ok=True)
    pages = []

    for export_index, (original_index, cut) in enumerate(approved_cuts, 1):
        if not 0 <= cut.photo_index < len(project.images):
            raise ValueError(f"{original_index + 1}번 컷의 사진 연결이 잘못되었습니다.")
        rendered = render_cut(
            project.images[cut.photo_index],
            original_index,
            cut,
            project.style,
            project.layout,
            project.custom_background,
        )
        path = png_folder / f"{export_index:02d}_{sanitize_name(cut.title)}.png"
        rendered.save(path)
        pages.append(rendered)

    product = sanitize_name(project.fields.get("product", "") or "상품")
    pdf_path = output_folder / f"{product}_승인본.pdf"
    pages[0].save(pdf_path, save_all=True, append_images=pages[1:])

    summary = review_summary(project)
    report = {
        "app_version": APP_VERSION,
        "exported_at": datetime.now().isoformat(timespec="seconds"),
        "product": project.fields.get("product", ""),
        "approved_count": len(approved_cuts),
        "pdf": str(pdf_path),
        "review": summary,
    }
    report_path = output_folder / "review_report.json"
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    return {
        "approved_count": len(approved_cuts),
        "pdf": str(pdf_path),
        "report": str(report_path),
    }


def export_review_report(project: Project, path: str | Path) -> Path:
    report = {
        "app_version": APP_VERSION,
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "product": project.fields.get("product", ""),
        "category": project.fields.get("category", ""),
        "review": review_summary(project),
        "cuts": [
            {
                "index": index + 1,
                "title": cut.title,
                "status": getattr(cut, "review_status", "검수 전"),
                "note": getattr(cut, "review_note", ""),
                "reviewed_at": getattr(cut, "reviewed_at", ""),
            }
            for index, cut in enumerate(project.cuts)
        ],
    }
    path = Path(path)
    path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    return path


CHANNEL_PROFILES = {
    "스마트스토어": {"detail_width": 860, "thumbnail_size": 1000, "jpeg_quality": 92},
    "쿠팡": {"detail_width": 780, "thumbnail_size": 1000, "jpeg_quality": 92},
    "일반 쇼핑몰": {"detail_width": 900, "thumbnail_size": 1000, "jpeg_quality": 92},
}

ERROR_LOG_DIR = CONFIG_DIR / "logs"
SETTINGS_BACKUP_NAME = "nongjak_ai_settings_backup.json"


def get_channel_profile(channel: str) -> dict[str, Any]:
    return dict(CHANNEL_PROFILES.get(channel, CHANNEL_PROFILES["일반 쇼핑몰"]))


def resize_for_channel(image: Image.Image, channel: str) -> Image.Image:
    profile = get_channel_profile(channel)
    target_width = int(profile["detail_width"])
    if image.width == target_width:
        return image.copy()
    ratio = target_width / image.width
    return image.resize(
        (target_width, max(1, int(image.height * ratio))),
        Image.Resampling.LANCZOS,
    )


def create_channel_thumbnail(project: Project, channel: str, output_path: str | Path) -> Path:
    if not project.cuts or not project.images:
        raise ValueError("사진과 상세페이지 컷이 필요합니다.")
    cut = project.cuts[0]
    if not 0 <= cut.photo_index < len(project.images):
        raise ValueError("첫 컷의 사진 연결이 잘못되었습니다.")
    profile = get_channel_profile(channel)
    size = int(profile["thumbnail_size"])
    rendered = render_cut(
        project.images[cut.photo_index],
        0,
        cut,
        project.style,
        project.layout,
        project.custom_background,
    )
    thumbnail = ImageOps.fit(
        rendered,
        (size, size),
        method=Image.Resampling.LANCZOS,
    )
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    thumbnail.save(output_path, "JPEG", quality=int(profile["jpeg_quality"]), optimize=True)
    return output_path


def channel_export_check(project: Project, channel: str) -> dict[str, Any]:
    from io import BytesIO

    profile = get_channel_profile(channel)
    issues = []
    estimates = []

    if not project.cuts:
        issues.append({"level": "오류", "message": "상세페이지 컷이 없습니다."})
    if not project.images:
        issues.append({"level": "오류", "message": "상품 사진이 없습니다."})

    for index, cut in enumerate(project.cuts, 1):
        if not 0 <= cut.photo_index < len(project.images):
            issues.append({"level": "오류", "message": f"{index}번 컷의 사진 연결이 잘못되었습니다."})
            continue
        rendered = render_cut(
            project.images[cut.photo_index],
            index - 1,
            cut,
            project.style,
            project.layout,
            project.custom_background,
        )
        resized = resize_for_channel(rendered, channel)
        buffer = BytesIO()
        resized.save(buffer, "JPEG", quality=int(profile["jpeg_quality"]), optimize=True)
        estimates.append({
            "cut": index,
            "width": resized.width,
            "height": resized.height,
            "estimated_mb": round(len(buffer.getvalue()) / (1024 * 1024), 3),
        })

    if not issues:
        issues.append({"level": "정상", "message": f"{channel} 출력 점검을 통과했습니다."})

    return {"channel": channel, "profile": profile, "issues": issues, "estimates": estimates}


def export_channel_package(
    project: Project,
    channel: str,
    output_folder: str | Path,
    approved_only: bool = False,
) -> dict[str, Any]:
    if not project.cuts or not project.images:
        raise ValueError("사진과 상세페이지 컷이 필요합니다.")

    profile = get_channel_profile(channel)
    output_folder = Path(output_folder) / sanitize_name(channel)
    detail_folder = output_folder / "detail"
    detail_folder.mkdir(parents=True, exist_ok=True)

    selected = []
    for index, cut in enumerate(project.cuts):
        approved = getattr(cut, "review_status", "검수 전") == "승인" or cut.approved
        if approved_only and not approved:
            continue
        selected.append((index, cut))

    if not selected:
        raise ValueError("내보낼 컷이 없습니다.")

    files = []
    for export_index, (original_index, cut) in enumerate(selected, 1):
        rendered = render_cut(
            project.images[cut.photo_index],
            original_index,
            cut,
            project.style,
            project.layout,
            project.custom_background,
        )
        resized = resize_for_channel(rendered, channel)
        path = detail_folder / f"{export_index:02d}_{sanitize_name(cut.title)}.jpg"
        resized.save(path, "JPEG", quality=int(profile["jpeg_quality"]), optimize=True)
        files.append(str(path))

    product = sanitize_name(project.fields.get("product", "") or "상품")
    thumbnail = create_channel_thumbnail(
        project,
        channel,
        output_folder / f"{product}_대표이미지.jpg",
    )
    report = {
        "app_version": APP_VERSION,
        "channel": channel,
        "product": project.fields.get("product", ""),
        "approved_only": approved_only,
        "detail_count": len(files),
        "detail_files": files,
        "thumbnail": str(thumbnail),
        "check": channel_export_check(project, channel),
    }
    report_path = output_folder / "channel_export_report.json"
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    return report


def log_error(error: BaseException, context: str = "") -> Path:
    import traceback

    ERROR_LOG_DIR.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    path = ERROR_LOG_DIR / f"error_{timestamp}.log"
    text = (
        f"농작 AI v{APP_VERSION}\n"
        f"시간: {datetime.now().isoformat(timespec='seconds')}\n"
        f"상황: {context}\n"
        f"오류: {error}\n\n"
        + "".join(traceback.format_exception(type(error), error, error.__traceback__))
    )
    path.write_text(text, encoding="utf-8")
    return path


def export_settings_backup(path: str | Path) -> Path:
    path = Path(path)
    payload = {
        "app_version": APP_VERSION,
        "exported_at": datetime.now().isoformat(timespec="seconds"),
        "ai_config": load_ai_config().to_dict(),
        "recent_projects": load_recent_projects(),
    }
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return path


def import_settings_backup(path: str | Path) -> dict[str, Any]:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    if "ai_config" in data:
        save_ai_config(AIConfig.from_dict(data["ai_config"]))
    if "recent_projects" in data:
        RECENT_FILE.parent.mkdir(parents=True, exist_ok=True)
        RECENT_FILE.write_text(
            json.dumps(data["recent_projects"], ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
    return data


def system_health_report(project: Project | None = None) -> dict[str, Any]:
    checks = {
        "config_dir_writable": False,
        "project_library_exists": PROJECT_LIBRARY_DIR.exists(),
        "backup_dir_exists": BACKUP_DIR.exists(),
        "error_log_dir_exists": ERROR_LOG_DIR.exists(),
        "pillow_available": True,
        "project_loaded": project is not None,
    }
    try:
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        probe = CONFIG_DIR / ".write_test"
        probe.write_text("ok", encoding="utf-8")
        probe.unlink(missing_ok=True)
        checks["config_dir_writable"] = True
    except Exception:
        checks["config_dir_writable"] = False

    score = round(sum(1 for value in checks.values() if value) / len(checks) * 100)
    return {
        "app_version": APP_VERSION,
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "score": score,
        "checks": checks,
        "project_validation": validate_project(project) if project else [],
    }


FIRST_RUN_FILE = CONFIG_DIR / "first_run.json"
UPDATE_CONFIG_FILE = CONFIG_DIR / "update_config.json"
SUPPORT_BUNDLE_DIR = CONFIG_DIR / "support_bundles"


@dataclass
class UpdateConfig:
    manifest_url: str = ""
    auto_check: bool = False
    channel: str = "stable"

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "UpdateConfig":
        return cls(
            manifest_url=str(data.get("manifest_url", "")),
            auto_check=bool(data.get("auto_check", False)),
            channel=str(data.get("channel", "stable")),
        )


def save_update_config(config: UpdateConfig, path: str | Path = UPDATE_CONFIG_FILE) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(config.to_dict(), ensure_ascii=False, indent=2), encoding="utf-8")


def load_update_config(path: str | Path = UPDATE_CONFIG_FILE) -> UpdateConfig:
    path = Path(path)
    if not path.exists():
        return UpdateConfig()
    try:
        return UpdateConfig.from_dict(json.loads(path.read_text(encoding="utf-8")))
    except Exception:
        return UpdateConfig()


def mark_first_run_complete(data: dict[str, Any] | None = None, path: str | Path = FIRST_RUN_FILE) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "completed": True,
        "completed_at": datetime.now().isoformat(timespec="seconds"),
        "app_version": APP_VERSION,
        "settings": data or {},
    }
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return path


def is_first_run(path: str | Path = FIRST_RUN_FILE) -> bool:
    path = Path(path)
    if not path.exists():
        return True
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return not bool(data.get("completed", False))
    except Exception:
        return True


def compare_versions(current: str, latest: str) -> int:
    def parse(value: str) -> tuple[int, ...]:
        numbers = []
        for part in value.strip().lstrip("vV").split("."):
            digits = "".join(character for character in part if character.isdigit())
            numbers.append(int(digits or 0))
        while len(numbers) < 3:
            numbers.append(0)
        return tuple(numbers)

    current_parts = parse(current)
    latest_parts = parse(latest)
    if current_parts < latest_parts:
        return -1
    if current_parts > latest_parts:
        return 1
    return 0


def read_update_manifest(
    config: UpdateConfig,
    timeout_seconds: int = 15,
) -> dict[str, Any]:
    if not config.manifest_url.strip():
        raise ValueError("업데이트 정보 주소가 입력되지 않았습니다.")

    request = urllib.request.Request(
        config.manifest_url.strip(),
        headers={"User-Agent": f"NongjakAI/{APP_VERSION}"},
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout_seconds) as response:
            data = json.loads(response.read().decode("utf-8"))
    except Exception as error:
        raise RuntimeError(f"업데이트 정보 확인 실패: {error}") from error

    if not isinstance(data, dict):
        raise ValueError("업데이트 정보가 JSON 객체가 아닙니다.")
    if "version" not in data:
        raise ValueError("업데이트 정보에 version 값이 없습니다.")
    return data


def check_for_update(
    config: UpdateConfig | None = None,
    manifest: dict[str, Any] | None = None,
) -> dict[str, Any]:
    config = config or load_update_config()
    manifest = manifest or read_update_manifest(config)
    latest = str(manifest.get("version", "0.0.0"))
    comparison = compare_versions(APP_VERSION, latest)
    return {
        "current_version": APP_VERSION,
        "latest_version": latest,
        "update_available": comparison < 0,
        "same_version": comparison == 0,
        "download_url": manifest.get("download_url", ""),
        "release_notes": manifest.get("release_notes", ""),
        "channel": manifest.get("channel", config.channel),
        "minimum_version": manifest.get("minimum_version", ""),
    }


def create_support_bundle(
    project: Project | None = None,
    output_path: str | Path | None = None,
) -> Path:
    import platform
    import tempfile

    SUPPORT_BUNDLE_DIR.mkdir(parents=True, exist_ok=True)
    if output_path is None:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_path = SUPPORT_BUNDLE_DIR / f"nongjak_support_{timestamp}.zip"
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    with tempfile.TemporaryDirectory() as temp_directory:
        temp = Path(temp_directory)

        system = {
            "app_version": APP_VERSION,
            "generated_at": datetime.now().isoformat(timespec="seconds"),
            "python_version": sys.version,
            "platform": platform.platform(),
            "machine": platform.machine(),
            "health": system_health_report(project),
        }
        (temp / "system_report.json").write_text(
            json.dumps(system, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

        if project is not None:
            (temp / "project_summary.json").write_text(
                json.dumps({
                    "fields": project.fields,
                    "image_count": len(project.images),
                    "cut_count": len(project.cuts),
                    "review": review_summary(project),
                    "validation": validate_project(project),
                }, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )

        for source in [AI_CONFIG_FILE, UPDATE_CONFIG_FILE, RECENT_FILE]:
            if source.exists():
                shutil.copy2(source, temp / source.name)

        if ERROR_LOG_DIR.exists():
            logs_folder = temp / "logs"
            logs_folder.mkdir(exist_ok=True)
            for log_path in sorted(
                ERROR_LOG_DIR.glob("*.log"),
                key=lambda item: item.stat().st_mtime,
                reverse=True,
            )[:10]:
                shutil.copy2(log_path, logs_folder / log_path.name)

        with zipfile.ZipFile(output_path, "w", zipfile.ZIP_DEFLATED) as archive:
            for file in temp.rglob("*"):
                if file.is_file():
                    archive.write(file, file.relative_to(temp))

    return output_path


def recover_latest_backup(
    backup_dir: str | Path = BACKUP_DIR,
) -> tuple[Project, Path]:
    backup_dir = Path(backup_dir)
    backups = sorted(
        backup_dir.glob("*.nongjak.json"),
        key=lambda path: path.stat().st_mtime,
        reverse=True,
    )
    if not backups:
        raise FileNotFoundError("복구할 프로젝트 백업이 없습니다.")

    for path in backups:
        try:
            return load_project(path), path
        except Exception:
            continue
    raise RuntimeError("백업 파일을 읽을 수 없습니다.")


def normalize_indices(indices: list[int], length: int) -> list[int]:
    return sorted({index for index in indices if 0 <= index < length})


def approve_cuts(project: Project, indices: list[int], note: str = "") -> int:
    selected = normalize_indices(indices, len(project.cuts))
    for index in selected:
        set_cut_review(project.cuts[index], "승인", note or project.cuts[index].review_note)
    return len(selected)


def mark_cuts_for_revision(project: Project, indices: list[int], note: str = "") -> int:
    selected = normalize_indices(indices, len(project.cuts))
    for index in selected:
        set_cut_review(project.cuts[index], "수정 필요", note or project.cuts[index].review_note)
    return len(selected)


def delete_cuts(project: Project, indices: list[int]) -> int:
    selected = normalize_indices(indices, len(project.cuts))
    for index in reversed(selected):
        del project.cuts[index]
    return len(selected)


def duplicate_cuts(project: Project, indices: list[int]) -> list[int]:
    selected = normalize_indices(indices, len(project.cuts))
    inserted_indices = []
    offset = 0
    for original_index in selected:
        insert_at = original_index + 1 + offset
        project.cuts.insert(insert_at, duplicate_cut(project.cuts[original_index + offset]))
        inserted_indices.append(insert_at)
        offset += 1
    return inserted_indices


def move_selected_cuts(project: Project, indices: list[int], direction: int) -> list[int]:
    selected = normalize_indices(indices, len(project.cuts))
    if not selected or direction not in {-1, 1}:
        return selected

    if direction < 0:
        selected_set = set(selected)
        for index in selected:
            if index == 0 or index - 1 in selected_set:
                continue
            project.cuts[index - 1], project.cuts[index] = project.cuts[index], project.cuts[index - 1]
        return [max(0, index - 1) for index in selected]

    selected_set = set(selected)
    for index in reversed(selected):
        if index >= len(project.cuts) - 1 or index + 1 in selected_set:
            continue
        project.cuts[index], project.cuts[index + 1] = project.cuts[index + 1], project.cuts[index]
    return [min(len(project.cuts) - 1, index + 1) for index in selected]


def cut_manager_rows(project: Project) -> list[dict[str, Any]]:
    rows = []
    for index, cut in enumerate(project.cuts):
        rows.append({
            "index": index,
            "number": index + 1,
            "title": cut.title,
            "story_stage": getattr(cut, "story_stage", ""),
            "review_status": getattr(cut, "review_status", "검수 전"),
            "approved": bool(cut.approved),
            "photo_index": cut.photo_index,
            "layout_variant": getattr(cut, "layout_variant", "기본 카드형"),
        })
    return rows


AUTOSAVE_DIR = CONFIG_DIR / "autosave"
SESSION_FILE = CONFIG_DIR / "session_state.json"


def project_fingerprint(project: Project) -> str:
    import hashlib

    payload = json.dumps(project.to_dict(), ensure_ascii=False, sort_keys=True)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def save_session_state(
    project: Project,
    current_index: int,
    dirty: bool,
    path: str | Path = SESSION_FILE,
) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "app_version": APP_VERSION,
        "saved_at": datetime.now().isoformat(timespec="seconds"),
        "current_index": int(current_index),
        "dirty": bool(dirty),
        "project": project.to_dict(),
        "fingerprint": project_fingerprint(project),
    }
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return path


def load_session_state(path: str | Path = SESSION_FILE) -> dict[str, Any] | None:
    path = Path(path)
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        data["project_object"] = Project.from_dict(data.get("project", {}))
        return data
    except Exception:
        return None


def create_autosave_snapshot(
    project: Project,
    autosave_dir: str | Path = AUTOSAVE_DIR,
    keep: int = 10,
) -> Path:
    autosave_dir = Path(autosave_dir)
    autosave_dir.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    product = sanitize_name(project.fields.get("product", "") or "프로젝트")
    path = autosave_dir / f"{product}_{timestamp}.nongjak.json"
    save_project(project, path)

    snapshots = sorted(
        autosave_dir.glob("*.nongjak.json"),
        key=lambda item: item.stat().st_mtime,
        reverse=True,
    )
    for old in snapshots[keep:]:
        old.unlink(missing_ok=True)
    return path


def load_latest_autosave(
    autosave_dir: str | Path = AUTOSAVE_DIR,
) -> tuple[Project, Path] | None:
    autosave_dir = Path(autosave_dir)
    snapshots = sorted(
        autosave_dir.glob("*.nongjak.json"),
        key=lambda item: item.stat().st_mtime,
        reverse=True,
    )
    for path in snapshots:
        try:
            return load_project(path), path
        except Exception:
            continue
    return None


def estimate_image_memory(path: str | Path) -> dict[str, Any]:
    with Image.open(path) as image:
        width, height = image.size
        bands = len(image.getbands())
    raw_bytes = width * height * max(1, bands)
    return {
        "width": width,
        "height": height,
        "bands": bands,
        "estimated_raw_mb": round(raw_bytes / (1024 * 1024), 2),
    }


def optimize_image_for_working_copy(
    source_path: str | Path,
    output_folder: str | Path,
    max_side: int = 2400,
    quality: int = 90,
) -> Path:
    source_path = Path(source_path)
    output_folder = Path(output_folder)
    output_folder.mkdir(parents=True, exist_ok=True)

    with Image.open(source_path) as image:
        image = image.convert("RGB")
        if max(image.size) > max_side:
            image.thumbnail((max_side, max_side), Image.Resampling.LANCZOS)
        output_path = output_folder / f"{sanitize_name(source_path.stem)}_working.jpg"
        counter = 2
        while output_path.exists():
            output_path = output_folder / f"{sanitize_name(source_path.stem)}_working_{counter}.jpg"
            counter += 1
        image.save(output_path, "JPEG", quality=quality, optimize=True)
    return output_path


def optimize_project_images(
    project: Project,
    output_folder: str | Path,
    max_side: int = 2400,
) -> dict[str, Any]:
    output_folder = Path(output_folder)
    new_paths = []
    results = []
    for path in project.images:
        before = estimate_image_memory(path)
        optimized = optimize_image_for_working_copy(path, output_folder, max_side=max_side)
        after = estimate_image_memory(optimized)
        new_paths.append(str(optimized))
        results.append({
            "source": str(path),
            "optimized": str(optimized),
            "before": before,
            "after": after,
        })

    project.images = new_paths
    return {
        "count": len(results),
        "results": results,
        "max_side": max_side,
    }


SUPPORTED_IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".webp", ".bmp"}
PRESET_FILE = CONFIG_DIR / "product_presets.json"

IMAGE_ROLE_KEYWORDS = {
    "대표": ["대표", "메인", "main", "hero", "썸네일"],
    "산지": ["산지", "밭", "농장", "원산지", "생산지"],
    "단면": ["단면", "과육", "속", "절단"],
    "선별": ["선별", "검수", "작업"],
    "활용": ["요리", "활용", "조리", "레시피"],
    "포장": ["포장", "박스", "완충"],
    "배송": ["배송", "택배", "출고"],
    "구성": ["구성", "세트", "전체", "패키지"],
}


def file_sha256(path: str | Path, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as file:
        while True:
            chunk = file.read(chunk_size)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def classify_image_filename(path: str | Path) -> dict[str, Any]:
    path = Path(path)
    normalized = re.sub(r"[_\-\s]+", " ", path.stem.lower()).strip()
    matched = {}
    for role, keywords in IMAGE_ROLE_KEYWORDS.items():
        score = sum(1 for keyword in keywords if keyword.lower() in normalized)
        if score:
            matched[role] = score
    role = max(matched, key=matched.get) if matched else "일반"
    return {"path": str(path), "filename": path.name, "role": role, "matched_roles": matched}


def scan_image_folder(folder: str | Path, recursive: bool = False) -> dict[str, Any]:
    folder = Path(folder)
    if not folder.exists() or not folder.is_dir():
        raise FileNotFoundError("사진 폴더를 찾을 수 없습니다.")

    iterator = folder.rglob("*") if recursive else folder.glob("*")
    files = sorted(
        path for path in iterator
        if path.is_file() and path.suffix.lower() in SUPPORTED_IMAGE_EXTENSIONS
    )

    unique = []
    duplicates = []
    seen = {}
    for path in files:
        digest = file_sha256(path)
        if digest in seen:
            duplicates.append({
                "path": str(path),
                "duplicate_of": str(seen[digest]),
                "sha256": digest,
            })
            continue
        seen[digest] = path
        unique.append(path)

    images = [classify_image_filename(path) for path in unique]
    role_counts = {}
    for item in images:
        role_counts[item["role"]] = role_counts.get(item["role"], 0) + 1

    return {
        "folder": str(folder),
        "total_found": len(files),
        "unique_count": len(unique),
        "duplicate_count": len(duplicates),
        "images": images,
        "duplicates": duplicates,
        "role_counts": role_counts,
    }


def infer_product_name_from_folder(folder: str | Path) -> str:
    name = Path(folder).name
    name = re.sub(r"^\d{4}[-_.]?\d{1,2}[-_.]?\d{1,2}[-_.]?", "", name)
    name = re.sub(r"[_\-]+", " ", name)
    name = re.sub(r"\b(사진|이미지|상품|상세페이지|원본|촬영본)\b", "", name)
    return re.sub(r"\s+", " ", name).strip()


def sort_images_by_role(items: list[dict[str, Any]]) -> list[dict[str, Any]]:
    priority = {"대표": 0, "구성": 1, "단면": 2, "산지": 3, "선별": 4, "활용": 5, "포장": 6, "배송": 7, "일반": 8}
    return sorted(items, key=lambda item: (priority.get(item.get("role", "일반"), 99), item.get("filename", "").lower()))


def build_project_from_folder(
    folder: str | Path,
    fields: dict[str, str] | None = None,
    cut_count: int = 8,
    ai_config: AIConfig | None = None,
) -> tuple[Project, dict[str, Any]]:
    scan = scan_image_folder(folder)
    if not scan["images"]:
        raise ValueError("폴더에 사용할 수 있는 상품 사진이 없습니다.")

    sorted_images = sort_images_by_role(scan["images"])
    image_paths = [item["path"] for item in sorted_images]
    merged_fields = dict(fields or {})
    if not merged_fields.get("product", "").strip():
        merged_fields["product"] = infer_product_name_from_folder(folder)

    project, workflow = build_one_click_project(
        merged_fields,
        image_paths,
        cut_count=cut_count,
        ai_config=ai_config,
    )
    workflow["folder_scan"] = scan
    workflow["sorted_images"] = sorted_images
    return project, workflow


def load_product_presets(path: str | Path = PRESET_FILE) -> list[dict[str, Any]]:
    path = Path(path)
    if not path.exists():
        return []
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, list) else []
    except Exception:
        return []


def save_product_presets(presets: list[dict[str, Any]], path: str | Path = PRESET_FILE) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(presets, ensure_ascii=False, indent=2), encoding="utf-8")
    return path


def create_product_preset(
    name: str,
    fields: dict[str, str],
    style: str,
    layout: str,
    cut_count: int,
) -> dict[str, Any]:
    if not name.strip():
        raise ValueError("프리셋 이름이 필요합니다.")
    return {
        "name": name.strip(),
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "fields": {
            "category": fields.get("category", ""),
            "origin": fields.get("origin", ""),
            "feature1": fields.get("feature1", ""),
            "feature2": fields.get("feature2", ""),
            "shipping": fields.get("shipping", ""),
        },
        "style": style,
        "layout": layout,
        "cut_count": max(1, min(int(cut_count), 10)),
    }


def upsert_product_preset(preset: dict[str, Any], path: str | Path = PRESET_FILE) -> list[dict[str, Any]]:
    presets = load_product_presets(path)
    presets = [item for item in presets if item.get("name") != preset.get("name")]
    presets.append(preset)
    presets.sort(key=lambda item: item.get("name", ""))
    save_product_presets(presets, path)
    return presets


def delete_product_preset(name: str, path: str | Path = PRESET_FILE) -> int:
    presets = load_product_presets(path)
    remaining = [item for item in presets if item.get("name") != name]
    save_product_presets(remaining, path)
    return len(presets) - len(remaining)


def apply_product_preset(
    current_fields: dict[str, str],
    preset: dict[str, Any],
    preserve_product_name: bool = True,
) -> dict[str, Any]:
    fields = dict(current_fields)
    product_name = fields.get("product", "")
    for key, value in preset.get("fields", {}).items():
        fields[key] = str(value)
    if preserve_product_name:
        fields["product"] = product_name
    return {
        "fields": fields,
        "style": preset.get("style", "프리미엄"),
        "layout": preset.get("layout", "균형형"),
        "cut_count": int(preset.get("cut_count", 8)),
    }


BATCH_JOB_STATUSES = ["대기", "진행 중", "성공", "실패"]


def discover_product_folders(root_folder: str | Path) -> list[Path]:
    root_folder = Path(root_folder)
    if not root_folder.exists() or not root_folder.is_dir():
        raise FileNotFoundError("상품 폴더 루트를 찾을 수 없습니다.")

    folders = []
    for child in sorted(root_folder.iterdir()):
        if not child.is_dir():
            continue
        has_image = any(
            path.is_file() and path.suffix.lower() in SUPPORTED_IMAGE_EXTENSIONS
            for path in child.iterdir()
        )
        if has_image:
            folders.append(child)
    return folders


def create_batch_jobs(
    root_folder: str | Path,
    output_folder: str | Path,
    default_fields: dict[str, str] | None = None,
    cut_count: int = 8,
) -> list[dict[str, Any]]:
    jobs = []
    for index, folder in enumerate(discover_product_folders(root_folder), 1):
        jobs.append({
            "id": index,
            "folder": str(folder),
            "product_name": infer_product_name_from_folder(folder),
            "output_folder": str(Path(output_folder) / sanitize_name(folder.name)),
            "default_fields": dict(default_fields or {}),
            "cut_count": int(cut_count),
            "status": "대기",
            "error": "",
            "result": {},
        })
    return jobs


def run_batch_job(
    job: dict[str, Any],
    ai_config: AIConfig | None = None,
) -> dict[str, Any]:
    job = dict(job)
    job["status"] = "진행 중"
    try:
        fields = dict(job.get("default_fields", {}))
        if not fields.get("product", "").strip():
            fields["product"] = job.get("product_name", "")

        project, workflow = build_project_from_folder(
            job["folder"],
            fields=fields,
            cut_count=int(job.get("cut_count", 8)),
            ai_config=ai_config,
        )

        output_folder = Path(job["output_folder"])
        output_folder.mkdir(parents=True, exist_ok=True)
        package = export_one_click_package(project, workflow, output_folder)

        job["status"] = "성공"
        job["error"] = ""
        job["result"] = {
            "project_fields": project.fields,
            "image_count": len(project.images),
            "cut_count": len(project.cuts),
            "package": package,
        }
    except Exception as error:
        job["status"] = "실패"
        job["error"] = str(error)
        job["result"] = {}
    return job


def run_batch_jobs(
    jobs: list[dict[str, Any]],
    ai_config: AIConfig | None = None,
) -> list[dict[str, Any]]:
    return [run_batch_job(job, ai_config=ai_config) for job in jobs]


def batch_summary(jobs: list[dict[str, Any]]) -> dict[str, Any]:
    counts = {status: 0 for status in BATCH_JOB_STATUSES}
    for job in jobs:
        status = job.get("status", "대기")
        if status not in counts:
            status = "실패"
        counts[status] += 1

    return {
        "total": len(jobs),
        "counts": counts,
        "success_rate": round(
            (counts["성공"] / len(jobs)) * 100,
            1,
        ) if jobs else 0.0,
        "failed_jobs": [
            {
                "id": job.get("id"),
                "product_name": job.get("product_name", ""),
                "folder": job.get("folder", ""),
                "error": job.get("error", ""),
            }
            for job in jobs
            if job.get("status") == "실패"
        ],
    }


def export_batch_report(
    jobs: list[dict[str, Any]],
    path: str | Path,
) -> Path:
    report = {
        "app_version": APP_VERSION,
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "summary": batch_summary(jobs),
        "jobs": jobs,
    }
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    return path


BATCH_STATE_FILENAME = "batch_state.json"
BATCH_METADATA_COLUMNS = ["folder_name","product","category","origin","feature1","feature2","shipping","cut_count"]
PREFLIGHT_LEVELS = ["정상","경고","오류"]


def export_batch_metadata_template(root_folder: str | Path, path: str | Path) -> Path:
    rows=[]
    for folder in discover_product_folders(root_folder):
        rows.append({
            "folder_name":folder.name,
            "product":infer_product_name_from_folder(folder),
            "category":"","origin":"","feature1":"","feature2":"",
            "shipping":"한진택배","cut_count":"8",
        })
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    with path.open("w",encoding="utf-8-sig",newline="") as file:
        writer=csv.DictWriter(file,fieldnames=BATCH_METADATA_COLUMNS)
        writer.writeheader(); writer.writerows(rows)
    return path


def load_batch_metadata(path: str | Path) -> dict[str,dict[str,str]]:
    mapping={}
    with Path(path).open("r",encoding="utf-8-sig",newline="") as file:
        reader=csv.DictReader(file)
        missing=[column for column in BATCH_METADATA_COLUMNS if column not in (reader.fieldnames or [])]
        if missing: raise ValueError("CSV 필수 열 누락: "+", ".join(missing))
        for row in reader:
            folder_name=str(row.get("folder_name","")).strip()
            if folder_name:
                mapping[folder_name]={key:str(row.get(key,"") or "").strip() for key in BATCH_METADATA_COLUMNS}
    return mapping


def apply_batch_metadata(jobs: list[dict[str,Any]], metadata: dict[str,dict[str,str]]) -> list[dict[str,Any]]:
    updated=[]
    for job in jobs:
        item=dict(job); row=metadata.get(Path(item.get("folder","")).name)
        if row:
            fields=dict(item.get("default_fields",{}))
            for key in ["product","category","origin","feature1","feature2","shipping"]:
                if row.get(key): fields[key]=row[key]
            item["default_fields"]=fields
            item["product_name"]=row.get("product") or item.get("product_name","")
            try: item["cut_count"]=max(1,min(int(row.get("cut_count","8") or 8),10))
            except ValueError: item["cut_count"]=8
        updated.append(item)
    return updated


def save_batch_state(jobs: list[dict[str,Any]], path: str | Path) -> Path:
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps({
        "app_version":APP_VERSION,
        "saved_at":datetime.now().isoformat(timespec="seconds"),
        "summary":batch_summary(jobs),
        "jobs":jobs,
    },ensure_ascii=False,indent=2),encoding="utf-8")
    return path


def load_batch_state(path: str | Path) -> list[dict[str,Any]]:
    data=json.loads(Path(path).read_text(encoding="utf-8"))
    jobs=data.get("jobs",[])
    if not isinstance(jobs,list): raise ValueError("배치 상태 파일 형식이 올바르지 않습니다.")
    return jobs


def reset_failed_batch_jobs(jobs: list[dict[str,Any]]) -> list[dict[str,Any]]:
    result=[]
    for job in jobs:
        item=dict(job)
        if item.get("status")=="실패":
            item["status"]="대기"; item["error"]=""; item["result"]={}
        result.append(item)
    return result


def resume_batch_jobs(jobs: list[dict[str,Any]], ai_config: AIConfig|None=None, state_path: str|Path|None=None) -> list[dict[str,Any]]:
    completed=[]
    for index,job in enumerate(jobs):
        completed.append(dict(job) if job.get("status")=="성공" else run_batch_job(job,ai_config=ai_config))
        if state_path: save_batch_state(completed+jobs[index+1:],state_path)
    return completed


def validate_batch_job_output(job: dict[str,Any]) -> dict[str,Any]:
    issues=[]; result=job.get("result",{}); package=result.get("package",{}) if isinstance(result,dict) else {}
    if job.get("status")!="성공": issues.append("성공 상태가 아닙니다.")
    for key in ["project","pdf","storyboard"]:
        value=package.get(key)
        if not value or not Path(value).exists(): issues.append(f"{key} 결과 파일 확인 필요")
    png_folder=package.get("png_folder")
    if not png_folder or not Path(png_folder).exists():
        issues.append("PNG 결과 폴더 확인 필요")
    else:
        expected=int(result.get("cut_count",0)); actual=len(list(Path(png_folder).glob("*.png")))
        if expected and actual!=expected: issues.append(f"PNG 수량 불일치: 예상 {expected} / 실제 {actual}")
    return {"job_id":job.get("id"),"product_name":job.get("product_name",""),"valid":not issues,"issues":issues}


def validate_batch_outputs(jobs: list[dict[str,Any]]) -> dict[str,Any]:
    results=[validate_batch_job_output(job) for job in jobs]
    valid_count=sum(1 for item in results if item["valid"])
    return {"total":len(results),"valid_count":valid_count,"invalid_count":len(results)-valid_count,"results":results}


def preflight_check_job(job: dict[str,Any]) -> dict[str,Any]:
    issues=[]; fields=dict(job.get("default_fields",{})); folder=Path(job.get("folder","")); output=Path(job.get("output_folder",""))
    image_count=0
    if not folder.exists():
        issues.append({"level":"오류","message":"상품 사진 폴더가 없습니다."})
    else:
        scan=scan_image_folder(folder); image_count=scan["unique_count"]
        if image_count==0: issues.append({"level":"오류","message":"사용 가능한 상품 사진이 없습니다."})
        elif image_count<3: issues.append({"level":"경고","message":f"상품 사진이 {image_count}장뿐입니다."})
        if scan["duplicate_count"]: issues.append({"level":"경고","message":f"중복 사진 {scan['duplicate_count']}장이 제외됩니다."})
    for key,label in {"product":"상품명","category":"품목","origin":"원산지","feature1":"핵심 특징 1","feature2":"핵심 특징 2","shipping":"배송정보"}.items():
        if not str(fields.get(key,"")).strip():
            issues.append({"level":"오류" if key in {"product","category"} else "경고","message":f"{label}이 비어 있습니다."})
    try: cut_count=int(job.get("cut_count",8))
    except Exception: cut_count=8; issues.append({"level":"경고","message":"컷 수가 올바르지 않아 8컷으로 처리됩니다."})
    if not 1<=cut_count<=10: issues.append({"level":"오류","message":f"컷 수는 1~10이어야 합니다: {cut_count}"})
    if output.exists() and any(output.iterdir()): issues.append({"level":"경고","message":"결과 폴더에 기존 파일이 있습니다."})
    status="오류" if any(i["level"]=="오류" for i in issues) else "경고" if any(i["level"]=="경고" for i in issues) else "정상"
    return {"job_id":job.get("id"),"product_name":job.get("product_name",""),"folder":str(folder),"output_folder":str(output),"image_count":image_count,"cut_count":cut_count,"status":status,"issues":issues,"ready":status!="오류"}


def preflight_check_jobs(jobs: list[dict[str,Any]]) -> dict[str,Any]:
    results=[preflight_check_job(job) for job in jobs]
    product_map={}; output_map={}
    for index,result in enumerate(results):
        product_map.setdefault(result["product_name"].strip().lower(),[]).append(index)
        output_map.setdefault(result["output_folder"].strip().lower(),[]).append(index)
    for indexes in product_map.values():
        if len(indexes)>1:
            for index in indexes:
                results[index]["issues"].append({"level":"경고","message":"동일한 상품명이 배치에 여러 번 있습니다."})
                if results[index]["status"]=="정상": results[index]["status"]="경고"
    for indexes in output_map.values():
        if len(indexes)>1:
            for index in indexes:
                results[index]["issues"].append({"level":"오류","message":"여러 작업이 동일한 결과 폴더를 사용합니다."})
                results[index]["status"]="오류"; results[index]["ready"]=False
    counts={level:sum(1 for item in results if item["status"]==level) for level in PREFLIGHT_LEVELS}
    return {"total":len(results),"counts":counts,"ready_count":sum(i["ready"] for i in results),"blocked_count":sum(not i["ready"] for i in results),"results":results}


def select_jobs_by_ids(jobs: list[dict[str,Any]], selected_ids: list[int]) -> list[dict[str,Any]]:
    selected=set(int(value) for value in selected_ids)
    return [dict(job) for job in jobs if int(job.get("id",-1)) in selected]


def select_ready_jobs(jobs: list[dict[str,Any]], preflight: dict[str,Any]|None=None) -> list[dict[str,Any]]:
    preflight=preflight or preflight_check_jobs(jobs)
    return select_jobs_by_ids(jobs,[item["job_id"] for item in preflight["results"] if item["ready"]])


def export_preflight_report(jobs: list[dict[str,Any]], path: str | Path) -> Path:
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps({"app_version":APP_VERSION,"generated_at":datetime.now().isoformat(timespec="seconds"),"preflight":preflight_check_jobs(jobs),"jobs":jobs},ensure_ascii=False,indent=2),encoding="utf-8")
    return path


def create_batch_manifest(jobs: list[dict[str,Any]], path: str | Path) -> Path:
    preflight=preflight_check_jobs(jobs); path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps({
        "app_version":APP_VERSION,
        "created_at":datetime.now().isoformat(timespec="seconds"),
        "job_count":len(jobs),
        "ready_count":preflight["ready_count"],
        "blocked_count":preflight["blocked_count"],
        "jobs":[{"id":job.get("id"),"product_name":job.get("product_name",""),"folder":job.get("folder",""),"output_folder":job.get("output_folder",""),"cut_count":job.get("cut_count",8),"preflight_status":preflight["results"][index]["status"]} for index,job in enumerate(jobs)],
    },ensure_ascii=False,indent=2),encoding="utf-8")
    return path


OUTPUT_POLICIES = ["새 버전 폴더", "기존 결과 백업", "빈 폴더만 사용"]


def estimate_folder_size(path: str | Path) -> int:
    path = Path(path)
    if not path.exists():
        return 0
    total = 0
    for file in path.rglob("*"):
        if file.is_file():
            try:
                total += file.stat().st_size
            except OSError:
                continue
    return total


def estimate_batch_required_space(jobs: list[dict[str, Any]]) -> dict[str, Any]:
    source_bytes = 0
    image_count = 0
    cut_count = 0

    for job in jobs:
        folder = Path(job.get("folder", ""))
        if folder.exists():
            for file in folder.iterdir():
                if file.is_file() and file.suffix.lower() in SUPPORTED_IMAGE_EXTENSIONS:
                    try:
                        source_bytes += file.stat().st_size
                        image_count += 1
                    except OSError:
                        pass
        cut_count += int(job.get("cut_count", 8) or 8)

    # PNG, PDF, 프로젝트, 보고서까지 고려한 보수적 추정치
    estimated_output_bytes = max(
        20 * 1024 * 1024,
        source_bytes * 3 + cut_count * 2_500_000,
    )
    return {
        "source_bytes": source_bytes,
        "source_mb": round(source_bytes / (1024 * 1024), 1),
        "image_count": image_count,
        "cut_count": cut_count,
        "estimated_output_bytes": estimated_output_bytes,
        "estimated_output_mb": round(estimated_output_bytes / (1024 * 1024), 1),
    }


def disk_space_check(target_folder: str | Path, required_bytes: int) -> dict[str, Any]:
    target_folder = Path(target_folder)
    target_folder.mkdir(parents=True, exist_ok=True)
    usage = shutil.disk_usage(target_folder)
    return {
        "total_bytes": usage.total,
        "used_bytes": usage.used,
        "free_bytes": usage.free,
        "required_bytes": int(required_bytes),
        "free_mb": round(usage.free / (1024 * 1024), 1),
        "required_mb": round(required_bytes / (1024 * 1024), 1),
        "enough": usage.free >= required_bytes,
    }


def next_version_folder(path: str | Path) -> Path:
    path = Path(path)
    if not path.exists():
        return path
    index = 2
    while True:
        candidate = path.with_name(f"{path.name}_v{index}")
        if not candidate.exists():
            return candidate
        index += 1


def backup_existing_output(path: str | Path) -> Path | None:
    path = Path(path)
    if not path.exists() or not any(path.iterdir()):
        return None
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup = path.with_name(f"{path.name}_backup_{timestamp}")
    counter = 2
    while backup.exists():
        backup = path.with_name(f"{path.name}_backup_{timestamp}_{counter}")
        counter += 1
    shutil.move(str(path), str(backup))
    path.mkdir(parents=True, exist_ok=True)
    return backup


def resolve_output_folder(path: str | Path, policy: str) -> dict[str, Any]:
    if policy not in OUTPUT_POLICIES:
        raise ValueError(f"지원하지 않는 결과 폴더 정책입니다: {policy}")

    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)

    if policy == "새 버전 폴더":
        resolved = next_version_folder(path)
        resolved.mkdir(parents=True, exist_ok=True)
        return {"output_folder": str(resolved), "backup_folder": "", "policy": policy}

    if policy == "기존 결과 백업":
        path.mkdir(parents=True, exist_ok=True)
        backup = backup_existing_output(path)
        return {
            "output_folder": str(path),
            "backup_folder": str(backup) if backup else "",
            "policy": policy,
        }

    path.mkdir(parents=True, exist_ok=True)
    if any(path.iterdir()):
        raise FileExistsError("결과 폴더가 비어 있지 않습니다.")
    return {"output_folder": str(path), "backup_folder": "", "policy": policy}


def apply_output_policy_to_jobs(
    jobs: list[dict[str, Any]],
    policy: str,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    updated = []
    changes = []
    for job in jobs:
        item = dict(job)
        original = item.get("output_folder", "")
        resolved = resolve_output_folder(original, policy)
        item["output_folder"] = resolved["output_folder"]
        item["output_policy"] = policy
        item["backup_folder"] = resolved["backup_folder"]
        updated.append(item)
        changes.append({
            "job_id": item.get("id"),
            "product_name": item.get("product_name", ""),
            "original_output": original,
            **resolved,
        })
    return updated, changes


def export_output_policy_report(
    changes: list[dict[str, Any]],
    space_check: dict[str, Any],
    path: str | Path,
) -> Path:
    report = {
        "app_version": APP_VERSION,
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "space_check": space_check,
        "changes": changes,
    }
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    return path


QUEUE_PRIORITIES = ["긴급", "높음", "보통", "낮음"]
QUEUE_PRIORITY_VALUES = {"긴급": 0, "높음": 1, "보통": 2, "낮음": 3}
QUEUE_CONTROL_FILENAME = "batch_queue_control.json"


def normalize_queue_jobs(jobs: list[dict[str, Any]]) -> list[dict[str, Any]]:
    normalized = []
    for position, job in enumerate(jobs):
        item = dict(job)
        item.setdefault("priority", "보통")
        if item["priority"] not in QUEUE_PRIORITIES:
            item["priority"] = "보통"
        item.setdefault("queue_position", position + 1)
        item.setdefault("enabled", True)
        item.setdefault("attempts", 0)
        item.setdefault("last_started_at", "")
        item.setdefault("last_finished_at", "")
        normalized.append(item)
    return normalized


def sort_queue_jobs(jobs: list[dict[str, Any]]) -> list[dict[str, Any]]:
    normalized = normalize_queue_jobs(jobs)
    sorted_jobs = sorted(
        normalized,
        key=lambda job: (
            QUEUE_PRIORITY_VALUES.get(job.get("priority", "보통"), 2),
            int(job.get("queue_position", 999999)),
            int(job.get("id", 999999)),
        ),
    )
    for index, job in enumerate(sorted_jobs, 1):
        job["queue_position"] = index
    return sorted_jobs


def set_job_priority(
    jobs: list[dict[str, Any]],
    job_ids: list[int],
    priority: str,
) -> list[dict[str, Any]]:
    if priority not in QUEUE_PRIORITIES:
        raise ValueError(f"지원하지 않는 우선순위입니다: {priority}")
    selected = {int(job_id) for job_id in job_ids}
    updated = normalize_queue_jobs(jobs)
    for job in updated:
        if int(job.get("id", -1)) in selected:
            job["priority"] = priority
    return sort_queue_jobs(updated)


def set_jobs_enabled(
    jobs: list[dict[str, Any]],
    job_ids: list[int],
    enabled: bool,
) -> list[dict[str, Any]]:
    selected = {int(job_id) for job_id in job_ids}
    updated = normalize_queue_jobs(jobs)
    for job in updated:
        if int(job.get("id", -1)) in selected:
            job["enabled"] = bool(enabled)
    return updated


def move_queue_jobs(
    jobs: list[dict[str, Any]],
    job_ids: list[int],
    direction: int,
) -> list[dict[str, Any]]:
    if direction not in {-1, 1}:
        return normalize_queue_jobs(jobs)

    queue = sorted(
        normalize_queue_jobs(jobs),
        key=lambda item: int(item.get("queue_position", 999999)),
    )
    selected = {int(job_id) for job_id in job_ids}

    if direction < 0:
        for index in range(1, len(queue)):
            current_id = int(queue[index].get("id", -1))
            previous_id = int(queue[index - 1].get("id", -1))
            if current_id in selected and previous_id not in selected:
                queue[index - 1], queue[index] = queue[index], queue[index - 1]
    else:
        for index in range(len(queue) - 2, -1, -1):
            current_id = int(queue[index].get("id", -1))
            next_id = int(queue[index + 1].get("id", -1))
            if current_id in selected and next_id not in selected:
                queue[index], queue[index + 1] = queue[index + 1], queue[index]

    for position, job in enumerate(queue, 1):
        job["queue_position"] = position
    return queue


def save_queue_control(
    paused: bool,
    stop_after_current: bool,
    path: str | Path,
) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(
            {
                "app_version": APP_VERSION,
                "saved_at": datetime.now().isoformat(timespec="seconds"),
                "paused": bool(paused),
                "stop_after_current": bool(stop_after_current),
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )
    return path


def load_queue_control(path: str | Path) -> dict[str, Any]:
    path = Path(path)
    if not path.exists():
        return {"paused": False, "stop_after_current": False}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return {
            "paused": bool(data.get("paused", False)),
            "stop_after_current": bool(data.get("stop_after_current", False)),
        }
    except Exception:
        return {"paused": False, "stop_after_current": False}


def run_queue_jobs(
    jobs: list[dict[str, Any]],
    ai_config: AIConfig | None = None,
    state_path: str | Path | None = None,
    control_path: str | Path | None = None,
    log_path: str | Path | None = None,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    queue = sort_queue_jobs(jobs)
    completed: list[dict[str, Any]] = []
    if log_path:
        append_batch_log("queue_started", None, log_path, estimate_queue_seconds(queue))
    stopped_reason = "완료"

    for index, job in enumerate(queue):
        control = load_queue_control(control_path) if control_path else {
            "paused": False,
            "stop_after_current": False,
        }
        if control["paused"]:
            if log_path:
                append_batch_log("queue_paused", None, log_path, {"remaining": len(queue[index:])})
            completed.extend(queue[index:])
            stopped_reason = "일시정지"
            break

        item = dict(job)
        if not item.get("enabled", True):
            completed.append(item)
            continue
        if item.get("status") == "성공":
            completed.append(item)
            continue

        item["attempts"] = int(item.get("attempts", 0)) + 1
        item["last_started_at"] = datetime.now().isoformat(timespec="seconds")
        if log_path:
            append_batch_log("job_started", item, log_path, {"estimate_seconds": estimate_job_seconds(item)})
        result = run_batch_job(item, ai_config=ai_config)
        result["priority"] = item.get("priority", "보통")
        result["queue_position"] = item.get("queue_position", index + 1)
        result["enabled"] = item.get("enabled", True)
        result["attempts"] = item["attempts"]
        result["last_started_at"] = item["last_started_at"]
        result["last_finished_at"] = datetime.now().isoformat(timespec="seconds")
        completed.append(result)
        if log_path:
            append_batch_log(
                "job_finished" if result.get("status") == "성공" else "job_failed",
                result,
                log_path,
                {"elapsed_seconds": job_elapsed_seconds(result), "error": result.get("error", "")},
            )

        remaining = queue[index + 1:]
        if state_path:
            save_batch_state(completed + remaining, state_path)

        control = load_queue_control(control_path) if control_path else {
            "paused": False,
            "stop_after_current": False,
        }
        if control["stop_after_current"]:
            if log_path:
                append_batch_log("queue_stop_after_current", result, log_path, {"remaining": len(remaining)})
            completed.extend(remaining)
            stopped_reason = "현재 작업 후 정지"
            break
    else:
        stopped_reason = "완료"

    if log_path:
        append_batch_log("queue_finished", None, log_path, {"reason": stopped_reason})
    return completed, {
        "reason": stopped_reason,
        "summary": batch_summary(completed),
        "remaining_count": sum(
            1 for job in completed
            if job.get("enabled", True) and job.get("status") != "성공"
        ),
    }


def queue_summary(jobs: list[dict[str, Any]]) -> dict[str, Any]:
    normalized = normalize_queue_jobs(jobs)
    priority_counts = {priority: 0 for priority in QUEUE_PRIORITIES}
    enabled_count = 0
    disabled_count = 0

    for job in normalized:
        priority_counts[job["priority"]] += 1
        if job.get("enabled", True):
            enabled_count += 1
        else:
            disabled_count += 1

    return {
        "total": len(normalized),
        "enabled_count": enabled_count,
        "disabled_count": disabled_count,
        "priority_counts": priority_counts,
        "status": batch_summary(normalized),
    }


def export_queue_report(
    jobs: list[dict[str, Any]],
    path: str | Path,
) -> Path:
    ordered = sort_queue_jobs(jobs)
    report = {
        "app_version": APP_VERSION,
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "summary": queue_summary(ordered),
        "jobs": ordered,
    }
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    return path


BATCH_LOG_FILENAME = "batch_progress_log.jsonl"


def parse_iso_datetime(value: str) -> datetime | None:
    if not value:
        return None
    try:
        return datetime.fromisoformat(value)
    except Exception:
        return None


def job_elapsed_seconds(job: dict[str, Any]) -> float:
    started = parse_iso_datetime(str(job.get("last_started_at", "")))
    finished = parse_iso_datetime(str(job.get("last_finished_at", "")))
    if not started or not finished:
        return 0.0
    return max(0.0, (finished - started).total_seconds())


def estimate_job_seconds(job: dict[str, Any]) -> float:
    image_count = 0
    folder = Path(job.get("folder", ""))
    if folder.exists():
        try:
            image_count = scan_image_folder(folder)["unique_count"]
        except Exception:
            image_count = 0
    cut_count = int(job.get("cut_count", 8) or 8)
    attempts = int(job.get("attempts", 0) or 0)

    estimate = 8.0 + image_count * 2.5 + cut_count * 1.8
    if attempts:
        estimate += min(30.0, attempts * 4.0)
    return round(estimate, 1)


def estimate_queue_seconds(jobs: list[dict[str, Any]]) -> dict[str, Any]:
    enabled = [
        job for job in normalize_queue_jobs(jobs)
        if job.get("enabled", True) and job.get("status") != "성공"
    ]
    estimates = [
        {
            "job_id": job.get("id"),
            "product_name": job.get("product_name", ""),
            "seconds": estimate_job_seconds(job),
        }
        for job in enabled
    ]
    total = round(sum(item["seconds"] for item in estimates), 1)
    return {
        "job_count": len(enabled),
        "estimated_seconds": total,
        "estimated_minutes": round(total / 60, 1),
        "jobs": estimates,
    }


def append_batch_log(
    event: str,
    job: dict[str, Any] | None,
    path: str | Path,
    details: dict[str, Any] | None = None,
) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "app_version": APP_VERSION,
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "event": event,
        "job_id": job.get("id") if job else None,
        "product_name": job.get("product_name", "") if job else "",
        "status": job.get("status", "") if job else "",
        "details": details or {},
    }
    with path.open("a", encoding="utf-8") as file:
        file.write(json.dumps(payload, ensure_ascii=False) + "\n")
    return path


def load_batch_logs(path: str | Path) -> list[dict[str, Any]]:
    path = Path(path)
    if not path.exists():
        return []
    logs = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        try:
            item = json.loads(line)
            if isinstance(item, dict):
                logs.append(item)
        except Exception:
            continue
    return logs


def batch_performance_summary(
    jobs: list[dict[str, Any]],
    logs: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    elapsed = []
    failures = []
    for job in jobs:
        seconds = job_elapsed_seconds(job)
        if seconds:
            elapsed.append({
                "job_id": job.get("id"),
                "product_name": job.get("product_name", ""),
                "seconds": round(seconds, 2),
                "attempts": int(job.get("attempts", 0) or 0),
            })
        if job.get("status") == "실패":
            failures.append({
                "job_id": job.get("id"),
                "product_name": job.get("product_name", ""),
                "error": job.get("error", ""),
                "attempts": int(job.get("attempts", 0) or 0),
            })

    slowest = sorted(elapsed, key=lambda item: item["seconds"], reverse=True)[:5]
    average = round(
        sum(item["seconds"] for item in elapsed) / len(elapsed),
        2,
    ) if elapsed else 0.0

    event_counts = {}
    for log in logs or []:
        event = str(log.get("event", ""))
        event_counts[event] = event_counts.get(event, 0) + 1

    return {
        "completed_count": len(elapsed),
        "average_seconds": average,
        "slowest_jobs": slowest,
        "failure_count": len(failures),
        "failures": failures,
        "event_counts": event_counts,
    }


def export_batch_performance_report(
    jobs: list[dict[str, Any]],
    log_path: str | Path,
    output_path: str | Path,
) -> Path:
    logs = load_batch_logs(log_path)
    report = {
        "app_version": APP_VERSION,
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "queue_estimate": estimate_queue_seconds(jobs),
        "performance": batch_performance_summary(jobs, logs),
        "logs": logs,
    }
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(
        json.dumps(report, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return output_path


CHECKPOINT_FILENAME = "cut_checkpoint.json"


def file_sha256(path: str | Path, chunk_size: int = 1024 * 1024) -> str:
    import hashlib
    digest = hashlib.sha256()
    with Path(path).open("rb") as file:
        while True:
            chunk = file.read(chunk_size)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def validate_png_file(path: str | Path) -> dict[str, Any]:
    path = Path(path)
    if not path.exists():
        return {"valid": False, "reason": "파일 없음", "path": str(path)}
    try:
        with Image.open(path) as image:
            image.verify()
        with Image.open(path) as image:
            width, height = image.size
        return {
            "valid": True,
            "reason": "",
            "path": str(path),
            "width": width,
            "height": height,
            "sha256": file_sha256(path),
            "size": path.stat().st_size,
        }
    except Exception as error:
        return {"valid": False, "reason": str(error), "path": str(path)}


def save_cut_checkpoint(data: dict[str, Any], path: str | Path) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = dict(data)
    payload["app_version"] = APP_VERSION
    payload["saved_at"] = datetime.now().isoformat(timespec="seconds")
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    temporary.replace(path)
    return path


def load_cut_checkpoint(path: str | Path) -> dict[str, Any]:
    path = Path(path)
    if not path.exists():
        return {"cuts": [], "app_version": APP_VERSION}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            raise ValueError("체크포인트 형식 오류")
        data.setdefault("cuts", [])
        return data
    except Exception:
        return {"cuts": [], "app_version": APP_VERSION, "corrupted": True}


def inspect_cut_checkpoint(output_folder: str | Path, cut_count: int) -> dict[str, Any]:
    output_folder = Path(output_folder)
    checkpoint_path = output_folder / CHECKPOINT_FILENAME
    checkpoint = load_cut_checkpoint(checkpoint_path)
    by_index = {
        int(item.get("index", 0)): item
        for item in checkpoint.get("cuts", [])
        if int(item.get("index", 0)) > 0
    }
    valid, missing, damaged = [], [], []

    for index in range(1, int(cut_count) + 1):
        item = by_index.get(index)
        if not item:
            missing.append(index)
            continue
        path = Path(item.get("path", ""))
        result = validate_png_file(path)
        if not result["valid"]:
            damaged.append(index)
            continue
        expected_hash = item.get("sha256", "")
        if expected_hash and result["sha256"] != expected_hash:
            damaged.append(index)
            continue
        valid.append(index)

    return {
        "checkpoint": str(checkpoint_path),
        "valid": valid,
        "missing": missing,
        "damaged": damaged,
        "valid_count": len(valid),
        "missing_count": len(missing),
        "damaged_count": len(damaged),
        "complete": len(valid) == int(cut_count),
        "corrupted_checkpoint": bool(checkpoint.get("corrupted", False)),
    }


def export_project_with_checkpoint(
    project: Project,
    output_folder: str | Path,
) -> dict[str, Any]:
    output_folder = Path(output_folder)
    output_folder.mkdir(parents=True, exist_ok=True)
    png_folder = output_folder / "checkpoint_png"
    png_folder.mkdir(parents=True, exist_ok=True)
    checkpoint_path = output_folder / CHECKPOINT_FILENAME
    checkpoint = load_cut_checkpoint(checkpoint_path)

    old_items = {
        int(item.get("index", 0)): item
        for item in checkpoint.get("cuts", [])
        if int(item.get("index", 0)) > 0
    }
    new_items = []
    reused = 0
    regenerated = 0

    for index, cut in enumerate(project.cuts, 1):
        filename = f"{index:02d}_{sanitize_name(cut.title)}.png"
        path = png_folder / filename
        old = old_items.get(index)
        can_reuse = False

        if old and Path(old.get("path", "")) == path:
            validation = validate_png_file(path)
            can_reuse = (
                validation["valid"]
                and validation.get("sha256") == old.get("sha256")
            )

        if can_reuse:
            reused += 1
            validation = validate_png_file(path)
        else:
            if not 0 <= cut.photo_index < len(project.images):
                raise ValueError(f"{index}번 컷의 사진 연결이 잘못되었습니다.")
            rendered = render_cut(
                project.images[cut.photo_index],
                index - 1,
                cut,
                project.style,
                project.layout,
                project.custom_background,
            )
            temporary = path.with_suffix(".tmp.png")
            rendered.save(temporary, format="PNG")
            temporary.replace(path)
            validation = validate_png_file(path)
            if not validation["valid"]:
                raise ValueError(f"{index}번 컷 저장 검증 실패: {validation['reason']}")
            regenerated += 1

        new_items.append({
            "index": index,
            "title": cut.title,
            "path": str(path),
            "sha256": validation["sha256"],
            "size": validation["size"],
            "width": validation["width"],
            "height": validation["height"],
        })
        save_cut_checkpoint(
            {
                "product": project.fields.get("product", ""),
                "cut_count": len(project.cuts),
                "cuts": new_items,
            },
            checkpoint_path,
        )

    inspection = inspect_cut_checkpoint(output_folder, len(project.cuts))
    report = {
        "app_version": APP_VERSION,
        "completed_at": datetime.now().isoformat(timespec="seconds"),
        "product": project.fields.get("product", ""),
        "cut_count": len(project.cuts),
        "reused_count": reused,
        "regenerated_count": regenerated,
        "inspection": inspection,
        "checkpoint": str(checkpoint_path),
        "png_folder": str(png_folder),
    }
    report_path = output_folder / "checkpoint_report.json"
    report_path.write_text(
        json.dumps(report, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    report["report"] = str(report_path)
    return report


def repair_cut_checkpoint(output_folder: str | Path, cut_count: int) -> dict[str, Any]:
    output_folder = Path(output_folder)
    checkpoint_path = output_folder / CHECKPOINT_FILENAME
    checkpoint = load_cut_checkpoint(checkpoint_path)
    valid_items = []
    removed = []

    for item in checkpoint.get("cuts", []):
        index = int(item.get("index", 0))
        if not 1 <= index <= int(cut_count):
            removed.append(index)
            continue
        validation = validate_png_file(item.get("path", ""))
        if not validation["valid"]:
            removed.append(index)
            continue
        if item.get("sha256") and item["sha256"] != validation["sha256"]:
            removed.append(index)
            continue
        valid_items.append(item)

    save_cut_checkpoint(
        {
            "product": checkpoint.get("product", ""),
            "cut_count": int(cut_count),
            "cuts": valid_items,
        },
        checkpoint_path,
    )
    return {
        "kept_count": len(valid_items),
        "removed_count": len(removed),
        "removed_indices": removed,
        "inspection": inspect_cut_checkpoint(output_folder, cut_count),
    }


AI_ENGINE_VERSION = "5.0"
PRODUCT_CATEGORY_RULES = {
    "농산물": ["옥수수", "양파", "감자", "고구마", "단호박", "호박", "마늘", "배추", "무", "고추", "채소"],
    "과일": ["무화과", "사과", "배", "복숭아", "포도", "귤", "감귤", "한라봉", "천혜향", "과일"],
    "수산물": ["홍어", "전복", "굴", "새우", "생선", "오징어", "낙지", "문어", "수산"],
    "수산가공식품": ["김", "액젓", "젓갈", "멸치", "다시마", "미역", "해조"],
    "축산물": ["한우", "소고기", "돼지고기", "닭고기", "오리", "축산"],
    "가공식품": ["건무화과", "분말", "가루", "즙", "청", "소스", "장아찌", "가공"],
}

CATEGORY_STYLE_RECOMMENDATIONS = {
    "농산물": {"style": "감성", "layout": "균형형", "tone": "산지직송·신선함"},
    "과일": {"style": "프리미엄", "layout": "사진 크게", "tone": "당도·과육·선별"},
    "수산물": {"style": "홈쇼핑", "layout": "사진 크게", "tone": "신선도·원산지·손질"},
    "수산가공식품": {"style": "홈쇼핑", "layout": "균형형", "tone": "감칠맛·전통·활용"},
    "축산물": {"style": "프리미엄", "layout": "사진 크게", "tone": "육질·선별·포장"},
    "가공식품": {"style": "프리미엄", "layout": "균형형", "tone": "원재료·제조·활용"},
    "식품": {"style": "프리미엄", "layout": "균형형", "tone": "품질·활용·신뢰"},
}


def _average_rgb(path: str | Path, sample_size: int = 80) -> tuple[int, int, int]:
    with Image.open(path) as image:
        image = image.convert("RGB")
        image.thumbnail((sample_size, sample_size), Image.Resampling.LANCZOS)
        stat = ImageStat.Stat(image)
        return tuple(int(value) for value in stat.mean[:3])


def _rgb_to_hex(rgb: tuple[int, int, int]) -> str:
    return "#" + "".join(f"{max(0, min(255, value)):02X}" for value in rgb)


def _color_name(rgb: tuple[int, int, int]) -> str:
    red, green, blue = rgb
    maximum = max(rgb)
    minimum = min(rgb)
    if maximum - minimum < 18:
        return "뉴트럴"
    if red > green * 1.25 and red > blue * 1.25:
        return "레드"
    if green > red * 1.18 and green > blue * 1.12:
        return "그린"
    if blue > red * 1.18 and blue > green * 1.08:
        return "블루"
    if red > 150 and green > 110 and blue < 100:
        return "골드·옐로"
    if red > 130 and blue > 105 and green < 125:
        return "퍼플"
    if red > 145 and green > 100 and blue > 75:
        return "웜 브라운"
    return "내추럴"


def analyze_image_visual_features(path: str | Path) -> dict[str, Any]:
    path = Path(path)
    metrics = image_metrics(path)
    average_rgb = _average_rgb(path)
    width = int(metrics["width"])
    height = int(metrics["height"])
    orientation = "정사각형"
    if width > height * 1.08:
        orientation = "가로"
    elif height > width * 1.08:
        orientation = "세로"

    area = width * height
    resolution_score = min(100, round(area / 2_000_000 * 100))
    brightness = float(metrics["brightness"])
    brightness_label = "밝음" if brightness >= 165 else "보통" if brightness >= 95 else "어두움"
    filename_role = classify_image_filename(path) if "classify_image_filename" in globals() else {
        "role": "일반", "matched_roles": {}
    }

    return {
        "path": str(path),
        "filename": path.name,
        "width": width,
        "height": height,
        "orientation": orientation,
        "brightness": round(brightness, 1),
        "brightness_label": brightness_label,
        "average_rgb": list(average_rgb),
        "average_hex": _rgb_to_hex(average_rgb),
        "color_family": _color_name(average_rgb),
        "resolution_score": resolution_score,
        "filename_role": filename_role.get("role", "일반"),
        "role_matches": filename_role.get("matched_roles", {}),
    }


def infer_category_and_product(
    image_paths: list[str],
    existing_fields: dict[str, str] | None = None,
) -> dict[str, Any]:
    fields = existing_fields or {}
    provided_product = fields.get("product", "").strip()
    provided_category = fields.get("category", "").strip()

    combined_name = " ".join(Path(path).stem.lower() for path in image_paths)
    candidates = []
    for category, keywords in PRODUCT_CATEGORY_RULES.items():
        matched = [keyword for keyword in keywords if keyword.lower() in combined_name]
        if matched:
            candidates.append({
                "category": category,
                "score": len(matched) * 20,
                "matched_keywords": matched,
            })

    candidates.sort(key=lambda item: item["score"], reverse=True)
    category = provided_category or (candidates[0]["category"] if candidates else "식품")

    product = provided_product
    if not product:
        best_tokens = []
        for category_keywords in PRODUCT_CATEGORY_RULES.values():
            for keyword in category_keywords:
                if keyword.lower() in combined_name:
                    best_tokens.append(keyword)
        if best_tokens:
            product = max(best_tokens, key=len)
        else:
            product = infer_product_name_from_folder(Path(image_paths[0]).parent) if image_paths else ""
        product = product or "상품명 확인 필요"

    confidence = 0.95 if provided_product and provided_category else 0.78 if candidates else 0.38
    return {
        "product": product,
        "category": category,
        "confidence": confidence,
        "candidates": candidates[:3],
    }


def score_hero_image(feature: dict[str, Any], index: int) -> float:
    score = 0.0
    score += feature["resolution_score"] * 0.45
    score += max(0, 30 - abs(feature["brightness"] - 145) * 0.18)
    if feature["orientation"] in {"가로", "정사각형"}:
        score += 12
    role = feature.get("filename_role", "일반")
    role_bonus = {"대표": 35, "구성": 18, "단면": 12, "일반": 5}.get(role, 0)
    score += role_bonus
    score -= index * 0.35
    return round(score, 2)


def recommend_visual_identity(
    features: list[dict[str, Any]],
    category: str,
) -> dict[str, Any]:
    if features:
        average = tuple(
            round(sum(item["average_rgb"][channel] for item in features) / len(features))
            for channel in range(3)
        )
    else:
        average = (180, 160, 130)

    red, green, blue = average
    accent = (
        min(220, max(45, int(red * 0.72))),
        min(200, max(45, int(green * 0.72))),
        min(180, max(45, int(blue * 0.72))),
    )
    background = (
        min(252, int(red * 0.18 + 220)),
        min(252, int(green * 0.18 + 220)),
        min(252, int(blue * 0.18 + 220)),
    )

    recommendation = CATEGORY_STYLE_RECOMMENDATIONS.get(
        category,
        CATEGORY_STYLE_RECOMMENDATIONS["식품"],
    )
    return {
        "style": recommendation["style"],
        "layout": recommendation["layout"],
        "tone": recommendation["tone"],
        "dominant_color": _rgb_to_hex(average),
        "accent_color": _rgb_to_hex(accent),
        "background_color": _rgb_to_hex(background),
        "color_family": _color_name(average),
        "font_recommendation": (
            "굵은 고딕 + 본문 고딕"
            if recommendation["style"] == "홈쇼핑"
            else "명조형 제목 + 깔끔한 고딕 본문"
            if recommendation["style"] == "감성"
            else "세미볼드 고딕 + 가독성 높은 고딕"
        ),
    }


def generate_v5_copy(
    product: str,
    category: str,
    origin: str,
    visual: dict[str, Any],
    existing_fields: dict[str, str],
) -> dict[str, Any]:
    feature1 = existing_fields.get("feature1", "").strip()
    feature2 = existing_fields.get("feature2", "").strip()

    defaults = {
        "농산물": ("산지에서 신선하게", "꼼꼼하게 선별한 품질"),
        "과일": ("눈으로 확인하는 신선함", "맛과 식감을 살린 선별"),
        "수산물": ("신선도를 먼저 생각한 상품", "안전한 포장과 빠른 발송"),
        "수산가공식품": ("깊은 맛과 풍부한 감칠맛", "다양한 요리에 편리하게"),
        "축산물": ("선별한 육질과 신선함", "꼼꼼한 포장과 냉장·냉동 배송"),
        "가공식품": ("원재료의 장점을 담은 제품", "간편하게 즐기는 활용성"),
        "식품": ("믿고 선택하는 품질", "일상에서 편리하게 활용"),
    }
    default_features = defaults.get(category, defaults["식품"])
    feature1 = feature1 or default_features[0]
    feature2 = feature2 or default_features[1]

    origin_prefix = "" if not origin or "확인 필요" in origin else f"{origin} "
    recommended_name = f"{origin_prefix}{product} {feature1}".strip()

    headlines = [
        f"한눈에 확인하는 {product}의 매력",
        f"{feature1}, 제대로 준비한 {product}",
        f"맛과 품질을 생각한 {product}",
    ]
    selling_points = [
        feature1,
        feature2,
        visual.get("tone", "품질과 신뢰"),
        "상품 특성에 맞춘 꼼꼼한 포장",
    ]
    keywords = list(dict.fromkeys([
        product,
        f"{origin_prefix}{product}".strip(),
        f"{product} 추천",
        f"{product} 산지직송",
        f"{product} 선물",
        category,
    ]))

    return {
        "recommended_product_name": recommended_name[:100],
        "main_copy": headlines[0],
        "alternate_headlines": headlines[1:],
        "selling_points": selling_points,
        "search_keywords": [keyword for keyword in keywords if keyword],
        "feature1": feature1,
        "feature2": feature2,
        "cta": f"지금 {product}을 확인해 보세요",
    }


def v5_analyze_product(
    image_paths: list[str],
    existing_fields: dict[str, str] | None = None,
) -> dict[str, Any]:
    existing_fields = dict(existing_fields or {})
    valid_paths = [str(Path(path)) for path in image_paths if Path(path).exists()]
    if not valid_paths:
        raise ValueError("분석할 상품 사진이 없습니다.")

    features = [analyze_image_visual_features(path) for path in valid_paths]
    identity = infer_category_and_product(valid_paths, existing_fields)
    visual = recommend_visual_identity(features, identity["category"])

    hero_candidates = []
    for index, feature in enumerate(features):
        hero_candidates.append({
            "image_index": index,
            "path": feature["path"],
            "filename": feature["filename"],
            "score": score_hero_image(feature, index),
            "reason": (
                f"{feature['filename_role']} 역할, "
                f"{feature['orientation']} 구도, "
                f"해상도 {feature['resolution_score']}점"
            ),
        })
    hero_candidates.sort(key=lambda item: item["score"], reverse=True)
    hero_index = hero_candidates[0]["image_index"]

    origin = existing_fields.get("origin", "").strip() or "원산지 확인 필요"
    copy_result = generate_v5_copy(
        identity["product"],
        identity["category"],
        origin,
        visual,
        existing_fields,
    )

    fields = {
        "product": identity["product"],
        "category": identity["category"],
        "origin": origin,
        "feature1": copy_result["feature1"],
        "feature2": copy_result["feature2"],
        "shipping": existing_fields.get("shipping", "").strip() or "배송정보 확인 필요",
    }

    warnings = []
    if identity["confidence"] < 0.6:
        warnings.append("상품 분류 신뢰도가 낮습니다. 상품명과 품목을 확인하세요.")
    if "확인 필요" in fields["origin"]:
        warnings.append("원산지는 사진만으로 판단하지 않았습니다.")
    if "확인 필요" in fields["shipping"]:
        warnings.append("배송정보를 직접 입력하세요.")
    if any(item["resolution_score"] < 45 for item in features):
        warnings.append("저해상도 사진이 포함되어 있습니다.")

    return {
        "engine": "nongjak-v5",
        "engine_version": AI_ENGINE_VERSION,
        "provider": "offline-v5",
        "confidence": identity["confidence"],
        "fields": fields,
        "classification": identity,
        "visual_identity": visual,
        "copy": copy_result,
        "hero_image": {
            "selected_index": hero_index,
            "selected_path": valid_paths[hero_index],
            "candidates": hero_candidates,
        },
        "images": features,
        "warnings": warnings,
    }


def apply_v5_analysis_to_project(
    project: Project,
    analysis: dict[str, Any],
    overwrite_fields: bool = False,
) -> Project:
    project.fields = apply_analysis_fields(
        project.fields,
        analysis,
        overwrite=overwrite_fields,
    )
    visual = analysis.get("visual_identity", {})
    project.style = visual.get("style", project.style)
    project.layout = visual.get("layout", project.layout)
    project.ai_analysis = analysis

    hero_index = int(analysis.get("hero_image", {}).get("selected_index", 0))
    if project.cuts and project.images and 0 <= hero_index < len(project.images):
        project.cuts[0].photo_index = hero_index

    copy_result = analysis.get("copy", {})
    if project.cuts:
        project.cuts[0].title = copy_result.get(
            "main_copy",
            project.cuts[0].title,
        )
        project.cuts[0].body = copy_result.get(
            "recommended_product_name",
            project.cuts[0].body,
        )

    if len(project.cuts) > 1:
        selling_points = copy_result.get("selling_points", [])
        for index, point in enumerate(selling_points[: min(4, len(project.cuts) - 1)], 1):
            project.cuts[index].body = point

    return project


def build_v5_project(
    fields: dict[str, str],
    image_paths: list[str],
    cut_count: int = 8,
) -> tuple[Project, dict[str, Any]]:
    analysis = v5_analyze_product(image_paths, fields)
    merged_fields = apply_analysis_fields(fields, analysis, overwrite=False)
    project = Project(
        fields=merged_fields,
        images=list(image_paths),
        cuts=build_cuts(merged_fields, cut_count),
        ai_analysis=analysis,
    )
    apply_v5_analysis_to_project(project, analysis, overwrite_fields=False)
    apply_story_flow(project, overwrite_titles=False, reorder=False)
    auto_assign_cut_layouts(project)
    apply_recommended_images(project, avoid_duplicates=True)
    return project, {
        "analysis": analysis,
        "quality": score_project_quality(project),
        "story_quality": analyze_story_flow(project),
        "image_usage": analyze_image_usage(project),
    }


def export_v5_analysis_report(
    analysis: dict[str, Any],
    path: str | Path,
) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(analysis, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return path


SALES_STRATEGY_ENGINE_VERSION = "5.1"

CHANNEL_TITLE_LIMITS = {
    "스마트스토어": 100,
    "쿠팡": 100,
    "일반 쇼핑몰": 120,
}

THUMBNAIL_STYLES = {
    "스마트스토어": [
        {"name": "깔끔형", "max_words": 8, "tone": "핵심 장점 중심"},
        {"name": "산지형", "max_words": 10, "tone": "원산지·신선함 중심"},
        {"name": "프리미엄형", "max_words": 8, "tone": "품질·선별 중심"},
    ],
    "쿠팡": [
        {"name": "직관형", "max_words": 7, "tone": "상품명·핵심 특징 중심"},
        {"name": "구성형", "max_words": 9, "tone": "구성·활용 중심"},
        {"name": "신뢰형", "max_words": 8, "tone": "품질·배송 중심"},
    ],
    "일반 쇼핑몰": [
        {"name": "브랜드형", "max_words": 10, "tone": "감성·스토리 중심"},
        {"name": "혜택형", "max_words": 9, "tone": "장점·구매 이유 중심"},
        {"name": "비주얼형", "max_words": 7, "tone": "짧고 강한 문구"},
    ],
}


def _clean_keyword(value: str) -> str:
    return " ".join(str(value or "").replace(",", " ").split()).strip()


def _unique_terms(values: list[str]) -> list[str]:
    result = []
    seen = set()
    for value in values:
        value = _clean_keyword(value)
        key = value.lower()
        if value and key not in seen:
            seen.add(key)
            result.append(value)
    return result


def generate_channel_product_titles(
    fields: dict[str, str],
    analysis: dict[str, Any] | None = None,
    channel: str = "스마트스토어",
) -> list[dict[str, Any]]:
    analysis = analysis or {}
    copy_result = analysis.get("copy", {})
    product = _clean_keyword(fields.get("product", "")) or "상품명"
    category = _clean_keyword(fields.get("category", ""))
    origin = _clean_keyword(fields.get("origin", ""))
    feature1 = _clean_keyword(fields.get("feature1", "")) or _clean_keyword(copy_result.get("feature1", ""))
    feature2 = _clean_keyword(fields.get("feature2", "")) or _clean_keyword(copy_result.get("feature2", ""))

    excluded = {"확인 필요", "원산지 확인 필요", "배송정보 확인 필요"}
    origin = "" if origin in excluded or "확인 필요" in origin else origin
    terms = _unique_terms([origin, product, feature1, feature2, category])

    patterns = [
        [origin, product, feature1],
        [product, feature1, feature2],
        [origin, product, feature2],
        [product, category, feature1],
        [product, feature1],
    ]

    limit = CHANNEL_TITLE_LIMITS.get(channel, 100)
    candidates = []
    for pattern in patterns:
        title = " ".join(_unique_terms([item for item in pattern if item]))
        if not title:
            continue
        title = title[:limit].strip()
        score = 50
        score += 18 if product and product in title else 0
        score += 10 if origin and origin in title else 0
        score += 10 if feature1 and feature1 in title else 0
        score += 7 if feature2 and feature2 in title else 0
        score += 5 if len(title) <= 45 else 0
        score -= max(0, len(title) - 70) // 5
        candidates.append({
            "title": title,
            "score": max(0, min(100, score)),
            "length": len(title),
            "channel": channel,
            "terms": [term for term in terms if term in title],
        })

    deduplicated = {}
    for item in candidates:
        existing = deduplicated.get(item["title"])
        if not existing or item["score"] > existing["score"]:
            deduplicated[item["title"]] = item
    return sorted(deduplicated.values(), key=lambda item: item["score"], reverse=True)


def score_sales_strategy(project: Project) -> dict[str, Any]:
    fields = project.fields
    quality = score_project_quality(project)
    story = analyze_story_flow(project)
    image_usage = analyze_image_usage(project)

    dimensions = {
        "상품정보": 100,
        "메시지": 100,
        "시각구성": 100,
        "구매흐름": 100,
        "모바일가독성": 100,
    }
    deductions = []

    required = {
        "product": ("상품정보", 24, "상품명이 없습니다."),
        "category": ("상품정보", 18, "품목이 없습니다."),
        "origin": ("상품정보", 14, "원산지가 없습니다."),
        "feature1": ("메시지", 18, "핵심 특징 1이 없습니다."),
        "feature2": ("메시지", 14, "핵심 특징 2가 없습니다."),
        "shipping": ("상품정보", 10, "배송정보가 없습니다."),
    }
    for key, (dimension, points, reason) in required.items():
        value = str(fields.get(key, "") or "").strip()
        if not value or "확인 필요" in value:
            dimensions[dimension] -= points
            deductions.append({"dimension": dimension, "points": points, "reason": reason})

    if len(project.cuts) < 6:
        dimensions["구매흐름"] -= 22
        deductions.append({"dimension": "구매흐름", "points": 22, "reason": "판매 설득에 필요한 컷 수가 부족합니다."})
    elif len(project.cuts) > 10:
        dimensions["모바일가독성"] -= 12
        deductions.append({"dimension": "모바일가독성", "points": 12, "reason": "상세페이지가 지나치게 길 수 있습니다."})

    short_titles = sum(1 for cut in project.cuts if len(cut.title.strip()) < 4)
    long_bodies = sum(1 for cut in project.cuts if len(cut.body.strip()) > 90)
    repeated_titles = len(project.cuts) - len({cut.title.strip().lower() for cut in project.cuts})

    if short_titles:
        penalty = min(24, short_titles * 6)
        dimensions["메시지"] -= penalty
        deductions.append({"dimension": "메시지", "points": penalty, "reason": f"의미가 약한 짧은 컷 제목이 {short_titles}개 있습니다."})
    if long_bodies:
        penalty = min(24, long_bodies * 6)
        dimensions["모바일가독성"] -= penalty
        deductions.append({"dimension": "모바일가독성", "points": penalty, "reason": f"모바일에서 긴 본문이 {long_bodies}개 있습니다."})
    if repeated_titles:
        penalty = min(20, repeated_titles * 5)
        dimensions["메시지"] -= penalty
        deductions.append({"dimension": "메시지", "points": penalty, "reason": "비슷한 컷 제목이 반복됩니다."})

    dimensions["시각구성"] = min(dimensions["시각구성"], image_usage["score"])
    dimensions["구매흐름"] = min(dimensions["구매흐름"], story["score"])
    dimensions["모바일가독성"] = min(dimensions["모바일가독성"], quality["score"])

    dimensions = {key: max(0, round(value)) for key, value in dimensions.items()}
    total = round(sum(dimensions.values()) / len(dimensions))

    grade = "A" if total >= 90 else "B" if total >= 80 else "C" if total >= 70 else "D" if total >= 60 else "F"
    return {
        "score": total,
        "grade": grade,
        "dimensions": dimensions,
        "deductions": deductions,
        "base_quality": quality["score"],
        "story_score": story["score"],
        "image_score": image_usage["score"],
    }


def recommend_cut_improvements(project: Project) -> list[dict[str, Any]]:
    recommendations = []
    expected = get_story_flow(project.fields.get("category", ""), len(project.cuts))

    for index, cut in enumerate(project.cuts):
        issues = []
        priority = 0
        expected_item = expected[index] if index < len(expected) else {"stage": "", "title": ""}

        if len(cut.title.strip()) < 4:
            issues.append("제목을 상품 장점이 드러나는 문장으로 보강")
            priority += 20
        if len(cut.body.strip()) < 12:
            issues.append("본문에 구체적인 구매 이유 추가")
            priority += 18
        if len(cut.body.strip()) > 90:
            issues.append("본문을 두 문장 이내로 축약")
            priority += 16
        if getattr(cut, "story_stage", "") != expected_item.get("stage"):
            issues.append(f"스토리 역할을 ‘{expected_item.get('stage','')}’ 단계에 맞게 조정")
            priority += 12
        if getattr(cut, "layout_variant", "기본 카드형") == "기본 카드형" and index in {0, len(project.cuts) - 1}:
            issues.append("첫·마지막 컷에 강조형 레이아웃 적용")
            priority += 10
        if getattr(cut, "review_status", "검수 전") == "수정 필요":
            issues.append("기존 검수 메모 반영")
            priority += 25
        if not cut.approved:
            priority += 4

        if issues:
            recommendations.append({
                "cut_index": index,
                "cut_number": index + 1,
                "title": cut.title,
                "priority": min(100, priority),
                "issues": issues,
                "recommended_title": expected_item.get("title") or cut.title,
                "recommended_stage": expected_item.get("stage", ""),
                "recommended_layout": recommend_cut_layout(
                    expected_item.get("title") or cut.title,
                    index,
                ),
            })

    return sorted(recommendations, key=lambda item: item["priority"], reverse=True)


def generate_thumbnail_concepts(
    project: Project,
    channel: str = "스마트스토어",
) -> list[dict[str, Any]]:
    fields = project.fields
    analysis = project.ai_analysis or {}
    copy_result = analysis.get("copy", {})
    visual = analysis.get("visual_identity", {})

    product = _clean_keyword(fields.get("product", "")) or "상품명"
    origin = _clean_keyword(fields.get("origin", ""))
    feature1 = _clean_keyword(fields.get("feature1", "")) or _clean_keyword(copy_result.get("feature1", ""))
    feature2 = _clean_keyword(fields.get("feature2", "")) or _clean_keyword(copy_result.get("feature2", ""))
    origin = "" if "확인 필요" in origin else origin

    phrases = [
        f"{origin} {product}\n{feature1}".strip(),
        f"{product}\n{feature2}".strip(),
        f"{feature1}\n{product}".strip(),
    ]
    styles = THUMBNAIL_STYLES.get(channel, THUMBNAIL_STYLES["일반 쇼핑몰"])
    concepts = []
    for index, style in enumerate(styles):
        phrase = phrases[index % len(phrases)]
        words = phrase.replace("\n", " ").split()
        if len(words) > style["max_words"]:
            phrase = " ".join(words[: style["max_words"]])
        concepts.append({
            "name": style["name"],
            "channel": channel,
            "headline": phrase,
            "subcopy": copy_result.get("cta", f"지금 {product}을 확인하세요"),
            "tone": style["tone"],
            "background_color": visual.get("background_color", "#F4EFE7"),
            "accent_color": visual.get("accent_color", "#6B4D32"),
            "recommended_image_index": int(
                analysis.get("hero_image", {}).get("selected_index", 0)
            ),
            "layout": (
                "상품 중앙 + 상단 짧은 문구"
                if index == 0
                else "상품 우측 + 좌측 장점 문구"
                if index == 1
                else "상품 크게 + 하단 신뢰 문구"
            ),
        })
    return concepts


def build_sales_strategy(
    project: Project,
    channel: str = "스마트스토어",
) -> dict[str, Any]:
    titles = generate_channel_product_titles(
        project.fields,
        project.ai_analysis,
        channel,
    )
    strategy_score = score_sales_strategy(project)
    improvements = recommend_cut_improvements(project)
    thumbnails = generate_thumbnail_concepts(project, channel)

    top_actions = []
    for deduction in strategy_score["deductions"][:4]:
        top_actions.append(deduction["reason"])
    for item in improvements[:3]:
        top_actions.append(f"{item['cut_number']}컷: {item['issues'][0]}")
    top_actions = _unique_terms(top_actions)[:6]

    return {
        "engine": "nongjak-sales-strategy",
        "engine_version": SALES_STRATEGY_ENGINE_VERSION,
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "channel": channel,
        "product": project.fields.get("product", ""),
        "strategy_score": strategy_score,
        "product_titles": titles,
        "thumbnail_concepts": thumbnails,
        "cut_improvements": improvements,
        "top_actions": top_actions,
        "limitations": [
            "외부 쇼핑몰의 실시간 경쟁상품 데이터는 포함하지 않습니다.",
            "원산지·인증·효능·배송 조건은 실제 상품정보로 검수해야 합니다.",
            "점수는 상세페이지 구조와 입력정보를 기준으로 한 내부 진단값입니다.",
        ],
    }


def apply_sales_strategy(
    project: Project,
    strategy: dict[str, Any],
    apply_best_title: bool = True,
    apply_cut_recommendations: bool = False,
) -> Project:
    if apply_best_title and strategy.get("product_titles"):
        project.fields["optimized_product_name"] = strategy["product_titles"][0]["title"]

    if apply_cut_recommendations:
        by_index = {
            int(item["cut_index"]): item
            for item in strategy.get("cut_improvements", [])
        }
        for index, cut in enumerate(project.cuts):
            recommendation = by_index.get(index)
            if not recommendation:
                continue
            cut.title = recommendation.get("recommended_title") or cut.title
            cut.story_stage = recommendation.get("recommended_stage") or cut.story_stage
            cut.layout_variant = recommendation.get("recommended_layout") or cut.layout_variant

    return project


def export_sales_strategy_report(
    strategy: dict[str, Any],
    path: str | Path,
) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(strategy, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return path


REGISTRATION_PACKAGE_VERSION = "5.3"
REGISTRATION_CHANNELS = ["스마트스토어", "쿠팡", "일반 쇼핑몰"]
CHANNEL_REQUIRED_FIELDS = {
    "스마트스토어": ["product", "category", "origin", "shipping"],
    "쿠팡": ["product", "category", "origin", "shipping"],
    "일반 쇼핑몰": ["product", "category"],
}
FOOD_NOTICE_FIELDS = [
    ("제품명", "product"), ("식품의 유형", "category"),
    ("생산자 및 소재지", "producer"), ("제조연월일·소비기한", "shelf_life"),
    ("포장단위별 내용물의 용량", "weight"), ("원재료명 및 함량", "ingredients"),
    ("영양성분", "nutrition"), ("유전자변형식품 여부", "gmo"),
    ("수입식품 여부", "imported"), ("소비자상담 전화번호", "customer_service"),
]


def parse_option_text(option_text: str) -> list[dict[str, Any]]:
    options = []
    for index, value in enumerate(str(option_text or "").replace("\n", ",").split(","), 1):
        name = value.strip()
        if name:
            options.append({
                "option_id": index, "name": name, "additional_price": 0,
                "stock": "", "seller_code": "", "enabled": True,
            })
    return options


def build_registration_validation(project: Project, channel: str = "스마트스토어") -> dict[str, Any]:
    missing, warnings = [], []
    for key in CHANNEL_REQUIRED_FIELDS.get(channel, ["product", "category"]):
        value = str(project.fields.get(key, "") or "").strip()
        if not value or "확인 필요" in value:
            missing.append(key)
    if not project.images:
        missing.append("images")
    if not project.cuts:
        missing.append("detail_page")

    warning_fields = {
        "optimized_product_name": "최적화 상품명이 없습니다.",
        "price": "판매가가 입력되지 않았습니다.",
        "weight": "중량·용량이 입력되지 않았습니다.",
        "customer_service": "소비자 상담 연락처가 입력되지 않았습니다.",
        "options": "옵션 정보가 없습니다.",
    }
    for key, message in warning_fields.items():
        if not str(project.fields.get(key, "") or "").strip():
            warnings.append(message)

    return {
        "channel": channel,
        "ready": not missing,
        "status": "등록 가능" if not missing else "보완 필요",
        "missing": missing,
        "warnings": warnings,
        "image_count": len(project.images),
        "cut_count": len(project.cuts),
    }


def build_food_notice_draft(project: Project) -> list[dict[str, str]]:
    rows = []
    for label, key in FOOD_NOTICE_FIELDS:
        value = str(project.fields.get(key, "") or "").strip()
        if not value:
            if key in {"product", "category"}:
                value = str(project.fields.get(key, "") or "")
            elif key == "producer":
                origin = str(project.fields.get("origin", "") or "")
                value = f"생산자 확인 필요 / 소재지: {origin}" if origin else "확인 필요"
            else:
                value = "확인 필요"
        rows.append({"항목": label, "내용": value})
    return rows


def build_channel_registration_data(project: Project, channel: str = "스마트스토어") -> dict[str, Any]:
    strategy = build_sales_strategy(project, channel)
    titles = strategy.get("product_titles", [])
    name = project.fields.get("optimized_product_name") or (titles[0]["title"] if titles else "") or project.fields.get("product", "")
    return {
        "package_version": REGISTRATION_PACKAGE_VERSION,
        "channel": channel,
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "product_name": name,
        "category": project.fields.get("category", ""),
        "origin": project.fields.get("origin", ""),
        "price": project.fields.get("price", ""),
        "shipping": project.fields.get("shipping", ""),
        "delivery_fee": project.fields.get("delivery_fee", ""),
        "courier": project.fields.get("courier", project.fields.get("shipping", "")),
        "brand": project.fields.get("brand", ""),
        "manufacturer": project.fields.get("manufacturer", ""),
        "seller_code": project.fields.get("seller_code", ""),
        "keywords": project.ai_analysis.get("copy", {}).get("search_keywords", []),
        "options": parse_option_text(project.fields.get("options", "")),
        "notice": build_food_notice_draft(project),
        "validation": build_registration_validation(project, channel),
    }


def _write_csv_file(path: Path, rows: list[dict[str, Any]], fieldnames: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8-sig") as file:
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows([{key: row.get(key, "") for key in fieldnames} for row in rows])


def export_registration_package(project: Project, output_folder: str | Path, channel: str = "스마트스토어") -> dict[str, Any]:
    output_folder = Path(output_folder)
    product = sanitize_name(project.fields.get("product", "") or "상품")
    folder = output_folder / f"{product}_{sanitize_name(channel)}_등록패키지"
    if folder.exists():
        shutil.rmtree(folder)
    folder.mkdir(parents=True, exist_ok=True)

    data = build_channel_registration_data(project, channel)
    (folder / "상품등록정보.json").write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

    summary = [{
        "판매채널": channel, "상품명": data["product_name"], "카테고리": data["category"],
        "원산지": data["origin"], "판매가": data["price"], "배송정보": data["shipping"],
        "배송비": data["delivery_fee"], "택배사": data["courier"], "브랜드": data["brand"],
        "제조사": data["manufacturer"], "판매자상품코드": data["seller_code"],
    }]
    _write_csv_file(folder / "상품등록정보.csv", summary, list(summary[0].keys()))
    options = data["options"] or [{"option_id": "", "name": "옵션 없음 또는 확인 필요", "additional_price": "", "stock": "", "seller_code": "", "enabled": ""}]
    _write_csv_file(folder / "옵션정보.csv", options, ["option_id", "name", "additional_price", "stock", "seller_code", "enabled"])
    _write_csv_file(folder / "상품정보고시_초안.csv", data["notice"], ["항목", "내용"])

    image_rows = [{
        "순번": index, "파일명": Path(path).name, "원본경로": str(path),
        "용도": "대표이미지 후보" if index == 1 else "추가이미지",
        "존재여부": "정상" if Path(path).exists() else "누락",
    } for index, path in enumerate(project.images, 1)]
    _write_csv_file(folder / "이미지목록.csv", image_rows, ["순번", "파일명", "원본경로", "용도", "존재여부"])

    checklist = [
        "# 상품 등록 전 검수 체크리스트", "", f"- 판매 채널: {channel}",
        f"- 상품명: {data['product_name']}", f"- 등록 준비 상태: {data['validation']['status']}",
        "", "## 누락 항목",
    ]
    checklist.extend([f"- {item}" for item in data["validation"]["missing"]] or ["- 필수 누락 없음"])
    checklist.extend(["", "## 경고"])
    checklist.extend([f"- {item}" for item in data["validation"]["warnings"]] or ["- 별도 경고 없음"])
    (folder / "등록전_검수체크리스트.md").write_text("\n".join(checklist), encoding="utf-8")
    save_project(project, folder / f"{product}.nongjak.json")

    zip_path = output_folder / f"{product}_{sanitize_name(channel)}_등록패키지.zip"
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as archive:
        for file in folder.rglob("*"):
            if file.is_file():
                archive.write(file, file.relative_to(folder))

    return {
        "channel": channel, "folder": str(folder), "zip": str(zip_path),
        "validation": data["validation"],
        "files": sorted(str(file.relative_to(folder)) for file in folder.rglob("*") if file.is_file()),
    }


def discover_project_files(folder: str | Path) -> list[Path]:
    folder = Path(folder)
    if not folder.exists():
        raise FileNotFoundError("프로젝트 폴더를 찾을 수 없습니다.")
    return sorted(folder.rglob("*.nongjak.json"))


def batch_registration_audit(project_files: list[str | Path], channel: str = "스마트스토어") -> dict[str, Any]:
    results = []
    for index, value in enumerate(project_files, 1):
        path = Path(value)
        try:
            project = load_project(path)
            validation = build_registration_validation(project, channel)
            results.append({
                "index": index, "project_file": str(path), "product": project.fields.get("product", ""),
                "status": validation["status"], "ready": validation["ready"],
                "missing_count": len(validation["missing"]), "warning_count": len(validation["warnings"]),
                "missing": validation["missing"], "warnings": validation["warnings"],
                "image_count": validation["image_count"], "cut_count": validation["cut_count"], "error": "",
            })
        except Exception as error:
            results.append({
                "index": index, "project_file": str(path), "product": path.stem,
                "status": "오류", "ready": False, "missing_count": 0, "warning_count": 0,
                "missing": [], "warnings": [], "image_count": 0, "cut_count": 0, "error": str(error),
            })
    return {
        "channel": channel, "total": len(results),
        "ready_count": sum(item["status"] == "등록 가능" for item in results),
        "needs_work_count": sum(item["status"] == "보완 필요" for item in results),
        "error_count": sum(item["status"] == "오류" for item in results),
        "results": results,
    }


def registration_issue_summary(audit: dict[str, Any]) -> dict[str, Any]:
    missing, warnings = {}, {}
    for item in audit.get("results", []):
        for key in item.get("missing", []):
            missing[key] = missing.get(key, 0) + 1
        for key in item.get("warnings", []):
            warnings[key] = warnings.get(key, 0) + 1
    return {
        "most_common_missing": sorted([{"item": key, "count": value} for key, value in missing.items()], key=lambda item: item["count"], reverse=True),
        "most_common_warnings": sorted([{"item": key, "count": value} for key, value in warnings.items()], key=lambda item: item["count"], reverse=True),
    }


def export_batch_registration_report(audit: dict[str, Any], output_folder: str | Path) -> dict[str, Any]:
    output_folder = Path(output_folder)
    output_folder.mkdir(parents=True, exist_ok=True)
    json_path = output_folder / "배치_등록점검_보고서.json"
    csv_path = output_folder / "배치_등록점검_보고서.csv"
    summary_path = output_folder / "배치_누락항목_요약.json"
    json_path.write_text(json.dumps(audit, ensure_ascii=False, indent=2), encoding="utf-8")

    rows = [{
        "순번": item["index"], "상품명": item["product"], "상태": item["status"],
        "누락수": item["missing_count"], "경고수": item["warning_count"],
        "이미지수": item["image_count"], "컷수": item["cut_count"],
        "누락항목": ", ".join(item["missing"]), "오류": item["error"], "프로젝트파일": item["project_file"],
    } for item in audit["results"]]
    _write_csv_file(csv_path, rows, ["순번", "상품명", "상태", "누락수", "경고수", "이미지수", "컷수", "누락항목", "오류", "프로젝트파일"])
    summary_path.write_text(json.dumps(registration_issue_summary(audit), ensure_ascii=False, indent=2), encoding="utf-8")
    return {"json": str(json_path), "csv": str(csv_path), "summary": str(summary_path)}


def export_batch_registration_packages(
    project_files: list[str | Path],
    output_folder: str | Path,
    channel: str = "스마트스토어",
    ready_only: bool = False,
) -> dict[str, Any]:
    audit = batch_registration_audit(project_files, channel)
    result_map = {item["project_file"]: item for item in audit["results"]}
    packages, skipped, failed = [], [], []
    for value in project_files:
        path = Path(value)
        if ready_only and not result_map.get(str(path), {}).get("ready", False):
            skipped.append(str(path))
            continue
        try:
            packages.append(export_registration_package(load_project(path), output_folder, channel))
        except Exception as error:
            failed.append({"project_file": str(path), "error": str(error)})
    reports = export_batch_registration_report(audit, output_folder)
    return {
        "channel": channel, "audit": audit, "package_count": len(packages),
        "skipped_count": len(skipped), "failed_count": len(failed),
        "packages": packages, "skipped": skipped, "failed": failed, "reports": reports,
    }


PREFERENCE_ENGINE_VERSION = "6.2"
PREFERENCE_PROFILE_FILE = CONFIG_DIR / "user_preference_profile.json"


def _mode_value(values: list[Any], default: Any = None) -> Any:
    values = [value for value in values if value not in (None, "")]
    if not values:
        return default
    counts: dict[str, int] = {}
    originals: dict[str, Any] = {}
    for value in values:
        key = json.dumps(value, ensure_ascii=False, sort_keys=True) if isinstance(value, (dict, list)) else str(value)
        counts[key] = counts.get(key, 0) + 1
        originals[key] = value
    best = max(counts, key=lambda key: (counts[key], -values.index(originals[key])))
    return originals[best]


def approved_cut_statistics(project: Project) -> dict[str, Any]:
    approved = [cut for cut in project.cuts if cut.approved or cut.review_status == "승인"]
    source = approved or project.cuts
    if not source:
        return {
            "approved_count": 0,
            "source_count": 0,
            "title_size": 33,
            "body_size": 39,
            "text_align": "center",
            "layout_variant": "기본 카드형",
            "image_scale": 1.0,
            "body_length": 0,
        }
    return {
        "approved_count": len(approved),
        "source_count": len(source),
        "title_size": round(sum(cut.title_size for cut in source) / len(source)),
        "body_size": round(sum(cut.body_size for cut in source) / len(source)),
        "text_align": _mode_value([cut.text_align for cut in source], "center"),
        "layout_variant": _mode_value([cut.layout_variant for cut in source], "기본 카드형"),
        "image_scale": round(sum(cut.image_scale for cut in source) / len(source), 2),
        "body_length": round(sum(len(cut.body.strip()) for cut in source) / len(source)),
    }


def build_preference_sample(project: Project, source_name: str = "") -> dict[str, Any]:
    stats = approved_cut_statistics(project)
    return {
        "source_name": source_name or project.fields.get("product", "프로젝트"),
        "captured_at": datetime.now().isoformat(timespec="seconds"),
        "category": project.fields.get("category", ""),
        "style": project.style,
        "layout": project.layout,
        "custom_background": project.custom_background,
        "cut_count": len(project.cuts),
        "fields": {
            "brandless": not bool(str(project.fields.get("brand", "") or "").strip()),
            "shipping": project.fields.get("shipping", ""),
            "origin": project.fields.get("origin", ""),
        },
        "cut_statistics": stats,
        "story_stages": [cut.story_stage for cut in project.cuts],
        "layout_sequence": [cut.layout_variant for cut in project.cuts],
        "approved_titles": [cut.title for cut in project.cuts if cut.approved or cut.review_status == "승인"],
    }


def load_preference_profile(path: str | Path = PREFERENCE_PROFILE_FILE) -> dict[str, Any]:
    path = Path(path)
    if not path.exists():
        return {"version": PREFERENCE_ENGINE_VERSION, "samples": [], "summary": {}}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            raise ValueError("취향 프로필 형식 오류")
        data.setdefault("samples", [])
        data.setdefault("summary", {})
        return data
    except Exception:
        return {"version": PREFERENCE_ENGINE_VERSION, "samples": [], "summary": {}, "corrupted": True}


def summarize_preference_samples(samples: list[dict[str, Any]]) -> dict[str, Any]:
    if not samples:
        return {}
    stats = [sample.get("cut_statistics", {}) for sample in samples]
    category_styles: dict[str, list[str]] = {}
    for sample in samples:
        category = sample.get("category") or "식품"
        category_styles.setdefault(category, []).append(sample.get("style", "프리미엄"))
    return {
        "sample_count": len(samples),
        "preferred_style": _mode_value([sample.get("style") for sample in samples], "프리미엄"),
        "preferred_layout": _mode_value([sample.get("layout") for sample in samples], "균형형"),
        "preferred_cut_count": round(sum(int(sample.get("cut_count", 0)) for sample in samples) / len(samples)),
        "preferred_title_size": round(sum(int(item.get("title_size", 33)) for item in stats) / len(stats)),
        "preferred_body_size": round(sum(int(item.get("body_size", 39)) for item in stats) / len(stats)),
        "preferred_text_align": _mode_value([item.get("text_align") for item in stats], "center"),
        "preferred_layout_variant": _mode_value([item.get("layout_variant") for item in stats], "기본 카드형"),
        "preferred_image_scale": round(sum(float(item.get("image_scale", 1.0)) for item in stats) / len(stats), 2),
        "preferred_body_length": round(sum(int(item.get("body_length", 0)) for item in stats) / len(stats)),
        "category_styles": {category: _mode_value(styles, "프리미엄") for category, styles in category_styles.items()},
        "brandless_ratio": round(sum(bool(sample.get("fields", {}).get("brandless", False)) for sample in samples) / len(samples), 2),
        "common_shipping": _mode_value([sample.get("fields", {}).get("shipping") for sample in samples], ""),
        "updated_at": datetime.now().isoformat(timespec="seconds"),
    }


def learn_project_preferences(
    project: Project,
    path: str | Path = PREFERENCE_PROFILE_FILE,
    source_name: str = "",
    max_samples: int = 50,
) -> dict[str, Any]:
    profile = load_preference_profile(path)
    samples = list(profile.get("samples", []))
    sample = build_preference_sample(project, source_name)
    samples.append(sample)
    samples = samples[-max(1, int(max_samples)):]
    if samples:
        create_preference_snapshot(profile, label="학습전_자동백업")
    return rebuild_preference_profile(samples, path)


def recommend_from_preference_profile(
    project: Project,
    profile: dict[str, Any] | None = None,
) -> dict[str, Any]:
    profile = profile or load_preference_profile()
    summary = profile.get("summary", {})
    category = project.fields.get("category", "") or "식품"
    category_style = summary.get("category_styles", {}).get(category)
    return {
        "available": bool(summary),
        "sample_count": int(summary.get("sample_count", 0)),
        "style": category_style or summary.get("preferred_style", project.style),
        "layout": summary.get("preferred_layout", project.layout),
        "cut_count": int(summary.get("preferred_cut_count", len(project.cuts) or 8)),
        "title_size": int(summary.get("preferred_title_size", 33)),
        "body_size": int(summary.get("preferred_body_size", 39)),
        "text_align": summary.get("preferred_text_align", "center"),
        "layout_variant": summary.get("preferred_layout_variant", "기본 카드형"),
        "image_scale": float(summary.get("preferred_image_scale", 1.0)),
        "body_length_target": int(summary.get("preferred_body_length", 0)),
        "brandless_preferred": float(summary.get("brandless_ratio", 0)) >= 0.6,
        "shipping": summary.get("common_shipping", ""),
    }


def apply_preference_profile(
    project: Project,
    profile: dict[str, Any] | None = None,
    apply_fields: bool = True,
    apply_cut_format: bool = True,
) -> dict[str, Any]:
    recommendation = recommend_from_preference_profile(project, profile)
    if not recommendation["available"]:
        return {"applied": False, "reason": "학습된 취향 정보가 없습니다.", "recommendation": recommendation}

    changes = []
    if project.style != recommendation["style"]:
        project.style = recommendation["style"]
        changes.append("스타일")
    if project.layout != recommendation["layout"]:
        project.layout = recommendation["layout"]
        changes.append("전체 레이아웃")

    if apply_fields:
        if recommendation["shipping"] and not str(project.fields.get("shipping", "") or "").strip():
            project.fields["shipping"] = recommendation["shipping"]
            changes.append("배송정보")
        if recommendation["brandless_preferred"] and not project.fields.get("brand"):
            project.fields["brand_policy"] = "브랜드 없이 제작"
            changes.append("브랜드 정책")

    if apply_cut_format:
        for cut in project.cuts:
            cut.title_size = recommendation["title_size"]
            cut.body_size = recommendation["body_size"]
            cut.text_align = recommendation["text_align"]
            cut.image_scale = recommendation["image_scale"]
            if cut.layout_variant == "기본 카드형":
                cut.layout_variant = recommendation["layout_variant"]
        if project.cuts:
            changes.append("컷 글자·정렬·이미지 비율")

    project.ai_analysis = dict(project.ai_analysis or {})
    project.ai_analysis["preference_profile"] = {
        "version": PREFERENCE_ENGINE_VERSION,
        "applied_at": datetime.now().isoformat(timespec="seconds"),
        "recommendation": recommendation,
    }
    return {"applied": True, "changes": changes, "recommendation": recommendation}


def preference_consistency_score(project: Project, profile: dict[str, Any] | None = None) -> dict[str, Any]:
    recommendation = recommend_from_preference_profile(project, profile)
    if not recommendation["available"]:
        return {"score": 0, "available": False, "issues": ["학습된 취향 정보가 없습니다."]}
    issues = []
    score = 100
    if project.style != recommendation["style"]:
        score -= 18; issues.append("선호 스타일과 다릅니다.")
    if project.layout != recommendation["layout"]:
        score -= 14; issues.append("선호 전체 레이아웃과 다릅니다.")
    for cut in project.cuts:
        if abs(cut.title_size - recommendation["title_size"]) > 4:
            score -= 3
        if abs(cut.body_size - recommendation["body_size"]) > 4:
            score -= 3
        if cut.text_align != recommendation["text_align"]:
            score -= 2
    score = max(0, score)
    if score < 100 and not issues:
        issues.append("일부 컷의 글자 크기나 정렬이 선호 형식과 다릅니다.")
    return {"score": score, "available": True, "issues": issues, "recommendation": recommendation}


def export_preference_profile(profile: dict[str, Any], path: str | Path) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(profile, ensure_ascii=False, indent=2), encoding="utf-8")
    return path


def reset_preference_profile(path: str | Path = PREFERENCE_PROFILE_FILE) -> bool:
    path = Path(path)
    if path.exists():
        path.unlink()
        return True
    return False


PREFERENCE_SNAPSHOT_DIR = CONFIG_DIR / "preference_snapshots"


def score_preference_sample(sample: dict[str, Any]) -> dict[str, Any]:
    score = 100
    issues = []
    stats = sample.get("cut_statistics", {})
    approved_count = int(stats.get("approved_count", 0) or 0)
    source_count = int(stats.get("source_count", 0) or 0)
    cut_count = int(sample.get("cut_count", 0) or 0)

    if source_count == 0 or cut_count == 0:
        score -= 70
        issues.append("학습할 상세페이지 컷이 없습니다.")
    elif approved_count == 0:
        score -= 22
        issues.append("승인된 컷이 없어 전체 프로젝트 형식을 학습합니다.")

    if not sample.get("category"):
        score -= 12
        issues.append("품목 정보가 없습니다.")
    if not sample.get("style"):
        score -= 10
        issues.append("스타일 정보가 없습니다.")
    if not sample.get("layout"):
        score -= 8
        issues.append("레이아웃 정보가 없습니다.")

    body_length = int(stats.get("body_length", 0) or 0)
    if body_length > 120:
        score -= 10
        issues.append("본문 길이가 지나치게 긴 표본입니다.")
    if float(stats.get("image_scale", 1.0) or 1.0) < 0.5:
        score -= 8
        issues.append("이미지 비율이 비정상적으로 작습니다.")

    return {
        "score": max(0, score),
        "usable": score >= 55,
        "issues": issues,
    }


def enrich_preference_sample(sample: dict[str, Any]) -> dict[str, Any]:
    item = dict(sample)
    quality = score_preference_sample(item)
    item["sample_quality"] = quality
    return item


def preference_category_summaries(samples: list[dict[str, Any]]) -> dict[str, Any]:
    grouped: dict[str, list[dict[str, Any]]] = {}
    for sample in samples:
        category = sample.get("category") or "식품"
        quality = sample.get("sample_quality") or score_preference_sample(sample)
        if not quality.get("usable", False):
            continue
        grouped.setdefault(category, []).append(sample)

    return {
        category: summarize_preference_samples(category_samples)
        for category, category_samples in grouped.items()
    }


def preference_profile_health(profile: dict[str, Any]) -> dict[str, Any]:
    samples = list(profile.get("samples", []))
    qualities = [
        sample.get("sample_quality") or score_preference_sample(sample)
        for sample in samples
    ]
    usable = sum(1 for quality in qualities if quality.get("usable"))
    weak = len(qualities) - usable
    average = round(
        sum(int(quality.get("score", 0)) for quality in qualities) / len(qualities),
        1,
    ) if qualities else 0.0
    categories = {}
    for sample in samples:
        category = sample.get("category") or "식품"
        categories[category] = categories.get(category, 0) + 1

    return {
        "sample_count": len(samples),
        "usable_count": usable,
        "weak_count": weak,
        "average_quality": average,
        "categories": categories,
        "healthy": bool(samples) and usable >= max(1, len(samples) // 2),
    }


def save_preference_profile_atomic(
    profile: dict[str, Any],
    path: str | Path = PREFERENCE_PROFILE_FILE,
) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(profile, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    temporary.replace(path)
    return path


def rebuild_preference_profile(
    samples: list[dict[str, Any]],
    path: str | Path = PREFERENCE_PROFILE_FILE,
) -> dict[str, Any]:
    enriched = [enrich_preference_sample(sample) for sample in samples]
    usable_samples = [
        sample for sample in enriched
        if sample["sample_quality"]["usable"]
    ]
    profile = {
        "version": PREFERENCE_ENGINE_VERSION,
        "samples": enriched,
        "summary": summarize_preference_samples(usable_samples),
        "category_summaries": preference_category_summaries(enriched),
        "health": preference_profile_health({"samples": enriched}),
        "updated_at": datetime.now().isoformat(timespec="seconds"),
    }
    save_preference_profile_atomic(profile, path)
    return profile


def remove_preference_sample(
    sample_index: int,
    path: str | Path = PREFERENCE_PROFILE_FILE,
) -> dict[str, Any]:
    profile = load_preference_profile(path)
    samples = list(profile.get("samples", []))
    if not 0 <= int(sample_index) < len(samples):
        raise IndexError("삭제할 학습 표본 번호가 올바르지 않습니다.")
    removed = samples.pop(int(sample_index))
    rebuilt = rebuild_preference_profile(samples, path)
    rebuilt["removed_sample"] = removed
    return rebuilt


def remove_latest_preference_sample(
    path: str | Path = PREFERENCE_PROFILE_FILE,
) -> dict[str, Any]:
    profile = load_preference_profile(path)
    samples = list(profile.get("samples", []))
    if not samples:
        return {"removed": False, "reason": "삭제할 학습 표본이 없습니다.", "profile": profile}
    removed = samples.pop()
    rebuilt = rebuild_preference_profile(samples, path)
    return {"removed": True, "removed_sample": removed, "profile": rebuilt}


def create_preference_snapshot(
    profile: dict[str, Any] | None = None,
    snapshot_dir: str | Path = PREFERENCE_SNAPSHOT_DIR,
    label: str = "",
) -> Path:
    profile = profile or load_preference_profile()
    snapshot_dir = Path(snapshot_dir)
    snapshot_dir.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    safe_label = sanitize_name(label or "취향프로필")
    path = snapshot_dir / f"{timestamp}_{safe_label}.json"
    payload = {
        "snapshot_version": PREFERENCE_ENGINE_VERSION,
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "label": label,
        "profile": profile,
    }
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return path


def list_preference_snapshots(
    snapshot_dir: str | Path = PREFERENCE_SNAPSHOT_DIR,
) -> list[dict[str, Any]]:
    snapshot_dir = Path(snapshot_dir)
    if not snapshot_dir.exists():
        return []
    results = []
    for path in sorted(snapshot_dir.glob("*.json"), key=lambda item: item.stat().st_mtime, reverse=True):
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            profile = data.get("profile", {})
            results.append({
                "path": str(path),
                "name": path.name,
                "created_at": data.get("created_at", ""),
                "label": data.get("label", ""),
                "sample_count": len(profile.get("samples", [])),
                "health": preference_profile_health(profile),
            })
        except Exception:
            results.append({
                "path": str(path),
                "name": path.name,
                "created_at": "",
                "label": "",
                "sample_count": 0,
                "health": {"healthy": False},
                "corrupted": True,
            })
    return results


def restore_preference_snapshot(
    snapshot_path: str | Path,
    profile_path: str | Path = PREFERENCE_PROFILE_FILE,
) -> dict[str, Any]:
    snapshot_path = Path(snapshot_path)
    data = json.loads(snapshot_path.read_text(encoding="utf-8"))
    profile = data.get("profile")
    if not isinstance(profile, dict):
        raise ValueError("올바른 취향 프로필 스냅샷이 아닙니다.")
    current = load_preference_profile(profile_path)
    backup = create_preference_snapshot(current, label="복원전_자동백업")
    save_preference_profile_atomic(profile, profile_path)
    return {
        "restored": True,
        "snapshot": str(snapshot_path),
        "backup_before_restore": str(backup),
        "profile": profile,
    }


def recommend_category_preference(
    project: Project,
    profile: dict[str, Any] | None = None,
) -> dict[str, Any]:
    profile = profile or load_preference_profile()
    category = project.fields.get("category", "") or "식품"
    category_summary = profile.get("category_summaries", {}).get(category)
    if category_summary:
        temporary_profile = {"summary": category_summary}
        recommendation = recommend_from_preference_profile(project, temporary_profile)
        recommendation["source"] = f"품목별 프로필: {category}"
        return recommendation

    recommendation = recommend_from_preference_profile(project, profile)
    recommendation["source"] = "전체 프로필"
    return recommendation


def preference_profile_comparison(
    project: Project,
    profile: dict[str, Any] | None = None,
) -> dict[str, Any]:
    profile = profile or load_preference_profile()
    global_recommendation = recommend_from_preference_profile(project, profile)
    category_recommendation = recommend_category_preference(project, profile)

    differences = []
    for key in ["style", "layout", "cut_count", "title_size", "body_size", "text_align", "layout_variant"]:
        global_value = global_recommendation.get(key)
        category_value = category_recommendation.get(key)
        if global_value != category_value:
            differences.append({
                "item": key,
                "global": global_value,
                "category": category_value,
            })

    return {
        "category": project.fields.get("category", "") or "식품",
        "global": global_recommendation,
        "category_profile": category_recommendation,
        "differences": differences,
        "recommended_source": category_recommendation.get("source", "전체 프로필"),
    }


WORKSPACE_ENGINE_VERSION = "5.7"
WORKSPACE_CONFIG_FILE = CONFIG_DIR / "workspace_config.json"
STARTUP_HISTORY_FILE = CONFIG_DIR / "startup_history.json"
RECOVERY_ARCHIVE_DIR = CONFIG_DIR / "recovery_archive"


@dataclass
class WorkspaceConfig:
    workspace_root: str = str(Path.home() / "농작AI_작업공간")
    project_folder_name: str = "프로젝트"
    output_folder_name: str = "완성본"
    image_folder_name: str = "상품사진"
    default_shipping: str = "한진택배"
    default_style: str = "프리미엄"
    default_layout: str = "균형형"
    default_cut_count: int = 8
    auto_restore_session: bool = True
    show_startup_dashboard: bool = True
    recent_limit: int = 10

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "WorkspaceConfig":
        default = cls()
        return cls(
            workspace_root=str(data.get("workspace_root", default.workspace_root)),
            project_folder_name=str(data.get("project_folder_name", default.project_folder_name)),
            output_folder_name=str(data.get("output_folder_name", default.output_folder_name)),
            image_folder_name=str(data.get("image_folder_name", default.image_folder_name)),
            default_shipping=str(data.get("default_shipping", default.default_shipping)),
            default_style=str(data.get("default_style", default.default_style)),
            default_layout=str(data.get("default_layout", default.default_layout)),
            default_cut_count=max(1, min(int(data.get("default_cut_count", default.default_cut_count)), 10)),
            auto_restore_session=bool(data.get("auto_restore_session", default.auto_restore_session)),
            show_startup_dashboard=bool(data.get("show_startup_dashboard", default.show_startup_dashboard)),
            recent_limit=max(1, min(int(data.get("recent_limit", default.recent_limit)), 30)),
        )


def save_workspace_config(
    config: WorkspaceConfig,
    path: str | Path = WORKSPACE_CONFIG_FILE,
) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(config.to_dict(), ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    temporary.replace(path)
    ensure_workspace_folders(config)
    return path


def load_workspace_config(
    path: str | Path = WORKSPACE_CONFIG_FILE,
) -> WorkspaceConfig:
    path = Path(path)
    if not path.exists():
        return WorkspaceConfig()
    try:
        return WorkspaceConfig.from_dict(json.loads(path.read_text(encoding="utf-8")))
    except Exception:
        return WorkspaceConfig()


def workspace_paths(config: WorkspaceConfig | None = None) -> dict[str, Path]:
    config = config or load_workspace_config()
    root = Path(config.workspace_root).expanduser()
    return {
        "root": root,
        "projects": root / config.project_folder_name,
        "outputs": root / config.output_folder_name,
        "images": root / config.image_folder_name,
    }


def ensure_workspace_folders(config: WorkspaceConfig | None = None) -> dict[str, str]:
    paths = workspace_paths(config)
    result = {}
    for key, path in paths.items():
        path.mkdir(parents=True, exist_ok=True)
        result[key] = str(path)
    return result


def apply_workspace_defaults(
    project: Project,
    config: WorkspaceConfig | None = None,
    overwrite: bool = False,
) -> Project:
    config = config or load_workspace_config()
    if overwrite or not project.fields.get("shipping"):
        project.fields["shipping"] = config.default_shipping
    if overwrite or not project.style:
        project.style = config.default_style
    if overwrite or not project.layout:
        project.layout = config.default_layout
    return project


def create_workspace_project(
    product_name: str = "",
    category: str = "",
    config: WorkspaceConfig | None = None,
) -> Project:
    config = config or load_workspace_config()
    fields = dict(DEFAULTS)
    fields.update({
        "product": product_name.strip(),
        "category": category.strip(),
        "shipping": config.default_shipping,
    })
    return Project(
        fields=fields,
        images=[],
        cuts=[],
        style=config.default_style,
        layout=config.default_layout,
    )


def save_startup_history(
    event: str,
    details: dict[str, Any] | None = None,
    path: str | Path = STARTUP_HISTORY_FILE,
    keep: int = 100,
) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    history = []
    if path.exists():
        try:
            history = json.loads(path.read_text(encoding="utf-8"))
            if not isinstance(history, list):
                history = []
        except Exception:
            history = []
    history.insert(0, {
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "app_version": APP_VERSION,
        "event": event,
        "details": details or {},
    })
    path.write_text(
        json.dumps(history[:keep], ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return path


def load_startup_history(
    path: str | Path = STARTUP_HISTORY_FILE,
) -> list[dict[str, Any]]:
    path = Path(path)
    if not path.exists():
        return []
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, list) else []
    except Exception:
        return []


def _candidate_from_project(
    project: Project,
    source_type: str,
    source_path: str,
    saved_at: str = "",
    dirty: bool = False,
    current_index: int = 0,
) -> dict[str, Any]:
    return {
        "source_type": source_type,
        "source_path": source_path,
        "saved_at": saved_at,
        "dirty": bool(dirty),
        "current_index": max(0, int(current_index)),
        "product": project.fields.get("product", "") or "이름 없는 프로젝트",
        "category": project.fields.get("category", ""),
        "image_count": len(project.images),
        "cut_count": len(project.cuts),
        "project": project,
    }


def collect_recovery_candidates(
    config: WorkspaceConfig | None = None,
) -> list[dict[str, Any]]:
    config = config or load_workspace_config()
    candidates = []

    session = load_session_state()
    if session and session.get("project_object"):
        candidates.append(_candidate_from_project(
            session["project_object"],
            "세션",
            str(SESSION_FILE),
            str(session.get("saved_at", "")),
            bool(session.get("dirty", False)),
            int(session.get("current_index", 0)),
        ))

    autosaves = sorted(
        AUTOSAVE_DIR.glob("*.nongjak.json"),
        key=lambda item: item.stat().st_mtime,
        reverse=True,
    ) if AUTOSAVE_DIR.exists() else []
    for path in autosaves[:5]:
        try:
            project = load_project(path)
            candidates.append(_candidate_from_project(
                project,
                "자동저장",
                str(path),
                datetime.fromtimestamp(path.stat().st_mtime).isoformat(timespec="seconds"),
                True,
                0,
            ))
        except Exception:
            continue

    recent = load_recent_projects()[: config.recent_limit]
    for item in recent:
        path = Path(item.get("path", ""))
        if not path.exists():
            continue
        try:
            project = load_project(path)
            candidates.append(_candidate_from_project(
                project,
                "최근 프로젝트",
                str(path),
                str(item.get("opened_at", "")),
                False,
                0,
            ))
        except Exception:
            continue

    unique = []
    seen = set()
    for candidate in candidates:
        key = (
            candidate["source_type"],
            candidate["source_path"],
            project_fingerprint(candidate["project"]),
        )
        if key in seen:
            continue
        seen.add(key)
        unique.append(candidate)

    source_priority = {"세션": 0, "자동저장": 1, "최근 프로젝트": 2}
    unique.sort(
        key=lambda item: (
            source_priority.get(item["source_type"], 9),
            item["saved_at"],
        ),
        reverse=False,
    )
    return unique


def select_best_recovery_candidate(
    candidates: list[dict[str, Any]] | None = None,
) -> dict[str, Any] | None:
    candidates = candidates if candidates is not None else collect_recovery_candidates()
    if not candidates:
        return None

    def score(item: dict[str, Any]) -> tuple[int, int, str]:
        source_score = {"세션": 30, "자동저장": 20, "최근 프로젝트": 10}.get(item["source_type"], 0)
        dirty_score = 10 if item.get("dirty") else 0
        content_score = min(10, item.get("cut_count", 0)) + min(5, item.get("image_count", 0))
        return source_score + dirty_score + content_score, item.get("cut_count", 0), item.get("saved_at", "")

    return max(candidates, key=score)


def archive_recovery_state(
    path: str | Path = SESSION_FILE,
    archive_dir: str | Path = RECOVERY_ARCHIVE_DIR,
) -> Path | None:
    path = Path(path)
    if not path.exists():
        return None
    archive_dir = Path(archive_dir)
    archive_dir.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    destination = archive_dir / f"{path.stem}_{timestamp}{path.suffix}"
    shutil.copy2(path, destination)
    return destination


def clear_recovery_state(
    archive_first: bool = True,
) -> dict[str, Any]:
    archived = []
    removed = []
    if SESSION_FILE.exists():
        if archive_first:
            backup = archive_recovery_state(SESSION_FILE)
            if backup:
                archived.append(str(backup))
        SESSION_FILE.unlink(missing_ok=True)
        removed.append(str(SESSION_FILE))
    return {"archived": archived, "removed": removed}


def startup_dashboard_data(
    config: WorkspaceConfig | None = None,
) -> dict[str, Any]:
    config = config or load_workspace_config()
    paths = ensure_workspace_folders(config)
    candidates = collect_recovery_candidates(config)
    best = select_best_recovery_candidate(candidates)
    history = load_startup_history()
    return {
        "engine_version": WORKSPACE_ENGINE_VERSION,
        "app_version": APP_VERSION,
        "first_run": is_first_run(),
        "workspace": config.to_dict(),
        "paths": paths,
        "candidate_count": len(candidates),
        "candidates": [
            {key: value for key, value in item.items() if key != "project"}
            for item in candidates
        ],
        "best_candidate": (
            {key: value for key, value in best.items() if key != "project"}
            if best else None
        ),
        "history_count": len(history),
    }


def export_startup_dashboard_report(
    path: str | Path,
    config: WorkspaceConfig | None = None,
) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(startup_dashboard_data(config), ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return path


TEMPLATE_ENGINE_VERSION = "5.8"
CUSTOM_TEMPLATE_FILE = CONFIG_DIR / "project_templates.json"
TEMPLATE_PACK_VERSION = 1

BUILTIN_PROJECT_TEMPLATES = [
    {
        "template_id": "builtin_agriculture_origin_8",
        "name": "농산물 산지직송 8컷",
        "category": "농산물",
        "description": "산지·선별·신선함·배송 흐름을 강조하는 농산물 기본형",
        "builtin": True,
        "style": "감성",
        "layout": "균형형",
        "cut_count": 8,
        "fields": {
            "category": "농산물",
            "feature1": "산지에서 신선하게",
            "feature2": "꼼꼼하게 선별한 품질",
            "shipping": "한진택배",
        },
        "cuts": [
            {"title": "산지에서 바로", "body": "{product}의 신선함을 그대로 전해드립니다.", "story_stage": "상품 소개", "layout_variant": "풀블리드형"},
            {"title": "한눈에 보는 핵심 장점", "body": "{feature1}\n{feature2}", "story_stage": "핵심 장점", "layout_variant": "좌우 분할형"},
            {"title": "정직한 산지 이야기", "body": "{origin}에서 정성껏 준비했습니다.", "story_stage": "산지·원산지", "layout_variant": "사진 중심형"},
            {"title": "좋은 상품만 선별", "body": "상태를 확인하고 꼼꼼하게 선별합니다.", "story_stage": "품질 근거", "layout_variant": "정보 카드형"},
            {"title": "사진으로 확인하는 품질", "body": "크기와 상태를 실제 사진으로 확인하세요.", "story_stage": "품질 근거", "layout_variant": "사진 중심형"},
            {"title": "다양하게 즐기는 방법", "body": "{product}을 맛있고 편리하게 활용해 보세요.", "story_stage": "활용 제안", "layout_variant": "좌우 분할형"},
            {"title": "안전하게 포장합니다", "body": "상품 특성에 맞춰 꼼꼼하게 포장합니다.", "story_stage": "포장·배송", "layout_variant": "정보 카드형"},
            {"title": "신선하게 보내드립니다", "body": "{shipping}으로 안전하게 발송합니다.", "story_stage": "구매 안내", "layout_variant": "강조 배너형"},
        ],
    },
    {
        "template_id": "builtin_fruit_premium_8",
        "name": "과일 프리미엄 8컷",
        "category": "과일",
        "description": "당도·과육·선별·선물 가치를 강조하는 프리미엄 과일형",
        "builtin": True,
        "style": "프리미엄",
        "layout": "사진 크게",
        "cut_count": 8,
        "fields": {
            "category": "과일",
            "feature1": "맛과 식감을 살린 선별",
            "feature2": "눈으로 확인하는 신선함",
            "shipping": "한진택배",
        },
        "cuts": [
            {"title": "맛있는 순간을 담은 {product}", "body": "선별부터 포장까지 정성껏 준비했습니다.", "story_stage": "상품 소개", "layout_variant": "풀블리드형"},
            {"title": "풍부한 맛과 식감", "body": "{feature1}", "story_stage": "핵심 장점", "layout_variant": "좌우 분할형"},
            {"title": "과육을 직접 확인하세요", "body": "단면과 과육 상태를 사진으로 보여드립니다.", "story_stage": "품질 근거", "layout_variant": "사진 중심형"},
            {"title": "좋은 상품을 고르는 기준", "body": "상태·크기·숙도를 꼼꼼하게 확인합니다.", "story_stage": "선별 과정", "layout_variant": "정보 카드형"},
            {"title": "{origin}에서 준비했습니다", "body": "산지의 환경과 생산 과정을 소중히 생각합니다.", "story_stage": "산지·원산지", "layout_variant": "사진 중심형"},
            {"title": "선물로도 좋은 구성", "body": "소중한 분께 전하기 좋은 품질로 준비합니다.", "story_stage": "활용 제안", "layout_variant": "좌우 분할형"},
            {"title": "충격을 줄이는 포장", "body": "상품 손상을 줄이도록 안전하게 포장합니다.", "story_stage": "포장·배송", "layout_variant": "정보 카드형"},
            {"title": "신선함을 빠르게", "body": "{shipping}으로 안전하게 보내드립니다.", "story_stage": "구매 안내", "layout_variant": "강조 배너형"},
        ],
    },
    {
        "template_id": "builtin_seaweed_homeshopping_8",
        "name": "김·해조류 홈쇼핑 8컷",
        "category": "수산가공식품",
        "description": "바삭함·원초·활용·구성을 강하게 전달하는 홈쇼핑형",
        "builtin": True,
        "style": "홈쇼핑",
        "layout": "사진 크게",
        "cut_count": 8,
        "fields": {
            "category": "수산가공식품",
            "feature1": "바삭한 식감과 풍부한 향",
            "feature2": "밥반찬부터 간식까지",
            "shipping": "한진택배",
        },
        "cuts": [
            {"title": "바삭함이 다른 {product}", "body": "{feature1}", "story_stage": "상품 소개", "layout_variant": "풀블리드형"},
            {"title": "한 장만 먹어도 만족", "body": "고소한 풍미와 바삭한 식감을 즐겨보세요.", "story_stage": "핵심 장점", "layout_variant": "강조 배너형"},
            {"title": "좋은 원초에서 시작", "body": "{origin} 원료를 꼼꼼하게 확인합니다.", "story_stage": "원재료", "layout_variant": "사진 중심형"},
            {"title": "맛을 살리는 제조 과정", "body": "상품의 특성을 살려 정성껏 제조합니다.", "story_stage": "제조 과정", "layout_variant": "정보 카드형"},
            {"title": "아이부터 어른까지", "body": "{feature2}", "story_stage": "활용 제안", "layout_variant": "좌우 분할형"},
            {"title": "구성을 확인하세요", "body": "구매 전 옵션과 구성 수량을 확인해 주세요.", "story_stage": "상품 구성", "layout_variant": "정보 카드형"},
            {"title": "위생적으로 포장", "body": "신선함과 바삭함을 지키도록 포장합니다.", "story_stage": "포장·배송", "layout_variant": "사진 중심형"},
            {"title": "지금 식탁에 더해보세요", "body": "{shipping}으로 안전하게 발송합니다.", "story_stage": "구매 안내", "layout_variant": "강조 배너형"},
        ],
    },
    {
        "template_id": "builtin_fish_sauce_9",
        "name": "액젓·젓갈 전통발효 9컷",
        "category": "수산가공식품",
        "description": "전통발효·감칠맛·김장·요리 활용을 설명하는 9컷 구성",
        "builtin": True,
        "style": "홈쇼핑",
        "layout": "균형형",
        "cut_count": 9,
        "fields": {
            "category": "수산가공식품",
            "feature1": "깊은 맛과 풍부한 감칠맛",
            "feature2": "김장과 다양한 요리에 활용",
            "shipping": "한진택배",
        },
        "cuts": [
            {"title": "깊은 맛을 담은 {product}", "body": "{feature1}", "story_stage": "상품 소개", "layout_variant": "풀블리드형"},
            {"title": "음식의 맛을 살리는 한 스푼", "body": "국물과 양념에 깊은 풍미를 더합니다.", "story_stage": "핵심 장점", "layout_variant": "강조 배너형"},
            {"title": "원재료를 확인하세요", "body": "제품 표시사항의 원재료와 함량을 확인해 주세요.", "story_stage": "원재료", "layout_variant": "정보 카드형"},
            {"title": "정성을 들인 발효 과정", "body": "시간과 정성을 들여 맛을 완성합니다.", "story_stage": "제조 과정", "layout_variant": "사진 중심형"},
            {"title": "김장에 잘 어울립니다", "body": "{feature2}", "story_stage": "활용 제안", "layout_variant": "좌우 분할형"},
            {"title": "국물 요리에도 활용", "body": "찌개·국·무침 등 다양한 요리에 사용하세요.", "story_stage": "활용 제안", "layout_variant": "좌우 분할형"},
            {"title": "보관 방법을 확인하세요", "body": "개봉 전후 보관 방법을 제품 표시사항에서 확인하세요.", "story_stage": "사용 안내", "layout_variant": "정보 카드형"},
            {"title": "튼튼하고 안전한 포장", "body": "누수와 파손을 줄이도록 꼼꼼하게 포장합니다.", "story_stage": "포장·배송", "layout_variant": "사진 중심형"},
            {"title": "맛있는 요리를 시작하세요", "body": "{shipping}으로 안전하게 발송합니다.", "story_stage": "구매 안내", "layout_variant": "강조 배너형"},
        ],
    },
    {
        "template_id": "builtin_seafood_fresh_8",
        "name": "수산물 신선배송 8컷",
        "category": "수산물",
        "description": "신선도·손질·구성·포장·배송을 강조하는 수산물형",
        "builtin": True,
        "style": "프리미엄",
        "layout": "사진 크게",
        "cut_count": 8,
        "fields": {
            "category": "수산물",
            "feature1": "신선도를 먼저 생각한 상품",
            "feature2": "안전한 포장과 빠른 발송",
            "shipping": "한진택배",
        },
        "cuts": [
            {"title": "신선함을 담은 {product}", "body": "{feature1}", "story_stage": "상품 소개", "layout_variant": "풀블리드형"},
            {"title": "눈으로 확인하는 상태", "body": "실제 상품의 색감과 상태를 사진으로 확인하세요.", "story_stage": "품질 근거", "layout_variant": "사진 중심형"},
            {"title": "{origin}에서 준비", "body": "원산지와 생산 정보를 정확히 확인합니다.", "story_stage": "산지·원산지", "layout_variant": "좌우 분할형"},
            {"title": "손질과 구성 안내", "body": "구매 전 손질 상태와 구성 옵션을 확인하세요.", "story_stage": "상품 구성", "layout_variant": "정보 카드형"},
            {"title": "다양한 요리에 활용", "body": "상품 특성에 맞는 조리법으로 즐겨보세요.", "story_stage": "활용 제안", "layout_variant": "좌우 분할형"},
            {"title": "신선도를 지키는 포장", "body": "온도와 상품 특성을 고려해 안전하게 포장합니다.", "story_stage": "포장·배송", "layout_variant": "사진 중심형"},
            {"title": "수령 후 확인사항", "body": "수령 즉시 상품 상태와 보관 방법을 확인하세요.", "story_stage": "사용 안내", "layout_variant": "정보 카드형"},
            {"title": "빠르고 안전하게 발송", "body": "{shipping}으로 보내드립니다.", "story_stage": "구매 안내", "layout_variant": "강조 배너형"},
        ],
    },
    {
        "template_id": "builtin_processed_simple_8",
        "name": "가공식품 심플 8컷",
        "category": "가공식품",
        "description": "원재료·제조·사용법·표시사항을 깔끔하게 전달하는 기본형",
        "builtin": True,
        "style": "심플",
        "layout": "균형형",
        "cut_count": 8,
        "fields": {
            "category": "가공식품",
            "feature1": "원재료의 장점을 담은 제품",
            "feature2": "간편하게 즐기는 활용성",
            "shipping": "한진택배",
        },
        "cuts": [
            {"title": "일상에 편리한 {product}", "body": "{feature1}", "story_stage": "상품 소개", "layout_variant": "풀블리드형"},
            {"title": "핵심 특징을 확인하세요", "body": "{feature1}\n{feature2}", "story_stage": "핵심 장점", "layout_variant": "정보 카드형"},
            {"title": "원재료와 함량", "body": "제품 표시사항의 원재료명과 함량을 확인하세요.", "story_stage": "원재료", "layout_variant": "정보 카드형"},
            {"title": "제조 과정과 품질관리", "body": "위생과 품질을 고려해 제조합니다.", "story_stage": "제조 과정", "layout_variant": "좌우 분할형"},
            {"title": "간편한 사용 방법", "body": "{product}을 편리하게 활용해 보세요.", "story_stage": "활용 제안", "layout_variant": "사진 중심형"},
            {"title": "보관과 소비기한", "body": "제품 표시사항의 보관 방법과 소비기한을 확인하세요.", "story_stage": "사용 안내", "layout_variant": "정보 카드형"},
            {"title": "안전한 포장", "body": "파손과 변질을 줄이도록 꼼꼼하게 포장합니다.", "story_stage": "포장·배송", "layout_variant": "좌우 분할형"},
            {"title": "주문 전 최종 확인", "body": "옵션·용량·배송정보를 확인한 뒤 주문해 주세요.", "story_stage": "구매 안내", "layout_variant": "강조 배너형"},
        ],
    },
]


def validate_project_template(template: dict[str, Any]) -> dict[str, Any]:
    issues = []
    required = ["template_id", "name", "category", "style", "layout", "cut_count", "cuts"]
    for key in required:
        if key not in template:
            issues.append(f"필수 항목 누락: {key}")

    if template.get("style") not in STYLE_PRESETS:
        issues.append("지원하지 않는 스타일입니다.")
    if template.get("layout") not in {"균형형", "사진 크게"}:
        issues.append("지원하지 않는 사진 배치입니다.")

    cuts = template.get("cuts", [])
    try:
        cut_count = int(template.get("cut_count", len(cuts)))
    except Exception:
        cut_count = 0
        issues.append("컷 수가 숫자가 아닙니다.")

    if not 1 <= cut_count <= 10:
        issues.append("컷 수는 1~10이어야 합니다.")
    if len(cuts) != cut_count:
        issues.append(f"컷 수 불일치: 설정 {cut_count} / 실제 {len(cuts)}")

    for index, cut in enumerate(cuts, 1):
        if not isinstance(cut, dict):
            issues.append(f"{index}컷 형식 오류")
            continue
        if not str(cut.get("title", "")).strip():
            issues.append(f"{index}컷 제목 누락")
        if not str(cut.get("body", "")).strip():
            issues.append(f"{index}컷 본문 누락")

    return {"valid": not issues, "issues": issues}


def normalize_project_template(template: dict[str, Any]) -> dict[str, Any]:
    item = copy.deepcopy(template)
    item.setdefault("template_id", f"custom_{datetime.now().strftime('%Y%m%d%H%M%S%f')}")
    item.setdefault("name", "사용자 템플릿")
    item.setdefault("category", "식품")
    item.setdefault("description", "")
    item.setdefault("builtin", False)
    item.setdefault("style", "프리미엄")
    item.setdefault("layout", "균형형")
    item.setdefault("fields", {})
    item.setdefault("cuts", [])
    item["cut_count"] = max(1, min(int(item.get("cut_count", len(item["cuts"]) or 8)), 10))
    normalized_cuts = []
    for index, raw in enumerate(item["cuts"][: item["cut_count"]], 1):
        cut = dict(raw)
        cut.setdefault("title", f"{index}컷")
        cut.setdefault("body", "{product}")
        cut.setdefault("story_stage", "상품 소개")
        cut.setdefault("layout_variant", "기본 카드형")
        cut.setdefault("title_size", 33)
        cut.setdefault("body_size", 39)
        cut.setdefault("text_align", "center")
        cut.setdefault("image_scale", 1.0)
        normalized_cuts.append(cut)
    item["cuts"] = normalized_cuts
    item["cut_count"] = len(normalized_cuts)
    item.setdefault("created_at", datetime.now().isoformat(timespec="seconds"))
    return item


def load_custom_project_templates(
    path: str | Path = CUSTOM_TEMPLATE_FILE,
) -> list[dict[str, Any]]:
    path = Path(path)
    if not path.exists():
        return []
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        templates = data.get("templates", data) if isinstance(data, dict) else data
        if not isinstance(templates, list):
            return []
        return [normalize_project_template(item) for item in templates if isinstance(item, dict)]
    except Exception:
        return []


def save_custom_project_templates(
    templates: list[dict[str, Any]],
    path: str | Path = CUSTOM_TEMPLATE_FILE,
) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "engine_version": TEMPLATE_ENGINE_VERSION,
        "updated_at": datetime.now().isoformat(timespec="seconds"),
        "templates": [normalize_project_template(item) for item in templates],
    }
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    temporary.replace(path)
    return path


def list_project_templates(
    include_builtin: bool = True,
    include_custom: bool = True,
    custom_path: str | Path = CUSTOM_TEMPLATE_FILE,
) -> list[dict[str, Any]]:
    templates = []
    if include_builtin:
        templates.extend(copy.deepcopy(BUILTIN_PROJECT_TEMPLATES))
    if include_custom:
        templates.extend(load_custom_project_templates(custom_path))
    return [normalize_project_template(item) for item in templates]


def find_project_template(
    template_id: str,
    custom_path: str | Path = CUSTOM_TEMPLATE_FILE,
) -> dict[str, Any] | None:
    for template in list_project_templates(True, True, custom_path):
        if template.get("template_id") == template_id:
            return template
    return None


def create_template_from_project(
    project: Project,
    name: str,
    description: str = "",
    template_id: str = "",
) -> dict[str, Any]:
    if not name.strip():
        raise ValueError("템플릿 이름이 필요합니다.")
    fields = {
        key: value
        for key, value in project.fields.items()
        if key not in {"product", "price", "seller_code"} and str(value or "").strip()
    }
    cuts = []
    for cut in project.cuts:
        cuts.append({
            "title": cut.title,
            "body": cut.body,
            "story_stage": cut.story_stage,
            "layout_variant": cut.layout_variant,
            "title_size": cut.title_size,
            "body_size": cut.body_size,
            "text_align": cut.text_align,
            "image_scale": cut.image_scale,
        })
    template = {
        "template_id": template_id or f"custom_{datetime.now().strftime('%Y%m%d%H%M%S%f')}",
        "name": name.strip(),
        "category": project.fields.get("category", "") or "식품",
        "description": description.strip(),
        "builtin": False,
        "style": project.style,
        "layout": project.layout,
        "cut_count": len(cuts),
        "fields": fields,
        "cuts": cuts,
        "created_at": datetime.now().isoformat(timespec="seconds"),
    }
    validation = validate_project_template(template)
    if not validation["valid"]:
        raise ValueError("템플릿 생성 실패: " + ", ".join(validation["issues"]))
    return normalize_project_template(template)


def upsert_custom_project_template(
    template: dict[str, Any],
    path: str | Path = CUSTOM_TEMPLATE_FILE,
) -> list[dict[str, Any]]:
    template = normalize_project_template(template)
    validation = validate_project_template(template)
    if not validation["valid"]:
        raise ValueError("템플릿 형식 오류: " + ", ".join(validation["issues"]))
    templates = [
        item for item in load_custom_project_templates(path)
        if item.get("template_id") != template.get("template_id")
        and item.get("name") != template.get("name")
    ]
    templates.append(template)
    templates.sort(key=lambda item: item.get("name", ""))
    save_custom_project_templates(templates, path)
    return templates


def delete_custom_project_template(
    template_id: str,
    path: str | Path = CUSTOM_TEMPLATE_FILE,
) -> bool:
    templates = load_custom_project_templates(path)
    remaining = [item for item in templates if item.get("template_id") != template_id]
    changed = len(remaining) != len(templates)
    if changed:
        save_custom_project_templates(remaining, path)
    return changed


def _template_context(fields: dict[str, str]) -> dict[str, str]:
    context = dict(DEFAULTS)
    context.update({key: str(value or "") for key, value in fields.items()})
    return context


def project_from_template(
    template: dict[str, Any],
    product_name: str = "",
    origin: str = "",
    shipping: str = "",
    images: list[str] | None = None,
) -> Project:
    template = normalize_project_template(template)
    validation = validate_project_template(template)
    if not validation["valid"]:
        raise ValueError("사용할 수 없는 템플릿입니다: " + ", ".join(validation["issues"]))

    fields = dict(DEFAULTS)
    fields.update(template.get("fields", {}))
    if product_name.strip():
        fields["product"] = product_name.strip()
    if origin.strip():
        fields["origin"] = origin.strip()
    if shipping.strip():
        fields["shipping"] = shipping.strip()

    context = _template_context(fields)
    cuts = []
    for raw in template["cuts"]:
        title = str(raw.get("title", "")).format(**context)
        body = str(raw.get("body", "")).format(**context)
        cuts.append(Cut(
            title=title,
            body=body,
            photo_index=0,
            title_size=int(raw.get("title_size", 33)),
            body_size=int(raw.get("body_size", 39)),
            text_align=str(raw.get("text_align", "center")),
            image_scale=float(raw.get("image_scale", 1.0)),
            layout_variant=str(raw.get("layout_variant", "기본 카드형")),
            story_stage=str(raw.get("story_stage", "상품 소개")),
        ))

    project = Project(
        fields=fields,
        images=list(images or []),
        cuts=cuts,
        style=template["style"],
        layout=template["layout"],
        ai_analysis={
            "template_engine_version": TEMPLATE_ENGINE_VERSION,
            "template_id": template["template_id"],
            "template_name": template["name"],
        },
    )
    if project.images:
        apply_recommended_images(project, avoid_duplicates=True)
    return project


def recommend_project_templates(
    category: str,
    product_name: str = "",
    custom_path: str | Path = CUSTOM_TEMPLATE_FILE,
) -> list[dict[str, Any]]:
    category = str(category or "").strip()
    product_name = str(product_name or "").lower()
    scored = []
    for template in list_project_templates(True, True, custom_path):
        score = 0
        reasons = []
        if category and template.get("category") == category:
            score += 60
            reasons.append("품목 일치")
        if template.get("category") == "수산가공식품" and any(keyword in product_name for keyword in ["김", "액젓", "젓갈", "미역", "다시마"]):
            score += 25
            reasons.append("상품명 연관")
        if template.get("category") == "농산물" and any(keyword in product_name for keyword in ["양파", "감자", "옥수수", "호박", "마늘"]):
            score += 25
            reasons.append("상품명 연관")
        if template.get("category") == "과일" and any(keyword in product_name for keyword in ["무화과", "사과", "배", "복숭아", "포도", "감귤"]):
            score += 25
            reasons.append("상품명 연관")
        if template.get("builtin"):
            score += 5
        scored.append({
            **copy.deepcopy(template),
            "recommendation_score": score,
            "recommendation_reasons": reasons or ["일반 추천"],
        })
    return sorted(scored, key=lambda item: (item["recommendation_score"], item["name"]), reverse=True)


def export_template_pack(
    templates: list[dict[str, Any]],
    path: str | Path,
) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "pack_version": TEMPLATE_PACK_VERSION,
        "engine_version": TEMPLATE_ENGINE_VERSION,
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "template_count": len(templates),
        "templates": [normalize_project_template(item) for item in templates],
    }
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return path


def import_template_pack(
    path: str | Path,
    custom_path: str | Path = CUSTOM_TEMPLATE_FILE,
) -> dict[str, Any]:
    path = Path(path)
    data = json.loads(path.read_text(encoding="utf-8"))
    templates = data.get("templates", [])
    if not isinstance(templates, list):
        raise ValueError("템플릿 묶음 형식이 올바르지 않습니다.")
    imported = []
    rejected = []
    current = load_custom_project_templates(custom_path)
    for raw in templates:
        if not isinstance(raw, dict):
            rejected.append({"name": "", "issues": ["템플릿 형식 오류"]})
            continue
        item = normalize_project_template(raw)
        item["builtin"] = False
        validation = validate_project_template(item)
        if validation["valid"]:
            current = [
                existing for existing in current
                if existing.get("template_id") != item.get("template_id")
                and existing.get("name") != item.get("name")
            ]
            current.append(item)
            imported.append(item["name"])
        else:
            rejected.append({"name": item.get("name", ""), "issues": validation["issues"]})
    save_custom_project_templates(current, custom_path)
    return {
        "imported_count": len(imported),
        "imported": imported,
        "rejected_count": len(rejected),
        "rejected": rejected,
    }


def template_library_summary(
    custom_path: str | Path = CUSTOM_TEMPLATE_FILE,
) -> dict[str, Any]:
    templates = list_project_templates(True, True, custom_path)
    categories = {}
    for item in templates:
        category = item.get("category", "식품")
        categories[category] = categories.get(category, 0) + 1
    return {
        "engine_version": TEMPLATE_ENGINE_VERSION,
        "total": len(templates),
        "builtin_count": sum(bool(item.get("builtin")) for item in templates),
        "custom_count": sum(not bool(item.get("builtin")) for item in templates),
        "categories": categories,
    }


REVISION_ENGINE_VERSION = "5.9"
REVISION_SCHEMA_VERSION = 1
REVISION_HISTORY_FILENAME = "cut_revision_history.json"
FINAL_APPROVAL_FILENAME = "final_approval_record.json"


def cut_revision_payload(cut: Cut) -> dict[str, Any]:
    return {
        "title": cut.title,
        "body": cut.body,
        "photo_index": cut.photo_index,
        "approved": cut.approved,
        "image_scale": cut.image_scale,
        "image_offset_x": cut.image_offset_x,
        "image_offset_y": cut.image_offset_y,
        "title_size": cut.title_size,
        "body_size": cut.body_size,
        "text_align": cut.text_align,
        "body_offset_y": cut.body_offset_y,
        "layout_variant": cut.layout_variant,
        "story_stage": cut.story_stage,
        "review_status": cut.review_status,
        "review_note": cut.review_note,
        "reviewed_at": cut.reviewed_at,
    }


def cut_revision_fingerprint(cut: Cut) -> str:
    return hashlib.sha256(
        json.dumps(
            cut_revision_payload(cut),
            ensure_ascii=False,
            sort_keys=True,
        ).encode("utf-8")
    ).hexdigest()


def revision_history_path(
    project_path: str | Path | None = None,
    folder: str | Path | None = None,
) -> Path:
    if folder:
        return Path(folder) / REVISION_HISTORY_FILENAME
    if project_path:
        path = Path(project_path)
        return path.parent / f"{path.stem}_{REVISION_HISTORY_FILENAME}"
    return CONFIG_DIR / REVISION_HISTORY_FILENAME


def load_cut_revision_history(path: str | Path) -> dict[str, Any]:
    path = Path(path)
    if not path.exists():
        return {
            "schema_version": REVISION_SCHEMA_VERSION,
            "engine_version": REVISION_ENGINE_VERSION,
            "project_fingerprint": "",
            "cuts": {},
        }
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            raise ValueError("버전 기록 형식 오류")
        data.setdefault("cuts", {})
        return data
    except Exception:
        return {
            "schema_version": REVISION_SCHEMA_VERSION,
            "engine_version": REVISION_ENGINE_VERSION,
            "project_fingerprint": "",
            "cuts": {},
            "corrupted": True,
        }


def save_cut_revision_history(
    history: dict[str, Any],
    path: str | Path,
) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    history = dict(history)
    history["schema_version"] = REVISION_SCHEMA_VERSION
    history["engine_version"] = REVISION_ENGINE_VERSION
    history["updated_at"] = datetime.now().isoformat(timespec="seconds")
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(history, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    temporary.replace(path)
    return path


def snapshot_cut_revision(
    project: Project,
    cut_index: int,
    history_path: str | Path,
    reason: str = "수동 저장",
    author: str = "사용자",
    force: bool = False,
) -> dict[str, Any]:
    if not 0 <= int(cut_index) < len(project.cuts):
        raise IndexError("컷 번호가 올바르지 않습니다.")

    cut = project.cuts[int(cut_index)]
    fingerprint = cut_revision_fingerprint(cut)
    history = load_cut_revision_history(history_path)
    history["project_fingerprint"] = project_fingerprint(project)
    key = str(int(cut_index))
    revisions = list(history.setdefault("cuts", {}).get(key, []))

    if revisions and revisions[-1].get("fingerprint") == fingerprint and not force:
        return {
            "created": False,
            "reason": "직전 버전과 변경 내용이 같습니다.",
            "revision": revisions[-1],
            "revision_count": len(revisions),
        }

    revision_number = len(revisions) + 1
    revision = {
        "revision_number": revision_number,
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "reason": str(reason or "수동 저장"),
        "author": str(author or "사용자"),
        "fingerprint": fingerprint,
        "cut_index": int(cut_index),
        "cut_number": int(cut_index) + 1,
        "data": cut_revision_payload(cut),
    }
    revisions.append(revision)
    history["cuts"][key] = revisions
    save_cut_revision_history(history, history_path)

    return {
        "created": True,
        "revision": revision,
        "revision_count": len(revisions),
    }


def snapshot_all_cut_revisions(
    project: Project,
    history_path: str | Path,
    reason: str = "전체 버전 저장",
    author: str = "사용자",
) -> dict[str, Any]:
    results = [
        snapshot_cut_revision(
            project,
            index,
            history_path,
            reason=reason,
            author=author,
        )
        for index in range(len(project.cuts))
    ]
    return {
        "total": len(results),
        "created_count": sum(bool(item["created"]) for item in results),
        "skipped_count": sum(not bool(item["created"]) for item in results),
        "results": results,
        "history_path": str(history_path),
    }


def list_cut_revisions(
    history_path: str | Path,
    cut_index: int,
) -> list[dict[str, Any]]:
    history = load_cut_revision_history(history_path)
    return list(history.get("cuts", {}).get(str(int(cut_index)), []))


def restore_cut_revision(
    project: Project,
    cut_index: int,
    revision_number: int,
    history_path: str | Path,
    snapshot_before_restore: bool = True,
) -> dict[str, Any]:
    cut_index = int(cut_index)
    if not 0 <= cut_index < len(project.cuts):
        raise IndexError("컷 번호가 올바르지 않습니다.")

    revisions = list_cut_revisions(history_path, cut_index)
    selected = next(
        (
            item for item in revisions
            if int(item.get("revision_number", 0)) == int(revision_number)
        ),
        None,
    )
    if not selected:
        raise ValueError("선택한 컷 버전을 찾을 수 없습니다.")

    before = None
    if snapshot_before_restore:
        before = snapshot_cut_revision(
            project,
            cut_index,
            history_path,
            reason=f"{revision_number}버전 복원 전 자동백업",
            author="시스템",
            force=True,
        )

    data = selected["data"]
    current = project.cuts[cut_index]
    for key, value in data.items():
        if hasattr(current, key):
            setattr(current, key, value)

    current.approved = current.review_status == "승인" or bool(current.approved)
    return {
        "restored": True,
        "cut_index": cut_index,
        "revision_number": int(revision_number),
        "restored_data": cut_revision_payload(current),
        "backup_before_restore": before,
    }


def compare_cut_revisions(
    first: dict[str, Any],
    second: dict[str, Any],
) -> dict[str, Any]:
    first_data = first.get("data", first)
    second_data = second.get("data", second)
    keys = sorted(set(first_data) | set(second_data))
    differences = []

    for key in keys:
        before = first_data.get(key)
        after = second_data.get(key)
        if before != after:
            differences.append({
                "field": key,
                "before": before,
                "after": after,
            })

    return {
        "different": bool(differences),
        "difference_count": len(differences),
        "differences": differences,
    }


def compare_current_cut_to_revision(
    project: Project,
    cut_index: int,
    revision: dict[str, Any],
) -> dict[str, Any]:
    if not 0 <= int(cut_index) < len(project.cuts):
        raise IndexError("컷 번호가 올바르지 않습니다.")
    return compare_cut_revisions(
        revision,
        {"data": cut_revision_payload(project.cuts[int(cut_index)])},
    )


def revision_history_summary(
    project: Project,
    history_path: str | Path,
) -> dict[str, Any]:
    history = load_cut_revision_history(history_path)
    cut_rows = []
    total_revisions = 0

    for index, cut in enumerate(project.cuts):
        revisions = list(history.get("cuts", {}).get(str(index), []))
        total_revisions += len(revisions)
        latest = revisions[-1] if revisions else None
        changed_after_latest = False
        if latest:
            changed_after_latest = (
                latest.get("fingerprint") != cut_revision_fingerprint(cut)
            )
        cut_rows.append({
            "cut_number": index + 1,
            "title": cut.title,
            "revision_count": len(revisions),
            "latest_at": latest.get("created_at", "") if latest else "",
            "latest_reason": latest.get("reason", "") if latest else "",
            "changed_after_latest": changed_after_latest,
            "review_status": cut.review_status,
        })

    return {
        "engine_version": REVISION_ENGINE_VERSION,
        "total_cuts": len(project.cuts),
        "total_revisions": total_revisions,
        "cuts_with_revisions": sum(
            item["revision_count"] > 0 for item in cut_rows
        ),
        "changed_after_latest_count": sum(
            item["changed_after_latest"] for item in cut_rows
        ),
        "cuts": cut_rows,
        "corrupted": bool(history.get("corrupted", False)),
    }


def final_approval_gate(project: Project) -> dict[str, Any]:
    review = review_summary(project)
    blockers = []
    warnings = []

    if not project.cuts:
        blockers.append("상세페이지 컷이 없습니다.")
    if not project.images:
        blockers.append("상품 사진이 없습니다.")
    if review["counts"]["검수 전"]:
        blockers.append(
            f"검수 전 컷이 {review['counts']['검수 전']}개 있습니다."
        )
    if review["counts"]["수정 필요"]:
        blockers.append(
            f"수정 필요 컷이 {review['counts']['수정 필요']}개 있습니다."
        )
    if review["counts"]["승인"] != review["total"]:
        blockers.append("모든 컷이 승인되지 않았습니다.")

    for key, label in {
        "product": "상품명",
        "category": "품목",
        "origin": "원산지",
        "shipping": "배송정보",
    }.items():
        value = str(project.fields.get(key, "") or "").strip()
        if not value or "확인 필요" in value:
            blockers.append(f"{label}을 확인해야 합니다.")

    for index, cut in enumerate(project.cuts, 1):
        if not cut.reviewed_at:
            warnings.append(f"{index}컷의 검수 시각 기록이 없습니다.")
        if len(cut.body.strip()) > 120:
            warnings.append(f"{index}컷 본문이 길어 모바일 검수가 필요합니다.")

    return {
        "ready": not blockers,
        "blockers": blockers,
        "warnings": warnings,
        "review": review,
    }


def create_final_approval_record(
    project: Project,
    approver: str,
    note: str = "",
) -> dict[str, Any]:
    gate = final_approval_gate(project)
    if not gate["ready"]:
        raise ValueError(
            "최종 승인 조건을 충족하지 못했습니다: "
            + " / ".join(gate["blockers"])
        )

    return {
        "record_version": REVISION_ENGINE_VERSION,
        "approved_at": datetime.now().isoformat(timespec="seconds"),
        "approver": str(approver or "사용자"),
        "note": str(note or ""),
        "product": project.fields.get("product", ""),
        "category": project.fields.get("category", ""),
        "project_fingerprint": project_fingerprint(project),
        "cut_fingerprints": [
            cut_revision_fingerprint(cut)
            for cut in project.cuts
        ],
        "review": gate["review"],
        "warnings": gate["warnings"],
    }


def validate_final_approval_record(
    project: Project,
    record: dict[str, Any],
) -> dict[str, Any]:
    current_project_fingerprint = project_fingerprint(project)
    current_cut_fingerprints = [
        cut_revision_fingerprint(cut)
        for cut in project.cuts
    ]
    project_matches = (
        record.get("project_fingerprint") == current_project_fingerprint
    )
    cuts_match = (
        record.get("cut_fingerprints") == current_cut_fingerprints
    )
    return {
        "valid": project_matches and cuts_match,
        "project_matches": project_matches,
        "cuts_match": cuts_match,
        "approved_at": record.get("approved_at", ""),
        "approver": record.get("approver", ""),
    }


def export_final_release_package(
    project: Project,
    output_folder: str | Path,
    approver: str,
    approval_note: str = "",
    history_path: str | Path | None = None,
) -> dict[str, Any]:
    output_folder = Path(output_folder)
    output_folder.mkdir(parents=True, exist_ok=True)

    gate = final_approval_gate(project)
    if not gate["ready"]:
        raise ValueError(
            "최종본 저장 불가: " + " / ".join(gate["blockers"])
        )

    record = create_final_approval_record(
        project,
        approver=approver,
        note=approval_note,
    )

    product = sanitize_name(
        project.fields.get("product", "") or "상품"
    )
    release_folder = output_folder / f"{product}_최종승인본"
    if release_folder.exists():
        shutil.rmtree(release_folder)
    release_folder.mkdir(parents=True, exist_ok=True)

    export_result = export_all_formats(project, release_folder)
    project_path = release_folder / f"{product}_최종.nongjak.json"
    save_project(project, project_path)

    approval_path = release_folder / FINAL_APPROVAL_FILENAME
    approval_path.write_text(
        json.dumps(record, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    review_path = export_review_report(
        project,
        release_folder / "최종_검수보고서.json",
    )

    revision_summary_path = ""
    if history_path:
        revision_summary = revision_history_summary(project, history_path)
        revision_summary_file = release_folder / "컷_버전이력_요약.json"
        revision_summary_file.write_text(
            json.dumps(
                revision_summary,
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )
        revision_summary_path = str(revision_summary_file)

    zip_path = output_folder / f"{product}_최종승인본.zip"
    with zipfile.ZipFile(
        zip_path,
        "w",
        zipfile.ZIP_DEFLATED,
    ) as archive:
        for file in release_folder.rglob("*"):
            if file.is_file():
                archive.write(
                    file,
                    file.relative_to(release_folder),
                )

    return {
        "ready": True,
        "folder": str(release_folder),
        "zip": str(zip_path),
        "approval_record": str(approval_path),
        "review_report": str(review_path),
        "revision_summary": revision_summary_path,
        "exports": export_result,
    }


def export_revision_report(
    project: Project,
    history_path: str | Path,
    output_path: str | Path,
) -> Path:
    history = load_cut_revision_history(history_path)
    report = {
        "engine_version": REVISION_ENGINE_VERSION,
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "product": project.fields.get("product", ""),
        "summary": revision_history_summary(
            project,
            history_path,
        ),
        "history": history,
    }
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(
        json.dumps(report, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return output_path


PRODUCT_INTELLIGENCE_VERSION = "6.0"

COPY_STYLE_PROFILES = {
    "홈쇼핑형": {
        "opening": "지금 주목하세요",
        "tone": "직관적이고 힘 있는 판매 문구",
        "cta": "지금 바로 만나보세요",
    },
    "프리미엄형": {
        "opening": "좋은 상품을 고르는 기준",
        "tone": "차분하고 신뢰감 있는 고급 문구",
        "cta": "정성껏 준비한 품질을 확인하세요",
    },
    "감성형": {
        "opening": "산지의 마음을 담았습니다",
        "tone": "따뜻하고 자연스러운 이야기 문구",
        "cta": "일상에 맛있는 순간을 더해보세요",
    },
    "심플형": {
        "opening": "필요한 장점만 분명하게",
        "tone": "짧고 명확한 정보 중심 문구",
        "cta": "상품정보를 확인하고 선택하세요",
    },
    "공구형": {
        "opening": "함께 구매하기 좋은 구성",
        "tone": "혜택과 구성을 빠르게 전달하는 문구",
        "cta": "구성과 옵션을 확인하세요",
    },
    "라이브커머스형": {
        "opening": "사진으로 직접 확인해 보세요",
        "tone": "말하듯 자연스럽고 현장감 있는 문구",
        "cta": "궁금한 점을 확인하고 주문하세요",
    },
}

CATEGORY_CUSTOMER_CONCERNS = {
    "농산물": [
        "실제 크기와 상태가 사진과 비슷한가요?",
        "수확 후 언제 발송되나요?",
        "흠과·크기 혼합 여부는 어떻게 되나요?",
        "보관은 어떻게 해야 하나요?",
    ],
    "과일": [
        "당도와 숙도는 어느 정도인가요?",
        "멍이나 눌림 없이 배송되나요?",
        "크기와 개수는 어떻게 구성되나요?",
        "수령 후 바로 먹어도 되나요?",
    ],
    "수산물": [
        "신선도와 원산지를 믿을 수 있나요?",
        "손질 상태와 실제 중량은 어떻게 되나요?",
        "냉장·냉동 중 어떤 상태로 배송되나요?",
        "수령 후 보관과 조리 방법은 무엇인가요?",
    ],
    "수산가공식품": [
        "원재료와 함량은 어떻게 되나요?",
        "맛이 너무 짜거나 강하지 않나요?",
        "보관 방법과 소비기한은 어떻게 되나요?",
        "어떤 요리에 활용하기 좋나요?",
    ],
    "축산물": [
        "부위와 등급을 확인할 수 있나요?",
        "냉장·냉동 배송 상태는 안전한가요?",
        "실제 중량과 포장 단위는 어떻게 되나요?",
        "해동과 조리 방법은 무엇인가요?",
    ],
    "가공식품": [
        "원재료와 첨가물을 확인할 수 있나요?",
        "중량과 구성은 정확한가요?",
        "소비기한과 보관 방법은 어떻게 되나요?",
        "섭취·조리 방법은 간편한가요?",
    ],
    "식품": [
        "실제 구성과 중량은 어떻게 되나요?",
        "원산지와 원재료를 확인할 수 있나요?",
        "보관·배송 조건은 안전한가요?",
        "구매 전 꼭 알아야 할 사항은 무엇인가요?",
    ],
}

CATEGORY_TRUST_FACTORS = {
    "농산물": ["원산지 표시", "실제 상품 사진", "선별 기준", "수확·발송 안내", "포장 방식"],
    "과일": ["산지 표시", "과육·단면 사진", "크기·개수 안내", "선별 과정", "충격 방지 포장"],
    "수산물": ["원산지", "손질 상태", "실중량 기준", "보관 온도", "신선 포장"],
    "수산가공식품": ["원재료명", "제조 정보", "식품 유형", "소비기한", "활용 예시"],
    "축산물": ["부위·등급", "원산지", "중량", "냉장·냉동 상태", "위생 포장"],
    "가공식품": ["원재료·함량", "제조원", "영양·표시사항", "소비기한", "사용 방법"],
    "식품": ["정확한 상품정보", "원산지·원재료", "실제 사진", "배송·보관 안내", "판매자 연락처"],
}


def generate_product_title_set(
    fields: dict[str, str],
    analysis: dict[str, Any] | None = None,
    count: int = 20,
) -> list[dict[str, Any]]:
    analysis = analysis or {}
    product = _clean_keyword(fields.get("product", "")) or "상품명"
    category = _clean_keyword(fields.get("category", ""))
    origin = _clean_keyword(fields.get("origin", ""))
    feature1 = _clean_keyword(fields.get("feature1", "")) or _clean_keyword(
        analysis.get("copy", {}).get("feature1", "")
    )
    feature2 = _clean_keyword(fields.get("feature2", "")) or _clean_keyword(
        analysis.get("copy", {}).get("feature2", "")
    )
    shipping = _clean_keyword(fields.get("shipping", ""))

    invalid = {"확인 필요", "원산지 확인 필요", "배송정보 확인 필요"}
    origin = "" if origin in invalid or "확인 필요" in origin else origin
    shipping = "" if "확인 필요" in shipping else shipping

    modifiers = _unique_terms([
        origin,
        feature1,
        feature2,
        "산지직송" if category in {"농산물", "과일", "수산물"} else "",
        "선별",
        "신선배송" if category in {"농산물", "과일", "수산물", "축산물"} else "",
        "프리미엄",
        "가정용",
        "선물용" if category in {"과일", "축산물"} else "",
        category,
    ])

    patterns = [
        [origin, product, feature1],
        [product, feature1, feature2],
        [origin, product, "산지직송"],
        [product, "선별", feature1],
        [product, feature2],
        ["프리미엄", product, feature1],
        [origin, product, category],
        [product, "가정용", feature1],
        [product, "선물용", feature2],
        [origin, product, "신선배송"],
        [product, category, feature1],
        [feature1, product],
        [product, feature1],
        [origin, product],
        [product, feature2, shipping],
        [product, "꼼꼼한 포장"],
        [product, "실속 구성", feature1],
        [origin, "프리미엄", product],
        [product, "추천", feature1],
        [product, "온라인 주문", feature2],
        [product] + modifiers[:3],
        [origin, product] + modifiers[1:4],
    ]

    results = {}
    for pattern in patterns:
        title = " ".join(_unique_terms([value for value in pattern if value]))
        if not title:
            continue
        title = title[:100].strip()
        score = 45
        score += 20 if product in title else 0
        score += 10 if origin and origin in title else 0
        score += 10 if feature1 and feature1 in title else 0
        score += 7 if feature2 and feature2 in title else 0
        score += 5 if 12 <= len(title) <= 48 else 0
        score -= max(0, len(title) - 70) // 4
        duplicated_words = len(title.split()) - len(set(title.split()))
        score -= duplicated_words * 4
        item = {
            "title": title,
            "score": max(0, min(100, score)),
            "length": len(title),
            "keywords": [term for term in modifiers if term and term in title],
        }
        if title not in results or item["score"] > results[title]["score"]:
            results[title] = item

    ordered = sorted(results.values(), key=lambda item: (item["score"], -item["length"]), reverse=True)
    return ordered[: max(1, int(count))]


def generate_search_keyword_plan(
    fields: dict[str, str],
    analysis: dict[str, Any] | None = None,
) -> dict[str, Any]:
    analysis = analysis or {}
    product = _clean_keyword(fields.get("product", ""))
    category = _clean_keyword(fields.get("category", ""))
    origin = _clean_keyword(fields.get("origin", ""))
    feature1 = _clean_keyword(fields.get("feature1", ""))
    feature2 = _clean_keyword(fields.get("feature2", ""))

    if "확인 필요" in origin:
        origin = ""

    primary = _unique_terms([
        product,
        f"{origin} {product}".strip(),
        f"{product} 추천".strip(),
        f"{product} 구매".strip(),
        category,
    ])
    intent = _unique_terms([
        f"{product} 산지직송" if category in {"농산물", "과일", "수산물"} else "",
        f"{product} 선물" if category in {"과일", "축산물"} else "",
        f"{product} 가정용",
        f"{product} 온라인 주문",
        f"{product} 배송",
    ])
    feature = _unique_terms([
        f"{product} {feature1}".strip(),
        f"{product} {feature2}".strip(),
        feature1,
        feature2,
    ])
    tags = _unique_terms(
        [product, category, origin, feature1, feature2]
        + analysis.get("copy", {}).get("search_keywords", [])
    )[:20]

    return {
        "primary_keywords": [value for value in primary if value],
        "purchase_intent_keywords": [value for value in intent if value],
        "feature_keywords": [value for value in feature if value],
        "recommended_tags": [value for value in tags if value],
        "negative_guidance": [
            "실제 상품에 없는 인증·효능 키워드는 사용하지 않습니다.",
            "상품명에 같은 단어를 반복하지 않습니다.",
            "원산지·중량·등급은 실제 정보와 일치할 때만 사용합니다.",
        ],
    }


def analyze_customer_purchase_psychology(
    fields: dict[str, str],
) -> dict[str, Any]:
    category = fields.get("category", "") or "식품"
    concerns = list(CATEGORY_CUSTOMER_CONCERNS.get(category, CATEGORY_CUSTOMER_CONCERNS["식품"]))
    trust = list(CATEGORY_TRUST_FACTORS.get(category, CATEGORY_TRUST_FACTORS["식품"]))

    missing_answers = []
    mapping = {
        "origin": "원산지 정보",
        "weight": "중량·용량 정보",
        "options": "옵션·구성 정보",
        "shipping": "배송 정보",
        "shelf_life": "소비기한 정보",
        "ingredients": "원재료 정보",
    }
    for key, label in mapping.items():
        value = str(fields.get(key, "") or "").strip()
        if not value or "확인 필요" in value:
            missing_answers.append(label)

    motivations = _unique_terms([
        fields.get("feature1", ""),
        fields.get("feature2", ""),
        "실제 상품을 사진으로 확인",
        "정확한 구성과 배송 안내",
        "구매 후 활용이 쉬움",
    ])

    return {
        "customer_questions": concerns,
        "purchase_hesitations": [
            "사진과 실제 상품이 다를 수 있다는 걱정",
            "중량·구성·크기가 불명확하다는 걱정",
            "배송 중 파손이나 신선도 저하에 대한 걱정",
            "원산지·원재료·제조 정보에 대한 불확실성",
        ],
        "trust_factors": trust,
        "purchase_motivations": motivations,
        "missing_answers": missing_answers,
    }


def generate_copy_style_variants(
    fields: dict[str, str],
) -> dict[str, dict[str, Any]]:
    product = fields.get("product", "") or "상품"
    feature1 = fields.get("feature1", "") or "꼼꼼하게 준비한 품질"
    feature2 = fields.get("feature2", "") or "안전한 포장과 배송"
    origin = fields.get("origin", "")
    if "확인 필요" in origin:
        origin = ""

    results = {}
    for name, profile in COPY_STYLE_PROFILES.items():
        if name == "홈쇼핑형":
            headline = f"{profile['opening']}! {feature1} {product}"
            body = f"{feature1}, {feature2}. 사진으로 직접 확인하고 선택하세요."
        elif name == "프리미엄형":
            headline = f"{profile['opening']}, {product}"
            body = f"{origin + '에서 ' if origin else ''}정성껏 준비한 {product}. {feature1}을 중심으로 소개합니다."
        elif name == "감성형":
            headline = f"{profile['opening']}, {product}"
            body = f"생산자의 정성과 {feature1}을 담아 식탁까지 안전하게 전합니다."
        elif name == "심플형":
            headline = f"{product} | {feature1}"
            body = f"{feature2}. 구성·원산지·배송정보를 확인하세요."
        elif name == "공구형":
            headline = f"{product} 실속 구성 확인"
            body = f"{feature1}. 옵션과 구성 수량을 비교하고 선택하세요."
        else:
            headline = f"오늘 보여드릴 상품은 {product}입니다"
            body = f"사진으로 상태를 확인해 보세요. {feature1}, 그리고 {feature2}까지 안내해 드립니다."

        results[name] = {
            "headline": headline[:70],
            "body": body[:150],
            "cta": profile["cta"],
            "tone": profile["tone"],
        }
    return results


def build_intelligent_page_plan(
    fields: dict[str, str],
    psychology: dict[str, Any],
    cut_count: int = 8,
) -> list[dict[str, Any]]:
    category = fields.get("category", "") or "식품"
    product = fields.get("product", "") or "상품"
    base_flow = get_story_flow(category, max(1, min(int(cut_count), 10)))
    concerns = psychology.get("customer_questions", [])
    trust = psychology.get("trust_factors", [])

    plan = []
    for index, stage in enumerate(base_flow):
        title = stage.get("title", f"{index + 1}컷")
        objective = {
            "상품 소개": "첫 화면에서 상품과 핵심 장점을 즉시 이해시킵니다.",
            "핵심 장점": "구매자가 선택해야 할 이유를 짧게 제시합니다.",
            "산지·원산지": "원산지와 생산 배경으로 신뢰를 높입니다.",
            "품질 근거": "실제 사진·선별 기준·수치 등으로 품질을 증명합니다.",
            "활용 제안": "먹는 법·조리법·사용 장면을 보여줍니다.",
            "상품 구성": "중량·개수·옵션을 혼동 없이 안내합니다.",
            "포장·배송": "파손·신선도 걱정을 줄입니다.",
            "구매 안내": "마지막 확인사항과 행동 문구를 제공합니다.",
        }.get(stage.get("stage", ""), "상품의 이해와 구매 결정을 돕습니다.")

        objection = concerns[index % len(concerns)] if concerns else ""
        trust_factor = trust[index % len(trust)] if trust else ""

        plan.append({
            "cut_number": index + 1,
            "stage": stage.get("stage", "상품 소개"),
            "title": title.replace("{product}", product),
            "objective": objective,
            "customer_question": objection,
            "trust_factor": trust_factor,
            "recommended_layout": recommend_cut_layout(title, index),
            "required_information": [
                value for value in [trust_factor, objection] if value
            ],
        })
    return plan


def product_intelligence_score(
    fields: dict[str, str],
    images: list[str],
    plan: list[dict[str, Any]],
) -> dict[str, Any]:
    dimensions = {
        "상품정보": 100,
        "검색준비": 100,
        "구매심리대응": 100,
        "사진준비": 100,
        "페이지기획": 100,
    }
    issues = []

    for key, label, points in [
        ("product", "상품명", 30),
        ("category", "품목", 20),
        ("origin", "원산지", 20),
        ("feature1", "핵심 특징 1", 15),
        ("feature2", "핵심 특징 2", 15),
    ]:
        value = str(fields.get(key, "") or "").strip()
        if not value or "확인 필요" in value:
            dimensions["상품정보"] -= points
            issues.append(f"{label} 보완 필요")

    if not images:
        dimensions["사진준비"] = 0
        issues.append("상품 사진 필요")
    elif len(images) < 3:
        dimensions["사진준비"] -= 40
        issues.append("사진이 3장 미만입니다.")
    elif len(images) < 6:
        dimensions["사진준비"] -= 15

    if not fields.get("optimized_product_name"):
        dimensions["검색준비"] -= 15
    if not fields.get("options"):
        dimensions["구매심리대응"] -= 15
        issues.append("옵션·구성 정보 보완 필요")
    if not fields.get("weight"):
        dimensions["구매심리대응"] -= 15
        issues.append("중량·용량 정보 보완 필요")
    if len(plan) < 6:
        dimensions["페이지기획"] -= 25

    dimensions = {key: max(0, value) for key, value in dimensions.items()}
    total = round(sum(dimensions.values()) / len(dimensions))
    return {
        "score": total,
        "grade": "A" if total >= 90 else "B" if total >= 80 else "C" if total >= 70 else "D" if total >= 60 else "F",
        "dimensions": dimensions,
        "issues": issues,
    }


def build_product_intelligence(
    image_paths: list[str],
    fields: dict[str, str],
    cut_count: int = 8,
) -> dict[str, Any]:
    valid_images = [str(Path(path)) for path in image_paths if Path(path).exists()]
    if not valid_images:
        raise ValueError("상품기획을 시작하려면 상품 사진이 필요합니다.")

    visual_analysis = v5_analyze_product(valid_images, fields)
    merged_fields = apply_analysis_fields(fields, visual_analysis, overwrite=False)
    psychology = analyze_customer_purchase_psychology(merged_fields)
    titles = generate_product_title_set(merged_fields, visual_analysis, 20)
    keywords = generate_search_keyword_plan(merged_fields, visual_analysis)
    copy_variants = generate_copy_style_variants(merged_fields)
    page_plan = build_intelligent_page_plan(merged_fields, psychology, cut_count)
    score = product_intelligence_score(merged_fields, valid_images, page_plan)

    return {
        "engine": "nongjak-product-intelligence",
        "engine_version": PRODUCT_INTELLIGENCE_VERSION,
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "fields": merged_fields,
        "visual_analysis": visual_analysis,
        "product_titles": titles,
        "keyword_plan": keywords,
        "customer_psychology": psychology,
        "copy_variants": copy_variants,
        "page_plan": page_plan,
        "score": score,
        "limitations": [
            "실시간 경쟁상품·검색량·클릭률을 조회한 결과가 아닙니다.",
            "효능·인증·원산지·중량은 실제 증빙 정보로 검수해야 합니다.",
            "사진만으로 확인할 수 없는 정보는 임의로 확정하지 않습니다.",
        ],
    }


def project_from_product_intelligence(
    intelligence: dict[str, Any],
    image_paths: list[str],
    copy_style: str = "프리미엄형",
) -> Project:
    fields = dict(intelligence["fields"])
    titles = intelligence.get("product_titles", [])
    if titles:
        fields["optimized_product_name"] = titles[0]["title"]

    copy_variant = intelligence.get("copy_variants", {}).get(
        copy_style,
        intelligence.get("copy_variants", {}).get("프리미엄형", {}),
    )
    cuts = []
    for index, item in enumerate(intelligence.get("page_plan", [])):
        title = item.get("title", f"{index + 1}컷")
        body_parts = []
        if index == 0:
            title = copy_variant.get("headline", title)
            body_parts.append(copy_variant.get("body", ""))
        else:
            body_parts.extend(item.get("required_information", []))
            if item.get("objective"):
                body_parts.append(item["objective"])
        body = "\n".join(_unique_terms([part for part in body_parts if part]))
        cuts.append(Cut(
            title=title,
            body=body[:180],
            photo_index=0,
            layout_variant=item.get("recommended_layout", "기본 카드형"),
            story_stage=item.get("stage", "상품 소개"),
        ))

    visual = intelligence.get("visual_analysis", {}).get("visual_identity", {})
    project = Project(
        fields=fields,
        images=list(image_paths),
        cuts=cuts,
        style=visual.get("style", "프리미엄"),
        layout=visual.get("layout", "균형형"),
        ai_analysis={
            **intelligence,
            "selected_copy_style": copy_style,
        },
    )
    if project.images:
        apply_recommended_images(project, avoid_duplicates=True)
    return project


def export_product_intelligence_report(
    intelligence: dict[str, Any],
    path: str | Path,
) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(intelligence, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return path


DESIGN_QUALITY_ENGINE_VERSION = "6.1"

DESIGN_STAGE_RULES = {
    "상품 소개": {
        "layout": "풀블리드형",
        "title_size": 42,
        "body_size": 32,
        "image_scale": 1.08,
        "text_align": "center",
    },
    "핵심 장점": {
        "layout": "좌우 분할형",
        "title_size": 38,
        "body_size": 34,
        "image_scale": 1.02,
        "text_align": "center",
    },
    "산지·원산지": {
        "layout": "상단 카피형",
        "title_size": 36,
        "body_size": 31,
        "image_scale": 1.0,
        "text_align": "center",
    },
    "품질 근거": {
        "layout": "포인트 카드형",
        "title_size": 37,
        "body_size": 31,
        "image_scale": 1.05,
        "text_align": "center",
    },
    "활용 제안": {
        "layout": "좌우 분할형",
        "title_size": 36,
        "body_size": 31,
        "image_scale": 1.0,
        "text_align": "center",
    },
    "상품 구성": {
        "layout": "포인트 카드형",
        "title_size": 35,
        "body_size": 30,
        "image_scale": 0.96,
        "text_align": "center",
    },
    "포장·배송": {
        "layout": "상단 카피형",
        "title_size": 35,
        "body_size": 30,
        "image_scale": 1.0,
        "text_align": "center",
    },
    "구매 안내": {
        "layout": "풀블리드형",
        "title_size": 40,
        "body_size": 31,
        "image_scale": 1.08,
        "text_align": "center",
    },
}

CATEGORY_DESIGN_RECOMMENDATIONS = {
    "농산물": {"style": "감성", "background": "#F1E8DB"},
    "과일": {"style": "프리미엄", "background": "#F7EFE2"},
    "수산물": {"style": "프리미엄", "background": "#EDF3F4"},
    "수산가공식품": {"style": "홈쇼핑", "background": "#FFF1D9"},
    "축산물": {"style": "프리미엄", "background": "#F2E7E1"},
    "가공식품": {"style": "심플", "background": "#F4F4F4"},
    "식품": {"style": "프리미엄", "background": "#F3EEE6"},
}


def estimate_text_lines(text: str, chars_per_line: int) -> int:
    text = str(text or "").strip()
    if not text:
        return 0
    lines = 0
    for paragraph in text.splitlines() or [""]:
        paragraph = paragraph.strip()
        lines += max(1, (len(paragraph) + chars_per_line - 1) // chars_per_line)
    return lines


def cut_design_diagnostics(
    cut: Cut,
    cut_index: int,
    cut_count: int,
) -> dict[str, Any]:
    title_length = len(str(cut.title or "").strip())
    body_length = len(str(cut.body or "").strip())
    title_lines = estimate_text_lines(cut.title, 16)
    body_lines = estimate_text_lines(cut.body, 20)
    issues = []
    recommendations = []
    score = 100

    if title_length < 4:
        score -= 22
        issues.append("제목이 너무 짧아 핵심 장점이 드러나지 않습니다.")
        recommendations.append("상품명이나 핵심 장점을 포함해 제목을 보강")
    elif title_length > 32:
        score -= 14
        issues.append("제목이 길어 모바일에서 시선이 분산될 수 있습니다.")
        recommendations.append("제목을 12~28자 안으로 축약")

    if title_lines > 3:
        score -= 12
        issues.append("제목이 4줄 이상으로 예상됩니다.")

    if body_length < 10:
        score -= 16
        issues.append("본문 정보가 부족합니다.")
        recommendations.append("고객 질문에 답하는 구체적 설명 추가")
    elif body_length > 105:
        score -= 18
        issues.append("본문이 길어 모바일 가독성이 떨어질 수 있습니다.")
        recommendations.append("핵심 정보만 남기고 2~4줄로 축약")

    if body_lines > 6:
        score -= 10
        issues.append("본문 줄 수가 많습니다.")

    if not 24 <= int(cut.title_size) <= 48:
        score -= 10
        issues.append("제목 글자 크기가 권장 범위를 벗어났습니다.")
    if not 24 <= int(cut.body_size) <= 42:
        score -= 10
        issues.append("본문 글자 크기가 권장 범위를 벗어났습니다.")

    if not 0.72 <= float(cut.image_scale) <= 1.35:
        score -= 12
        issues.append("상품 이미지 확대 비율이 지나칩니다.")

    if cut.layout_variant not in CUT_LAYOUT_VARIANTS:
        score -= 15
        issues.append("지원하지 않는 레이아웃입니다.")

    if cut_index == 0 and cut.layout_variant != "풀블리드형":
        score -= 10
        issues.append("첫 컷은 대표 이미지 중심의 풀블리드형이 효과적입니다.")
        recommendations.append("첫 컷을 풀블리드형으로 변경")

    if cut_index == cut_count - 1 and cut.layout_variant not in {"풀블리드형", "상단 카피형"}:
        score -= 8
        issues.append("마지막 컷의 구매 유도 강조가 약할 수 있습니다.")

    stage_rule = DESIGN_STAGE_RULES.get(cut.story_stage)
    if stage_rule and cut.layout_variant != stage_rule["layout"]:
        score -= 7
        recommendations.append(
            f"‘{cut.story_stage}’ 단계에는 {stage_rule['layout']} 추천"
        )

    return {
        "cut_number": cut_index + 1,
        "title": cut.title,
        "stage": cut.story_stage,
        "score": max(0, score),
        "grade": (
            "A" if score >= 90
            else "B" if score >= 80
            else "C" if score >= 70
            else "D" if score >= 60
            else "F"
        ),
        "title_length": title_length,
        "body_length": body_length,
        "title_lines": title_lines,
        "body_lines": body_lines,
        "issues": issues,
        "recommendations": recommendations,
    }


def project_design_quality(project: Project) -> dict[str, Any]:
    cuts = [
        cut_design_diagnostics(cut, index, len(project.cuts))
        for index, cut in enumerate(project.cuts)
    ]
    average = round(
        sum(item["score"] for item in cuts) / len(cuts)
    ) if cuts else 0

    layout_counts = {}
    for cut in project.cuts:
        layout_counts[cut.layout_variant] = layout_counts.get(cut.layout_variant, 0) + 1

    repeated_layout_penalty = 0
    if project.cuts and max(layout_counts.values(), default=0) >= max(5, len(project.cuts) - 1):
        repeated_layout_penalty = 10
        average = max(0, average - repeated_layout_penalty)

    style_recommendation = CATEGORY_DESIGN_RECOMMENDATIONS.get(
        project.fields.get("category", "식품"),
        CATEGORY_DESIGN_RECOMMENDATIONS["식품"],
    )
    global_issues = []
    if project.style != style_recommendation["style"]:
        global_issues.append(
            f"품목 기준 추천 스타일은 {style_recommendation['style']}입니다."
        )
    if len(layout_counts) < 3 and len(project.cuts) >= 6:
        global_issues.append("레이아웃 종류가 적어 상세페이지가 단조로울 수 있습니다.")
    if not project.custom_background:
        global_issues.append(
            f"추천 배경색 {style_recommendation['background']}을 적용할 수 있습니다."
        )

    return {
        "engine_version": DESIGN_QUALITY_ENGINE_VERSION,
        "score": average,
        "grade": (
            "A" if average >= 90
            else "B" if average >= 80
            else "C" if average >= 70
            else "D" if average >= 60
            else "F"
        ),
        "cut_count": len(cuts),
        "cuts": cuts,
        "layout_counts": layout_counts,
        "repeated_layout_penalty": repeated_layout_penalty,
        "recommended_style": style_recommendation["style"],
        "recommended_background": style_recommendation["background"],
        "global_issues": global_issues,
        "priority_cuts": sorted(
            [item for item in cuts if item["score"] < 85],
            key=lambda item: item["score"],
        ),
    }


def recommend_cut_design_settings(
    cut: Cut,
    cut_index: int,
    cut_count: int,
) -> dict[str, Any]:
    rule = DESIGN_STAGE_RULES.get(cut.story_stage, {})
    recommended_layout = rule.get(
        "layout",
        recommend_cut_layout(cut.title, cut_index),
    )
    if cut_index == 0:
        recommended_layout = "풀블리드형"
    elif cut_index == cut_count - 1:
        recommended_layout = "풀블리드형"

    body_length = len(cut.body.strip())
    body_size = int(rule.get("body_size", 31))
    if body_length > 90:
        body_size = min(body_size, 27)
    elif body_length < 35:
        body_size = max(body_size, 32)

    return {
        "layout_variant": recommended_layout,
        "title_size": int(rule.get("title_size", 36)),
        "body_size": body_size,
        "image_scale": float(rule.get("image_scale", 1.0)),
        "text_align": str(rule.get("text_align", "center")),
        "body_offset_y": 0,
    }


def apply_cut_design_settings(
    cut: Cut,
    settings: dict[str, Any],
) -> list[str]:
    changes = []
    for key in [
        "layout_variant",
        "title_size",
        "body_size",
        "image_scale",
        "text_align",
        "body_offset_y",
    ]:
        if key not in settings or not hasattr(cut, key):
            continue
        before = getattr(cut, key)
        after = settings[key]
        if before != after:
            setattr(cut, key, after)
            changes.append(f"{key}: {before} → {after}")
    return changes


def auto_optimize_project_design(
    project: Project,
    apply_style: bool = True,
    apply_background: bool = True,
    only_problem_cuts: bool = False,
) -> dict[str, Any]:
    before = project_design_quality(project)
    style_recommendation = CATEGORY_DESIGN_RECOMMENDATIONS.get(
        project.fields.get("category", "식품"),
        CATEGORY_DESIGN_RECOMMENDATIONS["식품"],
    )
    changes = []

    if apply_style and project.style != style_recommendation["style"]:
        changes.append(
            f"전체 스타일: {project.style} → {style_recommendation['style']}"
        )
        project.style = style_recommendation["style"]

    if apply_background and not project.custom_background:
        project.custom_background = style_recommendation["background"]
        changes.append(
            f"배경색: 기본 → {style_recommendation['background']}"
        )

    problem_indices = {
        item["cut_number"] - 1 for item in before["priority_cuts"]
    }
    cut_changes = []
    for index, cut in enumerate(project.cuts):
        if only_problem_cuts and index not in problem_indices:
            continue
        settings = recommend_cut_design_settings(
            cut,
            index,
            len(project.cuts),
        )
        applied = apply_cut_design_settings(cut, settings)
        if applied:
            cut_changes.append({
                "cut_number": index + 1,
                "title": cut.title,
                "changes": applied,
            })

    after = project_design_quality(project)
    return {
        "engine_version": DESIGN_QUALITY_ENGINE_VERSION,
        "before": before,
        "after": after,
        "score_improvement": after["score"] - before["score"],
        "global_changes": changes,
        "cut_changes": cut_changes,
        "changed_cut_count": len(cut_changes),
    }


def build_design_contact_sheet(
    project: Project,
    output_path: str | Path,
    thumb_width: int = 225,
) -> Path:
    if not project.cuts or not project.images:
        raise ValueError("연락시트를 만들 사진과 상세페이지 컷이 필요합니다.")

    columns = 4
    thumb_height = round(thumb_width * 4 / 3)
    caption_height = 64
    rows = (len(project.cuts) + columns - 1) // columns
    sheet = Image.new(
        "RGB",
        (
            columns * thumb_width,
            rows * (thumb_height + caption_height),
        ),
        "white",
    )
    draw = ImageDraw.Draw(sheet)
    font = _font(18, True)
    small = _font(14, False)

    for index, cut in enumerate(project.cuts):
        image_index = min(
            max(0, int(cut.photo_index)),
            len(project.images) - 1,
        )
        rendered = render_cut(
            project.images[image_index],
            index,
            cut,
            project.style,
            project.layout,
            project.custom_background,
        )
        rendered.thumbnail(
            (thumb_width, thumb_height),
            Image.Resampling.LANCZOS,
        )
        x = (index % columns) * thumb_width
        y = (index // columns) * (thumb_height + caption_height)
        sheet.paste(rendered, (x, y))
        draw.text(
            (x + 8, y + thumb_height + 5),
            f"{index + 1}컷 · {cut.story_stage}",
            font=font,
            fill=(25, 25, 25),
        )
        title = cut.title.replace("\n", " ")[:24]
        draw.text(
            (x + 8, y + thumb_height + 33),
            title,
            font=small,
            fill=(80, 80, 80),
        )

    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    sheet.save(output_path)
    return output_path


def export_design_quality_report(
    project: Project,
    output_path: str | Path,
) -> Path:
    report = project_design_quality(project)
    report["generated_at"] = datetime.now().isoformat(timespec="seconds")
    report["product"] = project.fields.get("product", "")
    report["style"] = project.style
    report["layout"] = project.layout
    report["custom_background"] = project.custom_background
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(
        json.dumps(report, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return output_path


THUMBNAIL_ENGINE_VERSION = "6.2"
THUMBNAIL_SIZE = (1000, 1000)

THUMBNAIL_CHANNEL_RULES = {
    "스마트스토어": {
        "safe_margin": 70,
        "max_headline_chars": 24,
        "max_subcopy_chars": 38,
        "recommended_text_ratio": 0.22,
    },
    "쿠팡": {
        "safe_margin": 60,
        "max_headline_chars": 20,
        "max_subcopy_chars": 30,
        "recommended_text_ratio": 0.18,
    },
    "일반 쇼핑몰": {
        "safe_margin": 80,
        "max_headline_chars": 28,
        "max_subcopy_chars": 44,
        "recommended_text_ratio": 0.25,
    },
}

THUMBNAIL_VARIANTS = {
    "상품집중형": {
        "product_box": (70, 150, 930, 920),
        "text_position": "top",
        "overlay": False,
    },
    "좌측카피형": {
        "product_box": (390, 90, 960, 940),
        "text_position": "left",
        "overlay": False,
    },
    "홈쇼핑강조형": {
        "product_box": (110, 170, 890, 930),
        "text_position": "overlay",
        "overlay": True,
    },
}


def thumbnail_text_candidates(project: Project) -> list[dict[str, str]]:
    fields = project.fields
    product = str(fields.get("product", "") or "상품").strip()
    feature1 = str(fields.get("feature1", "") or "꼼꼼하게 준비한 품질").strip()
    feature2 = str(fields.get("feature2", "") or "안전한 포장과 배송").strip()
    origin = str(fields.get("origin", "") or "").strip()
    if "확인 필요" in origin:
        origin = ""

    intelligence = project.ai_analysis or {}
    title_candidates = intelligence.get("product_titles", [])
    optimized = (
        fields.get("optimized_product_name")
        or (title_candidates[0]["title"] if title_candidates else "")
        or product
    )

    candidates = [
        {"headline": product, "subcopy": feature1},
        {"headline": feature1, "subcopy": product},
        {"headline": f"{origin} {product}".strip(), "subcopy": feature2},
        {"headline": optimized[:34], "subcopy": feature1},
        {"headline": f"지금 주목할 {product}", "subcopy": f"{feature1} · {feature2}"},
    ]
    unique = []
    seen = set()
    for item in candidates:
        key = (item["headline"], item["subcopy"])
        if key not in seen:
            seen.add(key)
            unique.append(item)
    return unique


def select_thumbnail_source_image(project: Project) -> dict[str, Any]:
    if not project.images:
        raise ValueError("썸네일을 만들 상품 사진이 없습니다.")

    analysis = project.ai_analysis or {}
    hero = analysis.get("hero_image", {})
    selected_index = hero.get("selected_index")
    if isinstance(selected_index, int) and 0 <= selected_index < len(project.images):
        return {
            "index": selected_index,
            "path": project.images[selected_index],
            "reason": "AI 대표사진 분석 결과",
        }

    candidates = []
    for index, path in enumerate(project.images):
        try:
            feature = analyze_image_visual_features(path)
            score = score_hero_image(feature, index)
        except Exception:
            score = -999
        candidates.append({"index": index, "path": path, "score": score})
    best = max(candidates, key=lambda item: item["score"])
    return {
        "index": best["index"],
        "path": best["path"],
        "reason": "해상도·밝기·구도 자동 점수",
    }


def _thumbnail_palette(project: Project) -> dict[str, tuple[int, int, int]]:
    preset = STYLE_PRESETS.get(project.style, STYLE_PRESETS["프리미엄"])
    background = preset["bg"]
    accent = preset["accent"]
    text = preset["text"]

    analysis = project.ai_analysis or {}
    visual = analysis.get("visual_identity", {})
    if visual.get("background_color"):
        background = ImageColor.getrgb(visual["background_color"])
    if visual.get("accent_color"):
        accent = ImageColor.getrgb(visual["accent_color"])
    return {"background": background, "accent": accent, "text": text}


def _fit_product_image(
    image_path: str | Path,
    box: tuple[int, int, int, int],
) -> Image.Image:
    with Image.open(image_path) as source:
        source = source.convert("RGBA")
        width = box[2] - box[0]
        height = box[3] - box[1]
        fitted = ImageOps.contain(source, (width, height), Image.Resampling.LANCZOS)
        return fitted.copy()


def _draw_multiline_center(
    draw: ImageDraw.ImageDraw,
    xy: tuple[int, int],
    text: str,
    font: ImageFont.FreeTypeFont | ImageFont.ImageFont,
    fill: tuple[int, int, int],
    max_width: int,
    spacing: int = 8,
) -> tuple[int, int, int, int]:
    joined = _wrap(draw, text, font, max_width)
    bbox = draw.multiline_textbbox((0, 0), joined, font=font, spacing=spacing, align="center")
    w = bbox[2] - bbox[0]
    h = bbox[3] - bbox[1]
    x = xy[0] - w // 2
    y = xy[1]
    draw.multiline_text((x, y), joined, font=font, fill=fill, spacing=spacing, align="center")
    return (x, y, x + w, y + h)


def render_thumbnail_variant(
    project: Project,
    variant_name: str,
    headline: str,
    subcopy: str,
    channel: str = "스마트스토어",
    image_path: str | Path | None = None,
) -> Image.Image:
    if variant_name not in THUMBNAIL_VARIANTS:
        raise ValueError("지원하지 않는 썸네일 유형입니다.")

    rule = THUMBNAIL_VARIANTS[variant_name]
    channel_rule = THUMBNAIL_CHANNEL_RULES.get(
        channel,
        THUMBNAIL_CHANNEL_RULES["일반 쇼핑몰"],
    )
    palette = _thumbnail_palette(project)
    canvas = Image.new("RGB", THUMBNAIL_SIZE, palette["background"])
    draw = ImageDraw.Draw(canvas)

    source = str(image_path or select_thumbnail_source_image(project)["path"])
    product_image = _fit_product_image(source, rule["product_box"])

    box = rule["product_box"]
    px = box[0] + (box[2] - box[0] - product_image.width) // 2
    py = box[1] + (box[3] - box[1] - product_image.height) // 2

    shadow = Image.new("RGBA", THUMBNAIL_SIZE, (0, 0, 0, 0))
    shadow_draw = ImageDraw.Draw(shadow)
    shadow_draw.ellipse(
        (px + 40, py + product_image.height - 20, px + product_image.width - 40, py + product_image.height + 30),
        fill=(0, 0, 0, 35),
    )
    canvas = Image.alpha_composite(canvas.convert("RGBA"), shadow)
    canvas.alpha_composite(product_image, (px, py))

    draw = ImageDraw.Draw(canvas)
    headline_font = _font(64 if variant_name != "좌측카피형" else 58, True)
    sub_font = _font(32, False)

    if variant_name == "상품집중형":
        draw.rounded_rectangle(
            (55, 50, 945, 210),
            radius=28,
            fill=(*palette["background"], 238),
            outline=palette["accent"],
            width=4,
        )
        _draw_multiline_center(
            draw, (500, 78), headline, headline_font, palette["text"], 820, 6
        )
        _draw_multiline_center(
            draw, (500, 150), subcopy, sub_font, palette["accent"], 780, 5
        )
    elif variant_name == "좌측카피형":
        draw.rounded_rectangle(
            (45, 120, 430, 870),
            radius=34,
            fill=(255, 255, 255, 232),
            outline=palette["accent"],
            width=4,
        )
        title_lines = _wrap(draw, headline, headline_font, 310)
        draw.multiline_text(
            (85, 205),
            title_lines,
            font=headline_font,
            fill=palette["text"],
            spacing=10,
        )
        sub_lines = _wrap(draw, subcopy, sub_font, 300)
        draw.multiline_text(
            (85, 520),
            sub_lines,
            font=sub_font,
            fill=palette["accent"],
            spacing=8,
        )
    else:
        overlay = Image.new("RGBA", THUMBNAIL_SIZE, (0, 0, 0, 0))
        overlay_draw = ImageDraw.Draw(overlay)
        overlay_draw.rounded_rectangle(
            (50, 55, 950, 260),
            radius=30,
            fill=(255, 255, 255, 226),
            outline=palette["accent"],
            width=6,
        )
        overlay_draw.rounded_rectangle(
            (100, 830, 900, 955),
            radius=28,
            fill=(*palette["accent"], 238),
        )
        canvas = Image.alpha_composite(canvas, overlay)
        draw = ImageDraw.Draw(canvas)
        _draw_multiline_center(
            draw, (500, 85), headline, headline_font, palette["text"], 800, 7
        )
        _draw_multiline_center(
            draw, (500, 860), subcopy, sub_font, (255, 255, 255), 720, 5
        )

    margin = channel_rule["safe_margin"]
    draw.rectangle(
        (margin, margin, 1000 - margin, 1000 - margin),
        outline=(*palette["accent"], 85),
        width=2,
    )
    return canvas.convert("RGB")


def thumbnail_quality_score(
    headline: str,
    subcopy: str,
    variant_name: str,
    channel: str = "스마트스토어",
) -> dict[str, Any]:
    rule = THUMBNAIL_CHANNEL_RULES.get(channel, THUMBNAIL_CHANNEL_RULES["일반 쇼핑몰"])
    score = 100
    issues = []

    if len(headline.strip()) < 3:
        score -= 35
        issues.append("메인 문구가 너무 짧습니다.")
    if len(headline) > rule["max_headline_chars"]:
        score -= min(30, (len(headline) - rule["max_headline_chars"]) * 2)
        issues.append("메인 문구가 채널 권장 길이보다 깁니다.")
    if len(subcopy) > rule["max_subcopy_chars"]:
        score -= min(25, len(subcopy) - rule["max_subcopy_chars"])
        issues.append("보조 문구가 길어 모바일에서 작게 보일 수 있습니다.")
    if headline.strip() == subcopy.strip():
        score -= 20
        issues.append("메인 문구와 보조 문구가 같습니다.")
    if variant_name == "홈쇼핑강조형" and len(headline) > 22:
        score -= 10
        issues.append("홈쇼핑 강조형은 더 짧은 문구가 효과적입니다.")

    return {
        "score": max(0, score),
        "grade": "A" if score >= 90 else "B" if score >= 80 else "C" if score >= 70 else "D" if score >= 60 else "F",
        "issues": issues,
    }


def generate_thumbnail_set(
    project: Project,
    output_folder: str | Path,
    channel: str = "스마트스토어",
) -> dict[str, Any]:
    output_folder = Path(output_folder)
    output_folder.mkdir(parents=True, exist_ok=True)

    selected = select_thumbnail_source_image(project)
    texts = thumbnail_text_candidates(project)
    variants = list(THUMBNAIL_VARIANTS)
    outputs = []

    for index, variant in enumerate(variants):
        text = texts[index % len(texts)]
        image = render_thumbnail_variant(
            project,
            variant,
            text["headline"],
            text["subcopy"],
            channel,
            selected["path"],
        )
        filename = f"{index + 1:02d}_{sanitize_name(variant)}.png"
        path = output_folder / filename
        image.save(path)
        quality = thumbnail_quality_score(
            text["headline"],
            text["subcopy"],
            variant,
            channel,
        )
        outputs.append({
            "variant": variant,
            "path": str(path),
            "headline": text["headline"],
            "subcopy": text["subcopy"],
            "quality": quality,
        })

    report = {
        "engine_version": THUMBNAIL_ENGINE_VERSION,
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "channel": channel,
        "product": project.fields.get("product", ""),
        "source_image": selected,
        "size": list(THUMBNAIL_SIZE),
        "outputs": outputs,
        "best_variant": max(outputs, key=lambda item: item["quality"]["score"]),
        "original_source_unchanged": True,
    }
    report_path = output_folder / "thumbnail_report.json"
    report_path.write_text(
        json.dumps(report, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    report["report"] = str(report_path)
    return report


def build_thumbnail_contact_sheet(
    thumbnail_result: dict[str, Any],
    output_path: str | Path,
) -> Path:
    outputs = thumbnail_result.get("outputs", [])
    if not outputs:
        raise ValueError("썸네일 결과가 없습니다.")

    thumb = 360
    caption = 110
    sheet = Image.new("RGB", (thumb * len(outputs), thumb + caption), "white")
    draw = ImageDraw.Draw(sheet)
    title_font = _font(22, True)
    small_font = _font(16, False)

    for index, item in enumerate(outputs):
        with Image.open(item["path"]) as image:
            image = ImageOps.fit(image.convert("RGB"), (thumb, thumb), Image.Resampling.LANCZOS)
            sheet.paste(image, (index * thumb, 0))
        draw.text(
            (index * thumb + 12, thumb + 10),
            f"{item['variant']} · {item['quality']['score']}점",
            font=title_font,
            fill=(25, 25, 25),
        )
        draw.text(
            (index * thumb + 12, thumb + 45),
            item["headline"][:28],
            font=small_font,
            fill=(80, 80, 80),
        )

    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    sheet.save(output_path)
    return output_path


AD_BANNER_ENGINE_VERSION = "6.3"

AD_BANNER_SIZES = {
    "스마트스토어 가로배너": (1200, 400),
    "인스타그램 정사각형": (1080, 1080),
    "인스타그램 세로형": (1080, 1350),
    "페이스북 가로형": (1200, 628),
}

AD_CAMPAIGN_TYPES = {
    "신상품": {
        "badge": "NEW",
        "headline": "새롭게 준비한 {product}",
        "subcopy": "{feature1}",
        "cta": "상품 확인하기",
    },
    "베스트상품": {
        "badge": "BEST",
        "headline": "많이 찾는 {product}",
        "subcopy": "{feature1} · {feature2}",
        "cta": "지금 만나보기",
    },
    "특가행사": {
        "badge": "SALE",
        "headline": "{product} 특별 구성",
        "subcopy": "옵션과 혜택을 확인하세요",
        "cta": "행사 내용 확인",
    },
    "산지직송": {
        "badge": "FRESH",
        "headline": "{origin} {product}",
        "subcopy": "{feature1} · 산지에서 안전하게 발송",
        "cta": "신선함 확인하기",
    },
}


def generate_ad_copy(
    project: Project,
    campaign_type: str,
) -> dict[str, str]:
    if campaign_type not in AD_CAMPAIGN_TYPES:
        raise ValueError("지원하지 않는 광고 유형입니다.")
    fields = dict(DEFAULTS)
    fields.update(project.fields)
    template = AD_CAMPAIGN_TYPES[campaign_type]
    return {
        "badge": template["badge"],
        "headline": template["headline"].format(**fields),
        "subcopy": template["subcopy"].format(**fields),
        "cta": template["cta"],
    }


def ad_banner_quality_score(
    headline: str,
    subcopy: str,
    size_name: str,
) -> dict[str, Any]:
    score = 100
    issues = []
    width, height = AD_BANNER_SIZES[size_name]
    is_wide = width / height > 2.0
    headline_limit = 24 if is_wide else 34
    subcopy_limit = 40 if is_wide else 55

    if len(headline.strip()) < 4:
        score -= 30
        issues.append("광고 제목이 너무 짧습니다.")
    if len(headline) > headline_limit:
        score -= min(30, (len(headline) - headline_limit) * 2)
        issues.append("광고 제목이 규격에 비해 깁니다.")
    if len(subcopy) > subcopy_limit:
        score -= min(25, len(subcopy) - subcopy_limit)
        issues.append("보조 문구가 길어 가독성이 떨어질 수 있습니다.")
    if headline.strip() == subcopy.strip():
        score -= 20
        issues.append("제목과 보조 문구가 동일합니다.")

    return {
        "score": max(0, score),
        "grade": "A" if score >= 90 else "B" if score >= 80 else "C" if score >= 70 else "D" if score >= 60 else "F",
        "issues": issues,
    }


def render_ad_banner(
    project: Project,
    size_name: str,
    campaign_type: str,
    image_path: str | Path | None = None,
) -> Image.Image:
    if size_name not in AD_BANNER_SIZES:
        raise ValueError("지원하지 않는 광고 규격입니다.")
    width, height = AD_BANNER_SIZES[size_name]
    copy_data = generate_ad_copy(project, campaign_type)
    palette = _thumbnail_palette(project)
    canvas = Image.new("RGBA", (width, height), (*palette["background"], 255))
    draw = ImageDraw.Draw(canvas)

    source_path = str(image_path or select_thumbnail_source_image(project)["path"])
    is_wide = width / height > 1.6

    if is_wide:
        image_box = (width // 2, 20, width - 20, height - 20)
        text_box_width = width // 2 - 90
    else:
        image_box = (70, height // 3, width - 70, height - 80)
        text_box_width = width - 140

    product = _fit_product_image(source_path, image_box)
    px = image_box[0] + (image_box[2] - image_box[0] - product.width) // 2
    py = image_box[1] + (image_box[3] - image_box[1] - product.height) // 2

    shadow = Image.new("RGBA", canvas.size, (0, 0, 0, 0))
    sdraw = ImageDraw.Draw(shadow)
    sdraw.ellipse(
        (px + 30, py + product.height - 10, px + product.width - 30, py + product.height + 24),
        fill=(0, 0, 0, 35),
    )
    canvas = Image.alpha_composite(canvas, shadow)
    canvas.alpha_composite(product, (px, py))
    draw = ImageDraw.Draw(canvas)

    badge_font = _font(max(20, width // 42), True)
    headline_font = _font(max(34, width // 20), True)
    sub_font = _font(max(20, width // 38), False)
    cta_font = _font(max(18, width // 45), True)

    if is_wide:
        left = 55
        top = 45
        draw.rounded_rectangle(
            (left, top, left + 150, top + 54),
            radius=18,
            fill=palette["accent"],
        )
        draw.text((left + 24, top + 10), copy_data["badge"], font=badge_font, fill=(255,255,255))
        headline = _wrap(draw, copy_data["headline"], headline_font, text_box_width)
        draw.multiline_text((left, top + 90), headline, font=headline_font, fill=palette["text"], spacing=8)
        subcopy = _wrap(draw, copy_data["subcopy"], sub_font, text_box_width)
        draw.multiline_text((left, top + 220), subcopy, font=sub_font, fill=palette["accent"], spacing=6)
        draw.rounded_rectangle(
            (left, height - 82, left + 260, height - 28),
            radius=20,
            fill=palette["accent"],
        )
        draw.text((left + 26, height - 69), copy_data["cta"], font=cta_font, fill=(255,255,255))
    else:
        draw.rounded_rectangle(
            (55, 45, 220, 105),
            radius=20,
            fill=palette["accent"],
        )
        draw.text((82, 58), copy_data["badge"], font=badge_font, fill=(255,255,255))
        headline = _wrap(draw, copy_data["headline"], headline_font, text_box_width)
        draw.multiline_text((70, 135), headline, font=headline_font, fill=palette["text"], spacing=8)
        subcopy = _wrap(draw, copy_data["subcopy"], sub_font, text_box_width)
        draw.multiline_text((70, 270), subcopy, font=sub_font, fill=palette["accent"], spacing=6)
        draw.rounded_rectangle(
            (70, height - 100, width - 70, height - 35),
            radius=22,
            fill=palette["accent"],
        )
        bbox = draw.textbbox((0,0), copy_data["cta"], font=cta_font)
        tx = (width - (bbox[2]-bbox[0])) // 2
        draw.text((tx, height - 83), copy_data["cta"], font=cta_font, fill=(255,255,255))

    return canvas.convert("RGB")


def generate_ad_banner_set(
    project: Project,
    output_folder: str | Path,
    size_name: str = "스마트스토어 가로배너",
) -> dict[str, Any]:
    if not project.images:
        raise ValueError("광고 배너를 만들 상품 사진이 없습니다.")
    output_folder = Path(output_folder)
    output_folder.mkdir(parents=True, exist_ok=True)
    source = select_thumbnail_source_image(project)
    outputs = []

    for index, campaign_type in enumerate(AD_CAMPAIGN_TYPES, 1):
        copy_data = generate_ad_copy(project, campaign_type)
        image = render_ad_banner(
            project,
            size_name,
            campaign_type,
            source["path"],
        )
        filename = f"{index:02d}_{sanitize_name(campaign_type)}_{sanitize_name(size_name)}.png"
        path = output_folder / filename
        image.save(path)
        quality = ad_banner_quality_score(
            copy_data["headline"],
            copy_data["subcopy"],
            size_name,
        )
        outputs.append({
            "campaign_type": campaign_type,
            "path": str(path),
            "copy": copy_data,
            "quality": quality,
        })

    report = {
        "engine_version": AD_BANNER_ENGINE_VERSION,
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "product": project.fields.get("product", ""),
        "size_name": size_name,
        "size": list(AD_BANNER_SIZES[size_name]),
        "source_image": source,
        "outputs": outputs,
        "best_banner": max(outputs, key=lambda item: item["quality"]["score"]),
        "original_source_unchanged": True,
    }
    report_path = output_folder / "ad_banner_report.json"
    report_path.write_text(
        json.dumps(report, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    report["report"] = str(report_path)
    return report


def build_ad_banner_contact_sheet(
    result: dict[str, Any],
    output_path: str | Path,
) -> Path:
    outputs = result.get("outputs", [])
    if not outputs:
        raise ValueError("광고 배너 결과가 없습니다.")

    preview_width = 420
    cards = []
    for item in outputs:
        with Image.open(item["path"]) as image:
            ratio = image.height / image.width
            height = max(180, round(preview_width * ratio))
            preview = ImageOps.fit(
                image.convert("RGB"),
                (preview_width, height),
                Image.Resampling.LANCZOS,
            )
        cards.append((item, preview))

    caption_height = 82
    sheet_height = sum(image.height + caption_height for _, image in cards)
    sheet = Image.new("RGB", (preview_width, sheet_height), "white")
    draw = ImageDraw.Draw(sheet)
    title_font = _font(20, True)
    small_font = _font(15, False)

    y = 0
    for item, image in cards:
        sheet.paste(image, (0, y))
        y += image.height
        draw.text(
            (12, y + 8),
            f"{item['campaign_type']} · {item['quality']['score']}점",
            font=title_font,
            fill=(25,25,25),
        )
        draw.text(
            (12, y + 40),
            item["copy"]["headline"][:36],
            font=small_font,
            fill=(80,80,80),
        )
        y += caption_height

    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    sheet.save(output_path)
    return output_path
