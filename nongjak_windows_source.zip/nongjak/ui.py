from __future__ import annotations

import json
import tkinter as tk
from pathlib import Path
from tkinter import colorchooser, filedialog, messagebox, simpledialog, ttk

from PIL import ImageTk

from .core import *


class App:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title(f"농작 AI v{APP_VERSION}")
        self.root.geometry("1440x900")
        self.project = Project(fields={}, images=[], cuts=[])
        self.current_project_path = None
        self.current = 0
        self.history: list[str] = []
        self.future: list[str] = []
        self.dirty = False
        self.last_saved_fingerprint = None
        self.autosave_interval_ms = 120000
        self.ai_config = load_ai_config()
        self.update_config = load_update_config()
        self.workspace_config = load_workspace_config()
        self.last_workflow_result = None
        self.build()
        self.status("상품정보와 사진을 입력하세요.")
        self.root.after(350, self.startup_workspace_flow)

    def usage_guide_ui(self):
        dialog = tk.Toplevel(self.root)
        dialog.title("농작 AI 사용법")
        dialog.geometry("780x680")
        dialog.transient(self.root)

        guide = """농작 AI v6.3.1 빠른 사용법

1. 처음 실행
- 압축파일을 완전히 풀어 주세요.
- 폴더 안의 ‘ONE_CLICK_START.cmd’을 먼저 실행하세요.
- 점검이 끝나면 ‘2_농작AI_실행.bat’을 실행하세요.

2. 가장 빠른 상세페이지 제작
- 상단 ‘사진 불러오기’를 눌러 상품사진을 선택합니다.
- 왼쪽에 상품명·품목·원산지·특징·택배사를 입력합니다.
- ‘한 번에 자동 제작’을 누릅니다.
- 첫 컷부터 한 장씩 확인하고 수정합니다.
- 검수 상태를 승인 또는 수정 필요로 저장합니다.

3. AI 상품기획
- 사진과 아는 상품정보를 입력합니다.
- ‘AI 상품기획’을 누르면 상품명·키워드·고객 질문·컷 구성을 만듭니다.
- 결과를 프로젝트에 적용한 뒤 한 컷씩 확인합니다.

4. 디자인과 썸네일
- ‘디자인 점검’에서 컷별 디자인 점수를 확인합니다.
- 문제 컷만 자동 보정하거나 전체 디자인을 보정할 수 있습니다.
- ‘썸네일 제작’에서 1000×1000 썸네일 3종을 만듭니다.

5. 저장
- 프로젝트 저장: 나중에 다시 편집할 작업파일
- PNG 저장: 현재 컷 이미지
- PDF 저장: 상세페이지 전체 PDF
- 승인본 저장: 승인된 컷만 저장

6. 화면이 깨져 보일 때
- Windows 화면 배율을 100~125%로 설정해 보세요.
- 프로그램 창을 최대화하세요.
- 상단 기능은 메뉴로 정리되어 있습니다.
- 오류가 나면 폴더의 logs/startup_error.log를 확인하세요.

중요
- 제공한 원본 상품사진 파일은 덮어쓰지 않습니다.
- 원산지·인증·중량·효능은 실제 자료로 최종 확인해야 합니다.
"""
        text = tk.Text(dialog, wrap="word", padx=18, pady=18)
        text.pack(fill="both", expand=True)
        text.insert("1.0", guide)
        text.config(state="disabled")
        ttk.Button(dialog, text="닫기", command=dialog.destroy).pack(pady=10)

    def build(self):
        top = ttk.Frame(self.root, padding=8)
        top.pack(fill="x")
        ttk.Label(top, text=f"농작 AI v{APP_VERSION}", font=("", 18, "bold")).pack(side="left")
        # v6.3.1: 많은 기능 버튼을 한 줄에 배치하면 작은 화면에서 UI가 깨집니다.
        # 기능을 메뉴로 정리하고, 자주 쓰는 핵심 버튼만 상단에 표시합니다.
        menu_bar = tk.Menu(self.root)

        file_menu = tk.Menu(menu_bar, tearoff=0)
        for text, command in [
            ("새 프로젝트", self.new),
            ("프로젝트 열기", self.open),
            ("프로젝트 저장", self.save),
            ("프로젝트 보관함", self.project_library),
            ("최근 작업", self.recent_projects),
            ("자동저장 복구", self.autosave_restore_ui),
            ("최신 백업 복구", self.recover_backup_ui),
        ]:
            file_menu.add_command(label=text, command=command)
        file_menu.add_separator()
        file_menu.add_command(label="종료", command=self.root.destroy)
        menu_bar.add_cascade(label="파일", menu=file_menu)

        ai_menu = tk.Menu(menu_bar, tearoff=0)
        for text, command in [
            ("한 번에 자동 제작", self.one_click_build_ui),
            ("v5.0 AI 자동 분석", self.v5_analysis_ui),
            ("v5.0 AI 자동 제작", self.v5_build_ui),
            ("v5.1 판매전략 분석", self.v51_strategy_ui),
            ("v6.0 AI 상품기획", self.v60_product_intelligence_ui),
            ("v6.1 AI 디자인 품질", self.v61_design_quality_ui),
            ("v6.3.1 AI 광고 배너", self.v63_ad_banner_ui),
            ("v6.3.1 AI 썸네일 제작", self.v62_thumbnail_ui),
            ("AI 연결 설정", self.ai_settings),
        ]:
            ai_menu.add_command(label=text, command=command)
        menu_bar.add_cascade(label="AI 제작", menu=ai_menu)

        edit_menu = tk.Menu(menu_bar, tearoff=0)
        for text, command in [
            ("컷 목록 관리", self.cut_manager_ui),
            ("컷 레이아웃 자동배치", self.auto_layout_ui),
            ("스토리 자동 구성", self.story_flow_ui),
            ("스토리 점검", self.story_check_ui),
            ("사진 자동 배치", self.auto_image_assign_ui),
            ("사진 사용 점검", self.image_usage_ui),
            ("품목 템플릿 추천", self.apply_category_template_ui),
            ("v5.8 프로젝트 템플릿", self.v58_template_library_ui),
            ("품질 점수", self.quality_score_ui),
        ]:
            edit_menu.add_command(label=text, command=command)
        menu_bar.add_cascade(label="편집·검수", menu=edit_menu)

        review_menu = tk.Menu(menu_bar, tearoff=0)
        for text, command in [
            ("검수 현황", self.review_dashboard_ui),
            ("승인본 저장", self.export_approved_ui),
            ("v5.9 컷 버전·최종승인", self.v59_revision_approval_ui),
            ("등록 전 점검", self.validate_ui),
        ]:
            review_menu.add_command(label=text, command=command)
        menu_bar.add_cascade(label="승인·출력", menu=review_menu)

        batch_menu = tk.Menu(menu_bar, tearoff=0)
        for text, command in [
            ("사진 폴더 자동 제작", self.folder_auto_build_ui),
            ("다중 상품 배치 제작", self.batch_queue_ui),
            ("배치 상품정보 양식", self.batch_metadata_template_ui),
            ("배치 작업 이어하기", self.resume_batch_ui),
            ("배치 사전 점검", self.batch_preflight_ui),
            ("배치 대기열 관리", self.batch_queue_manager_ui),
            ("배치 성능 보고서", self.batch_performance_ui),
            ("v5.3 배치 등록점검", self.v53_batch_registration_ui),
        ]:
            batch_menu.add_command(label=text, command=command)
        menu_bar.add_cascade(label="배치 작업", menu=batch_menu)

        settings_menu = tk.Menu(menu_bar, tearoff=0)
        for text, command in [
            ("v5.7 작업공간 시작", self.workspace_dashboard_ui),
            ("품목 프리셋", self.product_preset_ui),
            ("결과 폴더 안전 설정", self.output_policy_ui),
            ("설정 백업", self.settings_backup_ui),
            ("시스템 진단", self.system_health_ui),
            ("지원 진단 패키지", self.support_bundle_ui),
            ("업데이트 확인", self.update_check_ui),
        ]:
            settings_menu.add_command(label=text, command=command)
        menu_bar.add_cascade(label="설정·진단", menu=settings_menu)

        learn_menu = tk.Menu(menu_bar, tearoff=0)
        for text, command in [
            ("v5.4 작업취향 학습", self.v54_preference_ui),
            ("v5.5 학습 안전관리", self.v55_preference_safety_ui),
        ]:
            learn_menu.add_command(label=text, command=command)
        menu_bar.add_cascade(label="학습", menu=learn_menu)

        help_menu = tk.Menu(menu_bar, tearoff=0)
        help_menu.add_command(label="사용법", command=self.usage_guide_ui)
        help_menu.add_command(label="시스템 진단", command=self.system_health_ui)
        menu_bar.add_cascade(label="도움말", menu=help_menu)
        self.root.config(menu=menu_bar)

        for text, command in [
            ("새 프로젝트", self.new),
            ("사진 불러오기", self.add_images),
            ("한 번에 자동 제작", self.one_click_build_ui),
            ("AI 상품기획", self.v60_product_intelligence_ui),
            ("디자인 점검", self.v61_design_quality_ui),
            ("썸네일 제작", self.v62_thumbnail_ui),
            ("저장", self.save),
            ("사용법", self.usage_guide_ui),
        ]:
            ttk.Button(top, text=text, command=command).pack(side="left", padx=3)

        panes = ttk.Panedwindow(self.root, orient="horizontal")
        panes.pack(fill="both", expand=True, padx=10, pady=(0, 10))
        left = ttk.Frame(panes, padding=10)
        center = ttk.Frame(panes, padding=10)
        right = ttk.Frame(panes, padding=10)
        panes.add(left, weight=1)
        panes.add(center, weight=3)
        panes.add(right, weight=1)

        self.vars = {}
        for key, label in [
            ("product", "상품명"),
            ("category", "품목"),
            ("origin", "원산지"),
            ("feature1", "핵심 특징 1"),
            ("feature2", "핵심 특징 2"),
            ("shipping", "택배사/배송"),
        ]:
            ttk.Label(left, text=label).pack(anchor="w", pady=(5, 0))
            variable = tk.StringVar()
            ttk.Entry(left, textvariable=variable).pack(fill="x")
            self.vars[key] = variable

        ttk.Label(left, text="컷 수").pack(anchor="w", pady=(8, 0))
        self.count = tk.IntVar(value=8)
        ttk.Combobox(left, textvariable=self.count, values=[6, 7, 8, 9, 10], state="readonly").pack(fill="x")

        ttk.Label(left, text="스타일").pack(anchor="w", pady=(8, 0))
        self.style = tk.StringVar(value="프리미엄")
        ttk.Combobox(left, textvariable=self.style, values=list(STYLE_PRESETS), state="readonly").pack(fill="x")

        ttk.Label(left, text="사진 배치").pack(anchor="w", pady=(8, 0))
        self.layout = tk.StringVar(value="균형형")
        ttk.Combobox(left, textvariable=self.layout, values=["균형형", "사진 크게"], state="readonly").pack(fill="x")

        self.background = tk.StringVar()
        for text, command in [
            ("배경색 선택", self.choose_background),
            ("사진 불러오기", self.load_images),
            ("초안 생성", self.generate),
            ("현재 컷 복제", self.duplicate_current),
            ("현재 컷 삭제", self.delete_current),
            ("컷 위로", lambda: self.move_cut(-1)),
            ("컷 아래로", lambda: self.move_cut(1)),
        ]:
            ttk.Button(left, text=text, command=command).pack(fill="x", pady=3)

        ttk.Label(left, text="AI 분석 결과", font=("", 11, "bold")).pack(anchor="w", pady=(10, 3))
        self.analysis_text = tk.Text(left, width=34, height=16, wrap="word")
        self.analysis_text.pack(fill="both", expand=True)

        ttk.Label(center, text="한 컷씩 검수", font=("", 14, "bold")).pack()
        self.preview = ttk.Label(center, anchor="center")
        self.preview.pack(fill="both", expand=True)
        nav = ttk.Frame(center)
        nav.pack()
        ttk.Button(nav, text="◀ 이전", command=self.previous).pack(side="left")
        self.page = ttk.Label(nav, text="0 / 0")
        self.page.pack(side="left", padx=12)
        ttk.Button(nav, text="다음 ▶", command=self.next).pack(side="left")
        ttk.Button(nav, text="실행취소", command=self.undo).pack(side="left", padx=5)
        ttk.Button(nav, text="다시실행", command=self.redo).pack(side="left")
        self.status_bar = ttk.Label(center, relief="sunken", anchor="w")
        self.status_bar.pack(fill="x", pady=(8, 0))

        ttk.Label(right, text="제목").pack(anchor="w")
        self.title = tk.StringVar()
        ttk.Entry(right, textvariable=self.title).pack(fill="x")
        ttk.Label(right, text="본문").pack(anchor="w", pady=(6, 0))
        self.body = tk.Text(right, width=34, height=11, wrap="word")
        self.body.pack(fill="x")

        ttk.Label(right, text="사진 확대").pack(anchor="w", pady=(8, 0))
        self.scale = tk.DoubleVar(value=1.0)
        ttk.Scale(right, from_=0.5, to=2.5, variable=self.scale, orient="horizontal").pack(fill="x")
        move = ttk.Frame(right)
        move.pack(fill="x", pady=5)
        for text, dx, dy in [("←", -20, 0), ("→", 20, 0), ("↑", 0, -20), ("↓", 0, 20)]:
            ttk.Button(move, text=text, width=4, command=lambda x=dx, y=dy: self.move_image(x, y)).pack(side="left", padx=2)

        self.title_size = tk.IntVar(value=33)
        self.body_size = tk.IntVar(value=39)
        self.align = tk.StringVar(value="center")
        self.cut_layout = tk.StringVar(value="기본 카드형")
        ttk.Label(right, text="스토리 단계").pack(anchor="w")
        self.story_stage = tk.StringVar(value="상품 소개")
        ttk.Combobox(
            right,
            textvariable=self.story_stage,
            values=["관심 유도","맛 기대","신뢰 형성","핵심 설득","상품 이해","품질 증명","선별 신뢰","상품 상태","활용 제안","불안 해소","구매 조건","보조 설득","구매 전환"],
            state="readonly",
        ).pack(fill="x")
        ttk.Label(right, text="컷 레이아웃").pack(anchor="w")
        ttk.Combobox(right, textvariable=self.cut_layout, values=CUT_LAYOUT_VARIANTS, state="readonly").pack(fill="x")
        ttk.Label(right, text="제목 크기").pack(anchor="w")
        ttk.Spinbox(right, from_=18, to=60, textvariable=self.title_size).pack(fill="x")
        ttk.Label(right, text="본문 크기").pack(anchor="w")
        ttk.Spinbox(right, from_=18, to=70, textvariable=self.body_size).pack(fill="x")
        ttk.Label(right, text="본문 정렬").pack(anchor="w")
        ttk.Combobox(right, textvariable=self.align, values=["left", "center", "right"], state="readonly").pack(fill="x")

        ttk.Button(right, text="수정 적용", command=self.apply).pack(fill="x", pady=5)
        self.approved = tk.BooleanVar()
        ttk.Checkbutton(right, text="현재 컷 승인", variable=self.approved, command=self.approve).pack(anchor="w", pady=5)
        ttk.Button(right, text="PNG 저장", command=self.export_png).pack(fill="x", pady=3)
        ttk.Button(right, text="PDF 저장", command=self.export_pdf).pack(fill="x", pady=3)

    def status(self, message: str):
        self.status_bar.config(text=message)

    def fields(self) -> dict[str, str]:
        return {key: variable.get() for key, variable in self.vars.items()}

    def snapshot(self):
        self.history.append(json.dumps(self.project.to_dict(), ensure_ascii=False))
        self.history = self.history[-30:]
        self.future.clear()

    def restore_snapshot(self, raw: str):
        self.project = Project.from_dict(json.loads(raw))
        self.current = min(self.current, max(0, len(self.project.cuts) - 1))
        self.show()

    def undo(self):
        if not self.history:
            return
        self.future.append(json.dumps(self.project.to_dict(), ensure_ascii=False))
        self.restore_snapshot(self.history.pop())
        self.status("실행취소")

    def redo(self):
        if not self.future:
            return
        self.history.append(json.dumps(self.project.to_dict(), ensure_ascii=False))
        self.restore_snapshot(self.future.pop())
        self.status("다시실행")

    def choose_background(self):
        color = colorchooser.askcolor()
        if color and color[1]:
            self.background.set(color[1])

    def load_images(self):
        paths = filedialog.askopenfilenames(filetypes=[("이미지", "*.png *.jpg *.jpeg *.webp")])
        if paths:
            self.project.images = list(paths)
            self.analysis_text.delete("1.0", "end")
            self.analysis_text.insert("1.0", "\n".join(Path(path).name for path in paths))
            self.status(f"사진 {len(paths)}장 불러오기 완료")


















    def startup_workspace_flow(self):
        try:
            ensure_workspace_folders(self.workspace_config)
            if is_first_run():
                self.workspace_setup_ui(first_run=True)
                return
            if self.workspace_config.auto_restore_session:
                best=select_best_recovery_candidate()
                if best and best.get("dirty"):
                    if messagebox.askyesno(
                        "미완료 작업 복구",
                        f"{best['product']} 작업이 저장되지 않은 상태로 남아 있습니다.\n"
                        f"출처: {best['source_type']}\n"
                        f"컷 {best['cut_count']}개 / 사진 {best['image_count']}장\n\n"
                        "이 작업을 이어서 열까요?",
                    ):
                        self.restore_workspace_candidate(best)
                        save_startup_history("자동복구",{
                            "product":best["product"],
                            "source_type":best["source_type"],
                        })
                        return
            if self.workspace_config.show_startup_dashboard:
                self.workspace_dashboard_ui()
        except Exception as error:
            self.status(f"시작 작업공간 확인 실패: {error}")

    def restore_workspace_candidate(self,candidate):
        self.snapshot()
        self.project=candidate["project"]
        self.current=max(0,min(int(candidate.get("current_index",0)),max(0,len(self.project.cuts)-1)))
        self.current_project_path=(
            Path(candidate["source_path"])
            if candidate["source_type"]=="최근 프로젝트"
            else None
        )
        for key,variable in self.vars.items():
            variable.set(self.project.fields.get(key,""))
        self.style.set(self.project.style)
        self.layout.set(self.project.layout)
        self.count.set(len(self.project.cuts) or self.workspace_config.default_cut_count)
        self.show()
        self.dirty=bool(candidate.get("dirty",False))
        self.status(f"{candidate['product']} 작업 복구 완료")

    def workspace_setup_ui(self,first_run=False):
        dialog=tk.Toplevel(self.root)
        dialog.title("농작 AI 초기 작업공간 설정")
        dialog.geometry("620x600")
        dialog.transient(self.root)
        dialog.grab_set()

        config=self.workspace_config
        root_var=tk.StringVar(value=config.workspace_root)
        shipping_var=tk.StringVar(value=config.default_shipping)
        style_var=tk.StringVar(value=config.default_style)
        layout_var=tk.StringVar(value=config.default_layout)
        cut_var=tk.IntVar(value=config.default_cut_count)
        auto_restore=tk.BooleanVar(value=config.auto_restore_session)
        startup_dashboard=tk.BooleanVar(value=config.show_startup_dashboard)

        frame=ttk.Frame(dialog,padding=18)
        frame.pack(fill="both",expand=True)
        ttk.Label(frame,text="작업공간 기본 설정",font=("",16,"bold")).pack(anchor="w")
        ttk.Label(
            frame,
            text="상품사진·프로젝트·완성본을 한 곳에 정리하고 다음 실행에서 작업을 이어서 엽니다.",
            wraplength=560,
        ).pack(anchor="w",pady=(6,16))

        ttk.Label(frame,text="작업공간 폴더").pack(anchor="w")
        folder_line=ttk.Frame(frame)
        folder_line.pack(fill="x",pady=(2,10))
        ttk.Entry(folder_line,textvariable=root_var).pack(side="left",fill="x",expand=True)
        def choose_root():
            selected=filedialog.askdirectory(parent=dialog,title="농작 AI 작업공간 선택")
            if selected:root_var.set(selected)
        ttk.Button(folder_line,text="찾기",command=choose_root).pack(side="left",padx=(6,0))

        ttk.Label(frame,text="기본 택배사/배송").pack(anchor="w")
        ttk.Entry(frame,textvariable=shipping_var).pack(fill="x",pady=(2,10))
        ttk.Label(frame,text="기본 상세페이지 스타일").pack(anchor="w")
        ttk.Combobox(frame,textvariable=style_var,values=list(STYLE_PRESETS),state="readonly").pack(fill="x",pady=(2,10))
        ttk.Label(frame,text="기본 사진 배치").pack(anchor="w")
        ttk.Combobox(frame,textvariable=layout_var,values=["균형형","사진 크게"],state="readonly").pack(fill="x",pady=(2,10))
        ttk.Label(frame,text="기본 컷 수").pack(anchor="w")
        ttk.Combobox(frame,textvariable=cut_var,values=[6,7,8,9,10],state="readonly").pack(fill="x",pady=(2,12))
        ttk.Checkbutton(frame,text="미완료 작업을 시작할 때 자동으로 확인",variable=auto_restore).pack(anchor="w",pady=3)
        ttk.Checkbutton(frame,text="시작할 때 작업공간 화면 표시",variable=startup_dashboard).pack(anchor="w",pady=3)

        def save_setup():
            new_config=WorkspaceConfig(
                workspace_root=root_var.get().strip() or config.workspace_root,
                default_shipping=shipping_var.get().strip() or "한진택배",
                default_style=style_var.get(),
                default_layout=layout_var.get(),
                default_cut_count=cut_var.get(),
                auto_restore_session=auto_restore.get(),
                show_startup_dashboard=startup_dashboard.get(),
            )
            save_workspace_config(new_config)
            self.workspace_config=new_config
            mark_first_run_complete({"workspace":new_config.to_dict()})
            apply_workspace_defaults(self.project,new_config,overwrite=False)
            if not self.vars["shipping"].get():
                self.vars["shipping"].set(new_config.default_shipping)
            self.style.set(new_config.default_style)
            self.layout.set(new_config.default_layout)
            self.count.set(new_config.default_cut_count)
            save_startup_history("초기설정 완료",new_config.to_dict())
            dialog.destroy()
            self.status("농작 AI 작업공간 설정 완료")
            if first_run:
                self.workspace_dashboard_ui()

        ttk.Button(frame,text="설정 저장하고 시작",command=save_setup).pack(fill="x",pady=(24,0))
        if not first_run:
            ttk.Button(frame,text="닫기",command=dialog.destroy).pack(fill="x",pady=(6,0))


    def v58_template_library_ui(self):
        dialog=tk.Toplevel(self.root)
        dialog.title("v5.8 프로젝트 템플릿 라이브러리")
        dialog.geometry("1000x680")
        dialog.transient(self.root)

        left=ttk.Frame(dialog,padding=12)
        left.pack(side="left",fill="y")
        right=ttk.Frame(dialog,padding=(0,12,12,12))
        right.pack(side="right",fill="both",expand=True)

        search_var=tk.StringVar()
        ttk.Label(left,text="템플릿 검색").pack(anchor="w")
        search_entry=ttk.Entry(left,textvariable=search_var,width=31)
        search_entry.pack(fill="x",pady=(2,8))

        listbox=tk.Listbox(left,width=36,height=28)
        listbox.pack(fill="both",expand=True)

        detail=tk.Text(right,wrap="word")
        detail.pack(fill="both",expand=True)
        current_templates=[]

        def refresh():
            nonlocal current_templates
            keyword=search_var.get().strip().lower()
            templates=recommend_project_templates(
                self.vars["category"].get(),
                self.vars["product"].get(),
            )
            if keyword:
                templates=[
                    item for item in templates
                    if keyword in item.get("name","").lower()
                    or keyword in item.get("category","").lower()
                    or keyword in item.get("description","").lower()
                ]
            current_templates=templates
            listbox.delete(0,"end")
            for item in templates:
                prefix="기본" if item.get("builtin") else "사용자"
                listbox.insert(
                    "end",
                    f"[{prefix}] {item['name']} · {item['cut_count']}컷",
                )
            summary=template_library_summary()
            dialog.title(
                f"v5.8 프로젝트 템플릿 · 기본 {summary['builtin_count']} / 사용자 {summary['custom_count']}"
            )
            if templates:
                listbox.selection_set(0)
                show_detail()

        def selected_template():
            selected=listbox.curselection()
            if not selected:return None
            return current_templates[selected[0]]

        def show_detail(event=None):
            item=selected_template()
            detail.config(state="normal")
            detail.delete("1.0","end")
            if not item:
                detail.insert("1.0","템플릿을 선택하세요.")
                detail.config(state="disabled")
                return
            validation=validate_project_template(item)
            lines=[
                item["name"],
                "="*40,
                f"구분: {'기본 템플릿' if item.get('builtin') else '사용자 템플릿'}",
                f"품목: {item['category']}",
                f"스타일: {item['style']} / {item['layout']}",
                f"컷 수: {item['cut_count']}컷",
                f"추천 점수: {item.get('recommendation_score',0)}점",
                f"추천 이유: {', '.join(item.get('recommendation_reasons',[]))}",
                f"설명: {item.get('description','')}",
                f"검증 상태: {'정상' if validation['valid'] else '확인 필요'}",
                "",
                "컷 구성",
            ]
            lines.extend(
                f"{index}. [{cut.get('story_stage','')}] {cut.get('title','')} · {cut.get('layout_variant','')}"
                for index,cut in enumerate(item["cuts"],1)
            )
            if validation["issues"]:
                lines.extend(["","검증 문제"])
                lines.extend(f"- {issue}" for issue in validation["issues"])
            detail.insert("1.0","\n".join(lines))
            detail.config(state="disabled")

        def create_from_selected():
            item=selected_template()
            if not item:return
            product=simpledialog.askstring(
                "템플릿으로 새 프로젝트",
                "상품명을 입력하세요.",
                initialvalue=self.vars["product"].get(),
                parent=dialog,
            )
            if product is None:return
            origin=simpledialog.askstring(
                "원산지",
                "원산지를 입력하세요.",
                initialvalue=self.vars["origin"].get(),
                parent=dialog,
            )
            if origin is None:return
            self.snapshot()
            self.project=project_from_template(
                item,
                product_name=product,
                origin=origin,
                shipping=self.vars["shipping"].get() or self.workspace_config.default_shipping,
                images=list(self.project.images),
            )
            self.current=0
            self.current_project_path=None
            for key,var in self.vars.items():
                var.set(self.project.fields.get(key,""))
            self.style.set(self.project.style)
            self.layout.set(self.project.layout)
            self.count.set(len(self.project.cuts))
            self.show()
            self.dirty=True
            save_startup_history("템플릿 프로젝트 시작",{
                "template":item["name"],"product":product,
            })
            dialog.destroy()
            self.status(f"{item['name']} 템플릿으로 새 프로젝트 생성 완료")

        def save_current_template():
            if not self.project.cuts:
                return messagebox.showwarning("저장 불가","현재 상세페이지 컷이 없습니다.",parent=dialog)
            name=simpledialog.askstring(
                "사용자 템플릿 저장",
                "템플릿 이름을 입력하세요.",
                initialvalue=f"{self.project.fields.get('category','식품')} 사용자 템플릿",
                parent=dialog,
            )
            if not name:return
            description=simpledialog.askstring(
                "템플릿 설명",
                "이 템플릿의 용도나 특징을 입력하세요.",
                initialvalue="현재 승인·수정한 상세페이지 구성을 저장",
                parent=dialog,
            ) or ""
            try:
                template=create_template_from_project(self.project,name,description)
                upsert_custom_project_template(template)
            except Exception as error:
                return messagebox.showerror("템플릿 저장 오류",str(error),parent=dialog)
            refresh()
            messagebox.showinfo("템플릿 저장 완료",f"{name} 템플릿을 저장했습니다.",parent=dialog)

        def delete_selected():
            item=selected_template()
            if not item:return
            if item.get("builtin"):
                return messagebox.showinfo("삭제 불가","기본 템플릿은 삭제할 수 없습니다.",parent=dialog)
            if not messagebox.askyesno(
                "사용자 템플릿 삭제",
                f"{item['name']} 템플릿을 삭제할까요?",
                parent=dialog,
            ):return
            delete_custom_project_template(item["template_id"])
            refresh()

        def export_selected():
            item=selected_template()
            if not item:return
            path=filedialog.asksaveasfilename(
                parent=dialog,
                defaultextension=".json",
                initialfile=f"{sanitize_name(item['name'])}_템플릿.json",
                filetypes=[("농작 템플릿","*.json")],
            )
            if path:
                export_template_pack([item],path)
                messagebox.showinfo("내보내기 완료",path,parent=dialog)

        def import_pack_ui():
            path=filedialog.askopenfilename(
                parent=dialog,
                title="농작 템플릿 묶음 선택",
                filetypes=[("농작 템플릿","*.json")],
            )
            if not path:return
            try:
                result=import_template_pack(path)
            except Exception as error:
                return messagebox.showerror("템플릿 가져오기 오류",str(error),parent=dialog)
            refresh()
            messagebox.showinfo(
                "템플릿 가져오기 완료",
                f"가져옴 {result['imported_count']}개 / 제외 {result['rejected_count']}개",
                parent=dialog,
            )

        search_var.trace_add("write",lambda *args:refresh())
        listbox.bind("<<ListboxSelect>>",show_detail)
        listbox.bind("<Double-1>",lambda event:create_from_selected())

        buttons1=ttk.Frame(right,padding=(0,10,0,0))
        buttons1.pack(fill="x")
        ttk.Button(buttons1,text="선택 템플릿으로 시작",command=create_from_selected).pack(side="right",padx=3)
        ttk.Button(buttons1,text="현재 프로젝트를 템플릿 저장",command=save_current_template).pack(side="right",padx=3)

        buttons2=ttk.Frame(right,padding=(0,6,0,0))
        buttons2.pack(fill="x")
        ttk.Button(buttons2,text="템플릿 가져오기",command=import_pack_ui).pack(side="left",padx=3)
        ttk.Button(buttons2,text="선택 템플릿 내보내기",command=export_selected).pack(side="left",padx=3)
        ttk.Button(buttons2,text="사용자 템플릿 삭제",command=delete_selected).pack(side="left",padx=3)
        refresh()

    def workspace_dashboard_ui(self):
        config=self.workspace_config
        data=startup_dashboard_data(config)
        candidates=collect_recovery_candidates(config)

        dialog=tk.Toplevel(self.root)
        dialog.title("v5.7 작업공간 시작")
        dialog.geometry("900x650")
        dialog.transient(self.root)

        header=ttk.Frame(dialog,padding=14)
        header.pack(fill="x")
        ttk.Label(header,text="농작 AI 작업공간",font=("",17,"bold")).pack(side="left")
        ttk.Label(header,text=str(data["paths"]["root"])).pack(side="right")

        tree=ttk.Treeview(
            dialog,
            columns=("source","saved","images","cuts","dirty"),
            show="tree headings",
            selectmode="browse",
        )
        tree.heading("#0",text="상품명")
        tree.heading("source",text="출처")
        tree.heading("saved",text="저장 시각")
        tree.heading("images",text="사진")
        tree.heading("cuts",text="컷")
        tree.heading("dirty",text="미저장")
        tree.column("#0",width=210)
        tree.column("source",width=100,anchor="center")
        tree.column("saved",width=190)
        tree.column("images",width=60,anchor="center")
        tree.column("cuts",width=60,anchor="center")
        tree.column("dirty",width=70,anchor="center")
        tree.pack(fill="both",expand=True,padx=14,pady=(0,10))

        for index,item in enumerate(candidates):
            tree.insert(
                "","end",iid=str(index),text=item["product"],
                values=(
                    item["source_type"],item["saved_at"],item["image_count"],
                    item["cut_count"],"예" if item["dirty"] else "아니오",
                ),
            )

        summary=ttk.Label(
            dialog,
            text=(
                f"복구 가능한 작업 {len(candidates)}개 · "
                f"프로젝트 폴더: {data['paths']['projects']} · "
                f"완성본 폴더: {data['paths']['outputs']}"
            ),
        )
        summary.pack(anchor="w",padx=14,pady=(0,10))

        def open_selected():
            selected=tree.selection()
            if not selected:return
            item=candidates[int(selected[0])]
            self.restore_workspace_candidate(item)
            save_startup_history("작업공간에서 열기",{
                "product":item["product"],"source_type":item["source_type"],
            })
            dialog.destroy()

        def new_workspace_project():
            self.snapshot()
            self.project=create_workspace_project(config=self.workspace_config)
            self.current=0
            self.current_project_path=None
            for key,var in self.vars.items():
                var.set(self.project.fields.get(key,""))
            self.style.set(self.project.style)
            self.layout.set(self.project.layout)
            self.count.set(self.workspace_config.default_cut_count)
            self.show()
            self.dirty=False
            save_startup_history("새 작업 시작")
            dialog.destroy()
            self.status("새 작업공간 프로젝트를 시작했습니다.")

        def clear_session_ui():
            if not messagebox.askyesno(
                "미완료 세션 정리",
                "현재 복구 세션을 보관함에 백업한 뒤 시작 목록에서 제거할까요?",
                parent=dialog,
            ):return
            result=clear_recovery_state(True)
            messagebox.showinfo(
                "세션 정리 완료",
                f"백업 {len(result['archived'])}개 / 제거 {len(result['removed'])}개",
                parent=dialog,
            )
            dialog.destroy()
            self.workspace_dashboard_ui()

        buttons=ttk.Frame(dialog,padding=(14,0,14,14))
        buttons.pack(fill="x")
        ttk.Button(buttons,text="초기설정 변경",command=lambda:self.workspace_setup_ui(False)).pack(side="left",padx=3)
        ttk.Button(buttons,text="복구 세션 정리",command=clear_session_ui).pack(side="left",padx=3)
        ttk.Button(buttons,text="새 프로젝트",command=new_workspace_project).pack(side="right",padx=3)
        ttk.Button(buttons,text="선택 작업 열기",command=open_selected).pack(side="right",padx=3)
        tree.bind("<Double-1>",lambda event:open_selected())

    def batch_performance_ui(self):
        state_path=filedialog.askopenfilename(
            title="배치 상태 파일 선택",
            filetypes=[("배치 상태 JSON","*.json")],
        )
        if not state_path:
            return
        try:
            jobs=load_batch_state(state_path)
        except Exception as error:
            return messagebox.showerror("배치 상태 오류",str(error))

        log_path=Path(state_path).with_name(BATCH_LOG_FILENAME)
        logs=load_batch_logs(log_path)
        estimate=estimate_queue_seconds(jobs)
        performance=batch_performance_summary(jobs,logs)

        lines=[
            f"남은 작업: {estimate['job_count']}개",
            f"예상 소요시간: 약 {estimate['estimated_minutes']}분",
            f"완료 기록: {performance['completed_count']}개",
            f"평균 처리시간: {performance['average_seconds']}초",
            f"실패 작업: {performance['failure_count']}개",
            "",
            "느린 작업",
        ]
        if performance["slowest_jobs"]:
            lines.extend(
                f"- {item['product_name']}: {item['seconds']}초 / 시도 {item['attempts']}회"
                for item in performance["slowest_jobs"]
            )
        else:
            lines.append("- 처리시간 기록 없음")

        if performance["failures"]:
            lines.extend(["","실패 작업"])
            lines.extend(
                f"- {item['product_name']}: {item['error']}"
                for item in performance["failures"]
            )

        dialog=tk.Toplevel(self.root)
        dialog.title("배치 성능 보고서")
        dialog.geometry("650x520")
        text=tk.Text(dialog,wrap="word")
        text.pack(fill="both",expand=True,padx=12,pady=12)
        text.insert("1.0","\n".join(lines))
        text.config(state="disabled")

        def save_report():
            path=filedialog.asksaveasfilename(
                parent=dialog,
                defaultextension=".json",
                initialfile="batch_performance_report.json",
                filetypes=[("JSON 보고서","*.json")],
            )
            if path:
                export_batch_performance_report(jobs,log_path,path)
                self.status("배치 성능 보고서 저장 완료")

        ttk.Button(dialog,text="보고서 저장",command=save_report).pack(pady=(0,12))

    def batch_queue_manager_ui(self):
        state_path=filedialog.askopenfilename(
            title="배치 상태 파일 선택",
            filetypes=[("배치 상태 JSON","*.json")],
        )
        if not state_path:
            return
        try:
            jobs=sort_queue_jobs(load_batch_state(state_path))
        except Exception as error:
            return messagebox.showerror("대기열 불러오기 오류",str(error))

        control_path=Path(state_path).with_name(QUEUE_CONTROL_FILENAME)
        log_path=Path(state_path).with_name(BATCH_LOG_FILENAME)
        control=load_queue_control(control_path)

        dialog=tk.Toplevel(self.root)
        dialog.title("배치 대기열 관리")
        dialog.geometry("1040x620")
        dialog.transient(self.root)

        tree=ttk.Treeview(
            dialog,
            columns=("priority","enabled","status","attempts","folder"),
            show="tree headings",
            selectmode="extended",
        )
        tree.heading("#0",text="순서 · 상품명")
        tree.heading("priority",text="우선순위")
        tree.heading("enabled",text="실행")
        tree.heading("status",text="상태")
        tree.heading("attempts",text="시도")
        tree.heading("folder",text="사진 폴더")
        tree.column("#0",width=230)
        tree.column("priority",width=90,anchor="center")
        tree.column("enabled",width=70,anchor="center")
        tree.column("status",width=90,anchor="center")
        tree.column("attempts",width=60,anchor="center")
        tree.column("folder",width=450)
        tree.pack(fill="both",expand=True,padx=12,pady=12)

        paused=tk.BooleanVar(value=control["paused"])
        stop_after=tk.BooleanVar(value=control["stop_after_current"])
        status_label=ttk.Label(dialog)
        status_label.pack(anchor="w",padx=12,pady=(0,8))

        current_jobs=list(jobs)

        def selected_ids():
            return [int(item) for item in tree.selection()]

        def refresh(select=None):
            tree.delete(*tree.get_children())
            ordered=sorted(
                current_jobs,
                key=lambda item:int(item.get("queue_position",999999)),
            )
            for job in ordered:
                tree.insert(
                    "",
                    "end",
                    iid=str(job["id"]),
                    text=f"{int(job.get('queue_position',0)):02d}. {job.get('product_name','')}",
                    values=(
                        job.get("priority","보통"),
                        "사용" if job.get("enabled",True) else "제외",
                        job.get("status","대기"),
                        job.get("attempts",0),
                        job.get("folder",""),
                    ),
                )
            for job_id in select or []:
                if tree.exists(str(job_id)):
                    tree.selection_add(str(job_id))
            summary=queue_summary(current_jobs)
            estimate=estimate_queue_seconds(current_jobs)
            status_label.config(
                text=(
                    f"전체 {summary['total']}개 / 실행 {summary['enabled_count']}개 / "
                    f"제외 {summary['disabled_count']}개 / "
                    f"긴급 {summary['priority_counts']['긴급']} / "
                    f"높음 {summary['priority_counts']['높음']} / "
                    f"예상 {estimate['estimated_minutes']}분"
                )
            )

        def save_state():
            save_batch_state(current_jobs,state_path)
            save_queue_control(paused.get(),stop_after.get(),control_path)
            self.status("배치 대기열 상태 저장 완료")

        def change_priority(priority):
            nonlocal current_jobs
            ids=selected_ids()
            if not ids:return
            current_jobs=set_job_priority(current_jobs,ids,priority)
            refresh(ids)
            save_state()

        def change_enabled(enabled):
            nonlocal current_jobs
            ids=selected_ids()
            if not ids:return
            current_jobs=set_jobs_enabled(current_jobs,ids,enabled)
            refresh(ids)
            save_state()

        def move(direction):
            nonlocal current_jobs
            ids=selected_ids()
            if not ids:return
            current_jobs=move_queue_jobs(current_jobs,ids,direction)
            refresh(ids)
            save_state()

        def run_queue():
            nonlocal current_jobs
            save_queue_control(False,stop_after.get(),control_path)
            paused.set(False)
            save_batch_state(current_jobs,state_path)
            dialog.update_idletasks()
            try:
                current_jobs,result=run_queue_jobs(
                    current_jobs,
                    ai_config=self.ai_config,
                    state_path=state_path,
                    control_path=control_path,
                    log_path=log_path,
                )
            except Exception as error:
                return messagebox.showerror("대기열 실행 오류",str(error),parent=dialog)
            save_batch_state(current_jobs,state_path)
            refresh()
            messagebox.showinfo(
                "대기열 실행 결과",
                f"중단 사유: {result['reason']}\n"
                f"성공 {result['summary']['counts']['성공']}개\n"
                f"실패 {result['summary']['counts']['실패']}개\n"
                f"남은 작업 {result['remaining_count']}개",
                parent=dialog,
            )

        def save_report():
            path=filedialog.asksaveasfilename(
                parent=dialog,
                defaultextension=".json",
                initialfile="batch_queue_report.json",
                filetypes=[("JSON 보고서","*.json")],
            )
            if path:
                export_queue_report(current_jobs,path)

        controls=ttk.Frame(dialog,padding=(12,0,12,8))
        controls.pack(fill="x")
        ttk.Label(controls,text="선택 우선순위").pack(side="left")
        for priority in QUEUE_PRIORITIES:
            ttk.Button(
                controls,
                text=priority,
                command=lambda value=priority:change_priority(value),
            ).pack(side="left",padx=2)
        ttk.Button(controls,text="실행 포함",command=lambda:change_enabled(True)).pack(side="left",padx=(12,2))
        ttk.Button(controls,text="실행 제외",command=lambda:change_enabled(False)).pack(side="left",padx=2)
        ttk.Button(controls,text="위로",command=lambda:move(-1)).pack(side="right",padx=2)
        ttk.Button(controls,text="아래로",command=lambda:move(1)).pack(side="right",padx=2)

        bottom=ttk.Frame(dialog,padding=(12,0,12,12))
        bottom.pack(fill="x")
        ttk.Checkbutton(
            bottom,
            text="대기열 일시정지",
            variable=paused,
            command=save_state,
        ).pack(side="left")
        ttk.Checkbutton(
            bottom,
            text="현재 작업 완료 후 정지",
            variable=stop_after,
            command=save_state,
        ).pack(side="left",padx=12)
        ttk.Button(bottom,text="대기열 실행",command=run_queue).pack(side="right",padx=3)
        ttk.Button(bottom,text="보고서 저장",command=save_report).pack(side="right",padx=3)
        ttk.Button(bottom,text="상태 저장",command=save_state).pack(side="right",padx=3)

        refresh()

    def output_policy_ui(self):
        root_folder=filedialog.askdirectory(title="상품 폴더들이 들어 있는 상위 폴더 선택")
        if not root_folder:return
        output_folder=filedialog.askdirectory(title="결과 저장 상위 폴더 선택")
        if not output_folder:return

        jobs=create_batch_jobs(
            root_folder,
            output_folder,
            default_fields=self.fields(),
            cut_count=self.count.get(),
        )
        if not jobs:
            return messagebox.showinfo("결과 폴더 안전 설정","상품 폴더를 찾지 못했습니다.")

        estimate=estimate_batch_required_space(jobs)
        space=disk_space_check(output_folder,estimate["estimated_output_bytes"])

        dialog=tk.Toplevel(self.root)
        dialog.title("결과 폴더 안전 설정")
        dialog.geometry("660x460")
        dialog.transient(self.root)

        ttk.Label(dialog,text="결과 충돌 처리 방식",font=("",12,"bold")).pack(anchor="w",padx=16,pady=(16,6))
        policy=tk.StringVar(value="새 버전 폴더")
        ttk.Combobox(
            dialog,
            textvariable=policy,
            values=OUTPUT_POLICIES,
            state="readonly",
        ).pack(fill="x",padx=16)

        info=tk.Text(dialog,height=15,wrap="word")
        info.pack(fill="both",expand=True,padx=16,pady=12)
        lines=[
            f"상품 수: {len(jobs)}개",
            f"원본 사진: {estimate['image_count']}장 / 약 {estimate['source_mb']}MB",
            f"생성 예정 컷: {estimate['cut_count']}컷",
            f"예상 필요 공간: 약 {estimate['estimated_output_mb']}MB",
            f"현재 여유 공간: 약 {space['free_mb']}MB",
            f"저장공간 상태: {'충분' if space['enough'] else '부족'}",
            "",
            "처리 방식",
            "- 새 버전 폴더: 기존 결과를 유지하고 _v2, _v3 폴더 생성",
            "- 기존 결과 백업: 기존 폴더를 날짜가 붙은 백업 폴더로 이동",
            "- 빈 폴더만 사용: 기존 파일이 있으면 작업 차단",
        ]
        info.insert("1.0","\n".join(lines))
        info.config(state="disabled")

        def apply_policy():
            if not space["enough"]:
                return messagebox.showerror(
                    "저장공간 부족",
                    "예상 출력 용량보다 남은 저장공간이 부족합니다.",
                    parent=dialog,
                )
            try:
                updated,changes=apply_output_policy_to_jobs(jobs,policy.get())
                report_path=Path(output_folder)/"output_policy_report.json"
                export_output_policy_report(changes,space,report_path)
                state_path=Path(output_folder)/BATCH_STATE_FILENAME
                save_batch_state(updated,state_path)
            except Exception as error:
                return messagebox.showerror("결과 폴더 설정 오류",str(error),parent=dialog)
            dialog.destroy()
            messagebox.showinfo(
                "결과 폴더 설정 완료",
                f"{len(updated)}개 상품의 출력 폴더를 안전하게 설정했습니다.\n\n"
                f"상태 파일: {state_path}\n"
                f"보고서: {report_path}",
            )
            self.status("결과 폴더 안전 설정 완료")

        ttk.Button(dialog,text="선택 방식 적용",command=apply_policy).pack(fill="x",padx=16,pady=(0,16))

    def batch_metadata_template_ui(self):
        root_folder=filedialog.askdirectory(title="상품 폴더들이 들어 있는 상위 폴더 선택")
        if not root_folder:return
        path=filedialog.asksaveasfilename(defaultextension=".csv",initialfile="배치_상품정보_양식.csv",filetypes=[("CSV 파일","*.csv")])
        if path:
            export_batch_metadata_template(root_folder,path)
            messagebox.showinfo("배치 상품정보 양식","상품별 정보를 입력할 CSV 양식을 만들었습니다.")
            self.status("배치 상품정보 CSV 양식 생성 완료")

    def resume_batch_ui(self):
        state_path=filedialog.askopenfilename(title="batch_state.json 선택",filetypes=[("배치 상태 JSON","*.json")])
        if not state_path:return
        try: jobs=load_batch_state(state_path)
        except Exception as error:return messagebox.showerror("배치 상태 오류",str(error))
        remaining=sum(1 for job in jobs if job.get("status")!="성공")
        if not remaining:
            validation=validate_batch_outputs(jobs)
            return messagebox.showinfo("배치 작업 이어하기",f"남은 작업이 없습니다.\n정상 {validation['valid_count']}개 / 확인 필요 {validation['invalid_count']}개")
        if not messagebox.askyesno("배치 작업 이어하기",f"남은 작업 {remaining}개를 이어서 제작할까요?"):return
        finished=resume_batch_jobs(jobs,self.ai_config,state_path)
        validation=validate_batch_outputs(finished)
        report_path=Path(state_path).with_name("batch_resume_report.json")
        export_batch_report(finished,report_path)
        summary=batch_summary(finished)
        messagebox.showinfo("배치 작업 재개 완료",f"성공 {summary['counts']['성공']}개\n실패 {summary['counts']['실패']}개\n정상 결과 {validation['valid_count']}개\n확인 필요 {validation['invalid_count']}개")
        self.status("배치 작업 이어하기 완료")

    def batch_preflight_ui(self):
        root_folder=filedialog.askdirectory(title="상품 폴더들이 들어 있는 상위 폴더 선택")
        if not root_folder:return
        output_folder=filedialog.askdirectory(title="결과 저장 폴더 선택")
        if not output_folder:return
        jobs=create_batch_jobs(root_folder,output_folder,default_fields=self.fields(),cut_count=self.count.get())
        metadata_path=filedialog.askopenfilename(title="배치 상품정보 CSV 선택 (취소하면 기본값 사용)",filetypes=[("CSV 파일","*.csv")])
        if metadata_path:
            jobs=apply_batch_metadata(jobs,load_batch_metadata(metadata_path))
        preflight=preflight_check_jobs(jobs)
        dialog=tk.Toplevel(self.root); dialog.title("배치 사전 점검"); dialog.geometry("980x600")
        tree=ttk.Treeview(dialog,columns=("status","images","cuts","issues"),show="tree headings",selectmode="extended")
        for column,title,width in [("#0","상품명",180),("status","상태",80),("images","사진",60),("cuts","컷",60),("issues","점검 내용",560)]:
            tree.heading(column,text=title); tree.column(column,width=width)
        tree.pack(fill="both",expand=True,padx=12,pady=12)
        for item in preflight["results"]:
            issues=" / ".join(f"[{issue['level']}] {issue['message']}" for issue in item["issues"]) or "문제 없음"
            tree.insert("", "end", iid=str(item["job_id"]), text=item["product_name"], values=(item["status"],item["image_count"],item["cut_count"],issues))
            if item["ready"]: tree.selection_add(str(item["job_id"]))
        ttk.Label(dialog,text=f"전체 {preflight['total']}개 / 정상 {preflight['counts']['정상']} / 경고 {preflight['counts']['경고']} / 오류 {preflight['counts']['오류']}").pack(anchor="w",padx=12)
        def save_report():
            path=filedialog.asksaveasfilename(parent=dialog,defaultextension=".json",initialfile="batch_preflight_report.json",filetypes=[("JSON 보고서","*.json")])
            if path:
                export_preflight_report(jobs,path); create_batch_manifest(jobs,Path(path).with_name("batch_manifest.json"))
        def start_selected():
            selected_jobs=select_jobs_by_ids(jobs,[int(item) for item in tree.selection()])
            selected_check=preflight_check_jobs(selected_jobs)
            if selected_check["blocked_count"]: return messagebox.showerror("선택 작업 확인","오류 상태 작업을 선택 해제해 주세요.",parent=dialog)
            if not selected_jobs:return
            state_path=Path(output_folder)/BATCH_STATE_FILENAME; save_batch_state(selected_jobs,state_path)
            dialog.destroy(); finished=run_batch_jobs(selected_jobs,self.ai_config); save_batch_state(finished,state_path)
            report_path=Path(output_folder)/"batch_report.json"; export_batch_report(finished,report_path)
            summary=batch_summary(finished); messagebox.showinfo("선택 배치 제작 완료",f"성공 {summary['counts']['성공']}개\n실패 {summary['counts']['실패']}개")
        buttons=ttk.Frame(dialog,padding=12); buttons.pack(fill="x")
        ttk.Button(buttons,text="점검 보고서 저장",command=save_report).pack(side="left")
        ttk.Button(buttons,text="선택한 상품만 제작",command=start_selected).pack(side="right")

    def batch_queue_ui(self):
        root_folder=filedialog.askdirectory(title="상품 폴더들이 들어 있는 상위 폴더 선택")
        if not root_folder:
            return
        output_folder=filedialog.askdirectory(title="결과 저장 폴더 선택")
        if not output_folder:
            return

        try:
            jobs=create_batch_jobs(
                root_folder,
                output_folder,
                default_fields=self.fields(),
                cut_count=self.count.get(),
            )
        except Exception as error:
            return messagebox.showerror("배치 작업 생성 오류",str(error))

        if not jobs:
            return messagebox.showinfo(
                "배치 제작",
                "상품 사진이 들어 있는 하위 폴더를 찾지 못했습니다.",
            )

        dialog=tk.Toplevel(self.root)
        dialog.title("다중 상품 배치 제작")
        dialog.geometry("900x560")
        dialog.transient(self.root)

        tree=ttk.Treeview(
            dialog,
            columns=("folder","status","cuts","error"),
            show="tree headings",
        )
        tree.heading("#0",text="상품명")
        tree.heading("folder",text="사진 폴더")
        tree.heading("status",text="상태")
        tree.heading("cuts",text="컷")
        tree.heading("error",text="오류")
        tree.column("#0",width=180)
        tree.column("folder",width=280)
        tree.column("status",width=90,anchor="center")
        tree.column("cuts",width=60,anchor="center")
        tree.column("error",width=240)
        tree.pack(fill="both",expand=True,padx=12,pady=12)

        progress=tk.DoubleVar(value=0)
        ttk.Progressbar(
            dialog,
            variable=progress,
            maximum=max(1,len(jobs)),
        ).pack(fill="x",padx=12,pady=(0,8))

        status_label=ttk.Label(dialog,text=f"대기 중: {len(jobs)}개 상품")
        status_label.pack(anchor="w",padx=12,pady=(0,8))

        current_jobs=list(jobs)

        def refresh():
            tree.delete(*tree.get_children())
            for job in current_jobs:
                result=job.get("result",{})
                tree.insert(
                    "",
                    "end",
                    iid=str(job["id"]),
                    text=job.get("product_name",""),
                    values=(
                        job.get("folder",""),
                        job.get("status","대기"),
                        result.get("cut_count",job.get("cut_count",8)),
                        job.get("error",""),
                    ),
                )

        def execute():
            nonlocal current_jobs
            run_button.config(state="disabled")
            completed=[]
            for index,job in enumerate(current_jobs,1):
                job["status"]="진행 중"
                refresh()
                status_label.config(
                    text=f"{index}/{len(current_jobs)} 처리 중: {job.get('product_name','')}"
                )
                dialog.update_idletasks()

                result=run_batch_job(job,self.ai_config)
                completed.append(result)
                current_jobs=completed+current_jobs[index:]
                progress.set(index)
                refresh()
                dialog.update_idletasks()

            summary=batch_summary(current_jobs)
            report_path=Path(output_folder)/"batch_report.json"
            export_batch_report(current_jobs,report_path)
            status_label.config(
                text=(
                    f"완료: 성공 {summary['counts']['성공']} / "
                    f"실패 {summary['counts']['실패']} / "
                    f"성공률 {summary['success_rate']}%"
                )
            )
            run_button.config(state="normal")
            messagebox.showinfo(
                "배치 제작 완료",
                f"총 {summary['total']}개\n"
                f"성공 {summary['counts']['성공']}개\n"
                f"실패 {summary['counts']['실패']}개\n\n"
                f"보고서: {report_path}",
                parent=dialog,
            )
            self.status("다중 상품 배치 제작 완료")

        buttons=ttk.Frame(dialog,padding=(12,0,12,12))
        buttons.pack(fill="x")
        run_button=ttk.Button(
            buttons,
            text="배치 제작 시작",
            command=execute,
        )
        run_button.pack(side="left")
        ttk.Button(
            buttons,
            text="닫기",
            command=dialog.destroy,
        ).pack(side="right")

        refresh()

    def folder_auto_build_ui(self):
        folder=filedialog.askdirectory()
        if not folder:
            return
        self.status("사진 폴더 분석과 자동 제작 중...")
        self.root.update_idletasks()
        try:
            project,result=build_project_from_folder(
                folder,
                fields=self.fields(),
                cut_count=self.count.get(),
                ai_config=self.ai_config,
            )
        except Exception as error:
            return messagebox.showerror("사진 폴더 자동 제작 오류",str(error))

        self.snapshot()
        self.project=project
        self.last_workflow_result=result
        for key,variable in self.vars.items():
            variable.set(project.fields.get(key,""))
        self.style.set(project.style)
        self.layout.set(project.layout)
        self.current=0
        self.show()
        self.dirty=True

        scan=result["folder_scan"]
        messagebox.showinfo(
            "사진 폴더 자동 제작 완료",
            f"발견 {scan['total_found']}장\n"
            f"고유 사진 {scan['unique_count']}장\n"
            f"중복 제외 {scan['duplicate_count']}장\n"
            f"상세페이지 {len(project.cuts)}컷 생성",
        )
        self.status("사진 폴더 자동 제작 완료")

    def product_preset_ui(self):
        dialog=tk.Toplevel(self.root)
        dialog.title("품목 프리셋")
        dialog.geometry("680x460")
        dialog.transient(self.root)

        presets=load_product_presets()
        listbox=tk.Listbox(dialog)
        listbox.pack(fill="both",expand=True,padx=12,pady=12)

        def refresh():
            nonlocal presets
            presets=load_product_presets()
            listbox.delete(0,"end")
            for item in presets:
                fields=item.get("fields",{})
                listbox.insert(
                    "end",
                    f"{item.get('name','')} | {fields.get('category','')} | "
                    f"{fields.get('origin','')} | {item.get('style','')} | "
                    f"{item.get('cut_count',8)}컷",
                )

        def save_current():
            name=simpledialog.askstring(
                "프리셋 저장",
                "프리셋 이름을 입력하세요.",
                parent=dialog,
            )
            if not name:
                return
            preset=create_product_preset(
                name,
                self.fields(),
                self.style.get(),
                self.layout.get(),
                self.count.get(),
            )
            upsert_product_preset(preset)
            refresh()
            self.status(f"품목 프리셋 저장: {name}")

        def apply_selected():
            selected=listbox.curselection()
            if not selected:
                return
            preset=presets[selected[0]]
            result=apply_product_preset(self.fields(),preset,preserve_product_name=True)
            for key,value in result["fields"].items():
                if key in self.vars:
                    self.vars[key].set(value)
            self.style.set(result["style"])
            self.layout.set(result["layout"])
            self.count.set(result["cut_count"])
            dialog.destroy()
            self.status(f"품목 프리셋 적용: {preset.get('name','')}")

        def delete_selected():
            selected=listbox.curselection()
            if not selected:
                return
            preset=presets[selected[0]]
            if not messagebox.askyesno(
                "프리셋 삭제",
                f"{preset.get('name','')} 프리셋을 삭제할까요?",
                parent=dialog,
            ):
                return
            delete_product_preset(preset.get("name",""))
            refresh()

        buttons=ttk.Frame(dialog,padding=(12,0,12,12))
        buttons.pack(fill="x")
        ttk.Button(buttons,text="현재 설정 저장",command=save_current).pack(side="left",padx=3)
        ttk.Button(buttons,text="선택 적용",command=apply_selected).pack(side="left",padx=3)
        ttk.Button(buttons,text="선택 삭제",command=delete_selected).pack(side="left",padx=3)
        listbox.bind("<Double-1>",lambda event:apply_selected())
        refresh()

    def periodic_autosave(self):
        try:
            if self.dirty and (self.project.cuts or self.project.images):
                create_autosave_snapshot(self.project)
                save_session_state(self.project,self.current,self.dirty)
                self.status("자동저장 완료")
        except Exception as error:
            log_error(error,"주기 자동저장")
        finally:
            self.root.after(self.autosave_interval_ms,self.periodic_autosave)

    def restore_session_prompt(self):
        state=load_session_state()
        if not state or not state.get("dirty"):
            return
        answer=messagebox.askyesno(
            "이전 작업 복구",
            "이전에 저장되지 않은 작업이 있습니다.\n복구할까요?",
        )
        if not answer:
            return
        project=state["project_object"]
        self.project=project
        self.current=min(
            int(state.get("current_index",0)),
            max(0,len(project.cuts)-1),
        )
        for key,variable in self.vars.items():
            variable.set(project.fields.get(key,""))
        self.style.set(project.style)
        self.layout.set(project.layout)
        self.background.set(project.custom_background)
        self.show()
        self.dirty=True
        self.status("이전 작업 세션 복구 완료")

    def autosave_restore_ui(self):
        latest=load_latest_autosave()
        if not latest:
            return messagebox.showinfo("자동저장 복구","복구할 자동저장 파일이 없습니다.")
        project,path=latest
        answer=messagebox.askyesno(
            "자동저장 복구",
            f"가장 최근 자동저장을 복구할까요?\n\n{path.name}",
        )
        if not answer:
            return
        self.project=project
        self.current=0
        for key,variable in self.vars.items():
            variable.set(project.fields.get(key,""))
        self.style.set(project.style)
        self.layout.set(project.layout)
        self.background.set(project.custom_background)
        self.show()
        self.dirty=True
        self.status(f"자동저장 복구 완료: {path.name}")

    def optimize_images_ui(self):
        if not self.project.images:
            return messagebox.showwarning("사진 필요","상품 사진을 먼저 불러오세요.")
        folder=filedialog.askdirectory()
        if not folder:
            return
        try:
            self.snapshot()
            result=optimize_project_images(self.project,folder,max_side=2400)
        except Exception as error:
            return messagebox.showerror("사진 최적화 오류",str(error))
        self.show()
        total_before=sum(
            item["before"]["estimated_raw_mb"]
            for item in result["results"]
        )
        total_after=sum(
            item["after"]["estimated_raw_mb"]
            for item in result["results"]
        )
        messagebox.showinfo(
            "사진 작업본 최적화 완료",
            f"{result['count']}장 처리\n"
            f"예상 메모리 {total_before:.1f}MB → {total_after:.1f}MB\n\n"
            "원본 파일은 변경하지 않았습니다.",
        )
        self.status("사진 작업본 최적화 완료")

    def cut_manager_ui(self):
        if not self.project.cuts:
            return messagebox.showwarning("초안 필요", "상세페이지 초안을 먼저 생성하세요.")

        dialog = tk.Toplevel(self.root)
        dialog.title("컷 목록 관리")
        dialog.geometry("920x560")
        dialog.transient(self.root)

        tree = ttk.Treeview(
            dialog,
            columns=("stage", "status", "photo", "layout"),
            show="tree headings",
            selectmode="extended",
        )
        tree.heading("#0", text="번호 · 제목")
        tree.heading("stage", text="스토리 단계")
        tree.heading("status", text="검수 상태")
        tree.heading("photo", text="사진")
        tree.heading("layout", text="레이아웃")
        tree.column("#0", width=310)
        tree.column("stage", width=130)
        tree.column("status", width=100)
        tree.column("photo", width=70, anchor="center")
        tree.column("layout", width=130)
        tree.pack(fill="both", expand=True, padx=12, pady=12)

        def selected_indices():
            return sorted(int(item) for item in tree.selection())

        def refresh(select=None):
            tree.delete(*tree.get_children())
            for row in cut_manager_rows(self.project):
                tree.insert(
                    "",
                    "end",
                    iid=str(row["index"]),
                    text=f"{row['number']:02d}. {row['title']}",
                    values=(
                        row["story_stage"],
                        row["review_status"],
                        row["photo_index"] + 1,
                        row["layout_variant"],
                    ),
                )
            for index in select or []:
                if tree.exists(str(index)):
                    tree.selection_add(str(index))
                    tree.see(str(index))

        def jump_to_cut():
            selected = selected_indices()
            if not selected:
                return
            self.current = selected[0]
            self.show()
            self.status(f"{self.current + 1}번 컷으로 이동")
            dialog.destroy()

        def approve_selected():
            indices = selected_indices()
            if not indices:
                return
            self.snapshot()
            count = approve_cuts(self.project, indices)
            refresh(indices)
            self.status(f"선택한 컷 {count}개 승인")

        def revise_selected():
            indices = selected_indices()
            if not indices:
                return
            note = tk.simpledialog.askstring(
                "수정 메모",
                "선택한 컷에 적용할 수정 메모를 입력하세요.",
                parent=dialog,
            )
            self.snapshot()
            count = mark_cuts_for_revision(self.project, indices, note or "")
            refresh(indices)
            self.status(f"선택한 컷 {count}개 수정 필요 처리")

        def duplicate_selected():
            indices = selected_indices()
            if not indices:
                return
            self.snapshot()
            inserted = duplicate_cuts(self.project, indices)
            refresh(inserted)
            self.status(f"선택한 컷 {len(inserted)}개 복제")

        def delete_selected():
            indices = selected_indices()
            if not indices:
                return
            if not messagebox.askyesno(
                "컷 삭제",
                f"선택한 컷 {len(indices)}개를 삭제할까요?",
                parent=dialog,
            ):
                return
            self.snapshot()
            count = delete_cuts(self.project, indices)
            self.current = min(self.current, max(0, len(self.project.cuts) - 1))
            refresh()
            self.show()
            self.status(f"선택한 컷 {count}개 삭제")

        def move_selected(direction):
            indices = selected_indices()
            if not indices:
                return
            self.snapshot()
            moved = move_selected_cuts(self.project, indices, direction)
            refresh(moved)
            self.status("선택한 컷 순서 변경")

        buttons = ttk.Frame(dialog, padding=(12, 0, 12, 12))
        buttons.pack(fill="x")
        ttk.Button(buttons, text="현재 컷으로 이동", command=jump_to_cut).pack(side="left", padx=3)
        ttk.Button(buttons, text="선택 승인", command=approve_selected).pack(side="left", padx=3)
        ttk.Button(buttons, text="수정 필요", command=revise_selected).pack(side="left", padx=3)
        ttk.Button(buttons, text="선택 복제", command=duplicate_selected).pack(side="left", padx=3)
        ttk.Button(buttons, text="선택 삭제", command=delete_selected).pack(side="left", padx=3)
        ttk.Button(buttons, text="위로", command=lambda: move_selected(-1)).pack(side="right", padx=3)
        ttk.Button(buttons, text="아래로", command=lambda: move_selected(1)).pack(side="right", padx=3)

        tree.bind("<Double-1>", lambda event: jump_to_cut())
        refresh([self.current])

    def first_run_wizard(self):
        dialog=tk.Toplevel(self.root)
        dialog.title("농작 AI 처음 시작")
        dialog.geometry("520x420")
        dialog.transient(self.root)
        dialog.grab_set()

        ttk.Label(
            dialog,
            text="농작 AI 첫 실행 설정",
            font=("",16,"bold"),
        ).pack(pady=(20,10))
        ttk.Label(
            dialog,
            text=(
                "사진을 불러오고 한 번에 자동 제작을 실행하면\n"
                "상세페이지 초안이 생성됩니다.\n\n"
                "외부 AI 서버가 없다면 오프라인 모드를 그대로 사용하세요."
            ),
            justify="center",
        ).pack(padx=20,pady=10)

        ai_mode=tk.StringVar(value=self.ai_config.mode)
        ttk.Label(dialog,text="AI 사용 모드").pack(anchor="w",padx=30,pady=(10,4))
        ttk.Combobox(
            dialog,
            textvariable=ai_mode,
            values=["offline","remote"],
            state="readonly",
        ).pack(fill="x",padx=30)

        auto_update=tk.BooleanVar(value=self.update_config.auto_check)
        ttk.Checkbutton(
            dialog,
            text="실행 시 업데이트 정보를 확인",
            variable=auto_update,
        ).pack(anchor="w",padx=30,pady=12)

        def finish():
            self.ai_config.mode=ai_mode.get()
            self.update_config.auto_check=auto_update.get()
            save_ai_config(self.ai_config)
            save_update_config(self.update_config)
            mark_first_run_complete({
                "ai_mode":self.ai_config.mode,
                "auto_update":self.update_config.auto_check,
            })
            dialog.destroy()
            self.status("첫 실행 설정 완료")

        ttk.Button(dialog,text="설정 완료",command=finish).pack(fill="x",padx=30,pady=20)

    def update_check_ui(self):
        dialog=tk.Toplevel(self.root)
        dialog.title("업데이트 확인")
        dialog.geometry("560x400")
        dialog.transient(self.root)

        url=tk.StringVar(value=self.update_config.manifest_url)
        auto=tk.BooleanVar(value=self.update_config.auto_check)
        ttk.Label(dialog,text="업데이트 JSON 주소").pack(anchor="w",padx=16,pady=(16,4))
        ttk.Entry(dialog,textvariable=url).pack(fill="x",padx=16)
        ttk.Checkbutton(
            dialog,
            text="실행 시 자동 확인",
            variable=auto,
        ).pack(anchor="w",padx=16,pady=10)

        result_text=tk.Text(dialog,height=12,wrap="word")
        result_text.pack(fill="both",expand=True,padx=16,pady=8)

        def save_and_check():
            self.update_config.manifest_url=url.get().strip()
            self.update_config.auto_check=auto.get()
            save_update_config(self.update_config)
            try:
                result=check_for_update(self.update_config)
                lines=[
                    f"현재 버전: {result['current_version']}",
                    f"최신 버전: {result['latest_version']}",
                    f"업데이트 가능: {'예' if result['update_available'] else '아니오'}",
                    "",
                    "배포 메모",
                    str(result.get("release_notes","")),
                    "",
                    "다운로드 주소",
                    str(result.get("download_url","")),
                ]
            except Exception as error:
                log_path=log_error(error,"업데이트 확인")
                lines=[str(error),"",f"오류 로그: {log_path}"]
            result_text.delete("1.0","end")
            result_text.insert("1.0","\n".join(lines))

        ttk.Button(dialog,text="저장 후 확인",command=save_and_check).pack(pady=(0,16))

    def support_bundle_ui(self):
        path=filedialog.asksaveasfilename(
            defaultextension=".zip",
            initialfile=f"nongjak_support_v{APP_VERSION}.zip",
            filetypes=[("ZIP 진단 패키지","*.zip")],
        )
        if not path:
            return
        try:
            bundle=create_support_bundle(self.project,path)
        except Exception as error:
            return messagebox.showerror("진단 패키지 오류",str(error))
        messagebox.showinfo(
            "지원 진단 패키지 완료",
            f"설정·시스템 정보·최근 오류 로그를 저장했습니다.\n\n{bundle}",
        )
        self.status("지원 진단 패키지 저장 완료")

    def recover_backup_ui(self):
        try:
            project,path=recover_latest_backup()
        except Exception as error:
            return messagebox.showerror("백업 복구 오류",str(error))
        answer=messagebox.askyesno(
            "최신 백업 복구",
            f"다음 백업을 복구할까요?\n\n{path.name}",
        )
        if not answer:
            return
        self.project=project
        self.current_project_path=str(path)
        for key,variable in self.vars.items():
            variable.set(project.fields.get(key,""))
        self.style.set(project.style)
        self.layout.set(project.layout)
        self.background.set(project.custom_background)
        self.current=0
        self.show()
        self.status(f"백업 복구 완료: {path.name}")

    def channel_export_ui(self):
        if not self.project.cuts:
            return messagebox.showwarning("초안 필요","상세페이지 초안을 먼저 생성하세요.")
        dialog=tk.Toplevel(self.root)
        dialog.title("채널별 저장")
        dialog.transient(self.root)
        dialog.grab_set()
        channel=tk.StringVar(value="스마트스토어")
        approved_only=tk.BooleanVar(value=False)
        ttk.Label(dialog,text="판매 채널").pack(anchor="w",padx=16,pady=(16,4))
        ttk.Combobox(
            dialog,
            textvariable=channel,
            values=list(CHANNEL_PROFILES),
            state="readonly",
            width=30,
        ).pack(fill="x",padx=16)
        ttk.Checkbutton(
            dialog,
            text="승인된 컷만 저장",
            variable=approved_only,
        ).pack(anchor="w",padx=16,pady=10)

        def export():
            folder=filedialog.askdirectory(parent=dialog)
            if not folder:
                return
            try:
                result=export_channel_package(
                    self.project,
                    channel.get(),
                    folder,
                    approved_only.get(),
                )
            except Exception as error:
                log_path=log_error(error,"채널별 저장")
                return messagebox.showerror(
                    "채널 저장 오류",
                    f"{error}\n\n오류 로그: {log_path}",
                    parent=dialog,
                )
            dialog.destroy()
            messagebox.showinfo(
                "채널별 저장 완료",
                f"{result['channel']}용 상세이미지 {result['detail_count']}장과 대표이미지를 저장했습니다.",
            )
            self.status(f"{result['channel']} 채널 패키지 저장 완료")

        ttk.Button(dialog,text="저장 폴더 선택",command=export).pack(fill="x",padx=16,pady=(0,16))

    def settings_backup_ui(self):
        action=messagebox.askyesnocancel(
            "설정 백업",
            "예: 설정 백업 저장\n아니오: 설정 백업 불러오기\n취소: 닫기",
        )
        if action is None:
            return
        if action:
            path=filedialog.asksaveasfilename(
                defaultextension=".json",
                initialfile=SETTINGS_BACKUP_NAME,
                filetypes=[("JSON 설정 백업","*.json")],
            )
            if path:
                export_settings_backup(path)
                self.status("설정 백업 저장 완료")
        else:
            path=filedialog.askopenfilename(filetypes=[("JSON 설정 백업","*.json")])
            if path:
                import_settings_backup(path)
                self.ai_config=load_ai_config()
                self.status("설정 백업 불러오기 완료")

    def system_health_ui(self):
        report=system_health_report(self.project)
        lines=[
            f"농작 AI 버전: {report['app_version']}",
            f"시스템 점수: {report['score']}점",
            "",
            "환경 점검",
        ]
        lines.extend(
            f"- {key}: {'정상' if value else '확인 필요'}"
            for key,value in report["checks"].items()
        )
        if report["project_validation"]:
            lines.extend(["","현재 프로젝트 점검"])
            lines.extend(
                f"[{item['level']}] {item['message']}"
                for item in report["project_validation"]
            )
        messagebox.showinfo("시스템 진단","\n".join(lines))
        self.status("시스템 진단 완료")

    def save_review_ui(self):
        if not self.project.cuts:
            return
        cut=self.project.cuts[self.current]
        history_path=revision_history_path(self.current_project_path)
        snapshot_cut_revision(
            self.project,
            self.current,
            history_path,
            reason="검수 상태 변경 전 자동저장",
            author="시스템",
        )
        set_cut_review(
            cut,
            self.review_status.get(),
            self.review_note.get("1.0","end").strip(),
        )
        snapshot_cut_revision(
            self.project,
            self.current,
            history_path,
            reason=f"검수 상태 저장: {cut.review_status}",
            author="사용자",
        )
        self.approved.set(cut.approved)
        self.show()
        self.status(f"{self.current+1}번 컷 검수 상태 저장: {cut.review_status}")

    def next_unapproved_ui(self):
        index=next_review_cut(self.project,self.current)
        if index is None:
            return messagebox.showinfo("검수 완료","모든 컷이 승인되었습니다.")
        self.current=index
        self.show()
        self.status(f"{self.current+1}번 미승인 컷으로 이동")






    def v63_ad_banner_ui(self):
        if not self.project.images:
            return messagebox.showwarning(
                "사진 필요",
                "상품 사진을 먼저 불러오세요.",
            )

        dialog=tk.Toplevel(self.root)
        dialog.title("v6.3.1 AI 광고 배너 제작")
        dialog.geometry("780x610")
        dialog.transient(self.root)

        size_var=tk.StringVar(value="스마트스토어 가로배너")
        top=ttk.Frame(dialog,padding=12)
        top.pack(fill="x")
        ttk.Label(top,text="광고 규격").pack(side="left")
        ttk.Combobox(
            top,
            textvariable=size_var,
            values=list(AD_BANNER_SIZES),
            state="readonly",
            width=25,
        ).pack(side="left",padx=8)

        text=tk.Text(dialog,wrap="word")
        text.pack(fill="both",expand=True,padx=12,pady=(0,12))
        current={}

        def generate():
            nonlocal current
            folder=filedialog.askdirectory(
                parent=dialog,
                title="광고 배너 저장 폴더",
            )
            if not folder:return
            product=sanitize_name(
                self.project.fields.get("product","") or "상품"
            )
            output=Path(folder)/f"{product}_광고배너"
            try:
                current=generate_ad_banner_set(
                    self.project,
                    output,
                    size_var.get(),
                )
            except Exception as error:
                return messagebox.showerror(
                    "광고 배너 생성 오류",
                    str(error),
                    parent=dialog,
                )

            lines=[
                f"상품: {current['product']}",
                f"규격: {current['size_name']} {current['size']}",
                f"대표사진: {Path(current['source_image']['path']).name}",
                "",
                "생성 광고",
            ]
            lines.extend(
                f"- {item['campaign_type']}: "
                f"{item['quality']['score']}점 / "
                f"{item['copy']['headline']}"
                for item in current["outputs"]
            )
            lines.extend([
                "",
                f"최고 점수: {current['best_banner']['campaign_type']} "
                f"{current['best_banner']['quality']['score']}점",
                f"저장 폴더: {output}",
                "",
                "원본 상품사진은 변경하지 않았습니다.",
            ])
            text.config(state="normal")
            text.delete("1.0","end")
            text.insert("1.0","\n".join(lines))
            text.config(state="disabled")
            self.status("v6.3.1 광고 배너 4종 생성 완료")

        def comparison():
            if not current:
                return messagebox.showinfo(
                    "생성 필요",
                    "광고 배너를 먼저 생성하세요.",
                    parent=dialog,
                )
            path=filedialog.asksaveasfilename(
                parent=dialog,
                defaultextension=".png",
                initialfile="광고배너_4종_비교.png",
                filetypes=[("PNG 이미지","*.png")],
            )
            if path:
                build_ad_banner_contact_sheet(current,path)
                messagebox.showinfo("비교 이미지 완료",path,parent=dialog)

        buttons=ttk.Frame(dialog,padding=(12,0,12,12))
        buttons.pack(fill="x")
        ttk.Button(
            buttons,
            text="광고 배너 4종 생성",
            command=generate,
        ).pack(side="left",padx=3)
        ttk.Button(
            buttons,
            text="4종 비교 이미지",
            command=comparison,
        ).pack(side="right",padx=3)

        lines=[
            "생성 유형",
            "- 신상품",
            "- 베스트상품",
            "- 특가행사",
            "- 산지직송",
            "",
            "지원 규격",
        ]
        lines.extend(f"- {name}: {size}" for name,size in AD_BANNER_SIZES.items())
        text.insert("1.0","\n".join(lines))
        text.config(state="disabled")

    def v62_thumbnail_ui(self):
        if not self.project.images:
            return messagebox.showwarning(
                "사진 필요",
                "상품 사진을 먼저 불러오세요.",
            )

        dialog=tk.Toplevel(self.root)
        dialog.title("v6.3.1 AI 썸네일 제작")
        dialog.geometry("760x590")
        dialog.transient(self.root)

        channel=tk.StringVar(value="스마트스토어")
        top=ttk.Frame(dialog,padding=12)
        top.pack(fill="x")
        ttk.Label(top,text="판매 채널").pack(side="left")
        ttk.Combobox(
            top,
            textvariable=channel,
            values=list(THUMBNAIL_CHANNEL_RULES),
            state="readonly",
            width=20,
        ).pack(side="left",padx=8)

        text=tk.Text(dialog,wrap="word")
        text.pack(fill="both",expand=True,padx=12,pady=(0,12))
        current={}

        def generate():
            nonlocal current
            folder=filedialog.askdirectory(
                parent=dialog,
                title="썸네일 저장 폴더",
            )
            if not folder:return
            product=sanitize_name(
                self.project.fields.get("product","") or "상품"
            )
            output=Path(folder)/f"{product}_썸네일"
            try:
                current=generate_thumbnail_set(
                    self.project,
                    output,
                    channel.get(),
                )
            except Exception as error:
                return messagebox.showerror(
                    "썸네일 생성 오류",
                    str(error),
                    parent=dialog,
                )

            lines=[
                f"상품: {current['product']}",
                f"채널: {current['channel']}",
                f"대표사진: {Path(current['source_image']['path']).name}",
                f"선택 이유: {current['source_image']['reason']}",
                "",
                "생성 결과",
            ]
            lines.extend(
                f"- {item['variant']}: {item['quality']['score']}점 / "
                f"{item['headline']}"
                for item in current["outputs"]
            )
            lines.extend([
                "",
                f"최고 점수: {current['best_variant']['variant']} "
                f"{current['best_variant']['quality']['score']}점",
                f"저장 폴더: {output}",
                "",
                "원본 상품사진 파일은 변경하지 않았습니다.",
            ])
            text.config(state="normal")
            text.delete("1.0","end")
            text.insert("1.0","\n".join(lines))
            text.config(state="disabled")
            self.status("v6.3.1 썸네일 3종 생성 완료")

        def contact_sheet():
            if not current:
                return messagebox.showinfo(
                    "생성 필요",
                    "먼저 썸네일 3종을 생성하세요.",
                    parent=dialog,
                )
            path=filedialog.asksaveasfilename(
                parent=dialog,
                defaultextension=".png",
                initialfile="썸네일_3종_비교.png",
                filetypes=[("PNG 이미지","*.png")],
            )
            if path:
                build_thumbnail_contact_sheet(current,path)
                messagebox.showinfo(
                    "비교 이미지 완료",
                    path,
                    parent=dialog,
                )

        def open_best():
            if not current:
                return messagebox.showinfo(
                    "생성 필요",
                    "먼저 썸네일을 생성하세요.",
                    parent=dialog,
                )
            path=Path(current["best_variant"]["path"])
            try:
                import webbrowser
                webbrowser.open(path.resolve().as_uri())
            except Exception:
                messagebox.showinfo(
                    "최고 점수 썸네일",
                    str(path),
                    parent=dialog,
                )

        buttons=ttk.Frame(dialog,padding=(12,0,12,12))
        buttons.pack(fill="x")
        ttk.Button(
            buttons,
            text="썸네일 3종 생성",
            command=generate,
        ).pack(side="left",padx=3)
        ttk.Button(
            buttons,
            text="3종 비교 이미지",
            command=contact_sheet,
        ).pack(side="right",padx=3)
        ttk.Button(
            buttons,
            text="최고 점수 썸네일 열기",
            command=open_best,
        ).pack(side="right",padx=3)

        preview=select_thumbnail_source_image(self.project)
        candidates=thumbnail_text_candidates(self.project)
        lines=[
            f"추천 대표사진: {Path(preview['path']).name}",
            f"선택 이유: {preview['reason']}",
            "",
            "예상 문구 후보",
        ]
        lines.extend(
            f"- {item['headline']} / {item['subcopy']}"
            for item in candidates[:5]
        )
        text.insert("1.0","\n".join(lines))
        text.config(state="disabled")

    def v61_design_quality_ui(self):
        if not self.project.cuts:
            return messagebox.showwarning(
                "초안 필요",
                "상세페이지 초안을 먼저 생성하세요.",
            )

        dialog=tk.Toplevel(self.root)
        dialog.title("v6.1 AI 디자인 품질 엔진")
        dialog.geometry("950x700")
        dialog.transient(self.root)

        text=tk.Text(dialog,wrap="word")
        text.pack(fill="both",expand=True,padx=12,pady=12)
        current={}

        def analyze():
            nonlocal current
            current=project_design_quality(self.project)
            lines=[
                f"상품: {self.project.fields.get('product','')}",
                f"디자인 품질: {current['score']}점 / {current['grade']}등급",
                f"현재 스타일: {self.project.style}",
                f"추천 스타일: {current['recommended_style']}",
                f"추천 배경색: {current['recommended_background']}",
                f"레이아웃 사용: {current['layout_counts']}",
                "",
                "전체 개선사항",
            ]
            lines.extend(
                f"- {item}" for item in current["global_issues"]
            )
            if not current["global_issues"]:
                lines.append("- 전체 디자인 구조가 안정적입니다.")

            lines.extend(["","우선 수정 컷"])
            for item in current["priority_cuts"][:10]:
                lines.append(
                    f"{item['cut_number']}컷 · {item['score']}점 · "
                    f"{item['title']}"
                )
                lines.extend(
                    f"  - {issue}" for issue in item["issues"]
                )
            if not current["priority_cuts"]:
                lines.append("- 85점 미만 컷이 없습니다.")

            lines.extend(["","전체 컷 점수"])
            lines.extend(
                f"- {item['cut_number']}컷 [{item['stage']}] "
                f"{item['score']}점 / {item['grade']}"
                for item in current["cuts"]
            )
            text.config(state="normal")
            text.delete("1.0","end")
            text.insert("1.0","\n".join(lines))
            text.config(state="disabled")
            self.status("v6.1 디자인 품질 분석 완료")

        def optimize(all_cuts=True):
            self.snapshot()
            result=auto_optimize_project_design(
                self.project,
                apply_style=True,
                apply_background=True,
                only_problem_cuts=not all_cuts,
            )
            self.style.set(self.project.style)
            self.layout.set(self.project.layout)
            self.show()
            messagebox.showinfo(
                "디자인 자동 보정 완료",
                f"보정 전 {result['before']['score']}점\n"
                f"보정 후 {result['after']['score']}점\n"
                f"점수 변화 {result['score_improvement']:+d}점\n"
                f"수정 컷 {result['changed_cut_count']}개",
                parent=dialog,
            )
            analyze()

        def contact_sheet():
            if not self.project.images:
                return messagebox.showwarning(
                    "사진 필요",
                    "연락시트를 만들 상품 사진이 없습니다.",
                    parent=dialog,
                )
            path=filedialog.asksaveasfilename(
                parent=dialog,
                defaultextension=".png",
                initialfile="상세페이지_전체미리보기.png",
                filetypes=[("PNG 이미지","*.png")],
            )
            if path:
                try:
                    build_design_contact_sheet(self.project,path)
                except Exception as error:
                    return messagebox.showerror(
                        "미리보기 생성 오류",
                        str(error),
                        parent=dialog,
                    )
                messagebox.showinfo(
                    "전체 미리보기 완료",
                    path,
                    parent=dialog,
                )

        def save_report():
            path=filedialog.asksaveasfilename(
                parent=dialog,
                defaultextension=".json",
                initialfile="v6_1_디자인품질보고서.json",
                filetypes=[("JSON 보고서","*.json")],
            )
            if path:
                export_design_quality_report(
                    self.project,
                    path,
                )
                self.status("v6.1 디자인 품질 보고서 저장 완료")

        buttons=ttk.Frame(dialog,padding=(12,0,12,12))
        buttons.pack(fill="x")
        ttk.Button(
            buttons,
            text="다시 분석",
            command=analyze,
        ).pack(side="left",padx=3)
        ttk.Button(
            buttons,
            text="문제 컷만 자동 보정",
            command=lambda:optimize(False),
        ).pack(side="left",padx=3)
        ttk.Button(
            buttons,
            text="전체 디자인 자동 보정",
            command=lambda:optimize(True),
        ).pack(side="left",padx=3)
        ttk.Button(
            buttons,
            text="전체 미리보기 PNG",
            command=contact_sheet,
        ).pack(side="right",padx=3)
        ttk.Button(
            buttons,
            text="보고서 저장",
            command=save_report,
        ).pack(side="right",padx=3)
        analyze()

    def v60_product_intelligence_ui(self):
        if not self.project.images:
            return messagebox.showwarning(
                "사진 필요",
                "상품 사진을 먼저 불러오세요.",
            )

        dialog=tk.Toplevel(self.root)
        dialog.title("v6.0 AI 상품기획 엔진")
        dialog.geometry("980x720")
        dialog.transient(self.root)

        top=ttk.Frame(dialog,padding=12)
        top.pack(fill="x")
        style_var=tk.StringVar(value="프리미엄형")
        ttk.Label(top,text="카피 스타일").pack(side="left")
        ttk.Combobox(
            top,
            textvariable=style_var,
            values=list(COPY_STYLE_PROFILES),
            state="readonly",
            width=20,
        ).pack(side="left",padx=8)

        text=tk.Text(dialog,wrap="word")
        text.pack(fill="both",expand=True,padx=12,pady=(0,12))
        current={}

        def analyze():
            nonlocal current
            self.project.fields=self.fields()
            self.status("v6.0 AI가 상품기획안을 만드는 중...")
            self.root.update_idletasks()
            try:
                current=build_product_intelligence(
                    self.project.images,
                    self.project.fields,
                    self.count.get(),
                )
            except Exception as error:
                return messagebox.showerror(
                    "상품기획 오류",
                    str(error),
                    parent=dialog,
                )

            score=current["score"]
            lines=[
                f"상품: {current['fields'].get('product','')}",
                f"품목: {current['fields'].get('category','')}",
                f"상품기획 점수: {score['score']}점 / {score['grade']}등급",
                "",
                "추천 상품명 TOP 10",
            ]
            lines.extend(
                f"{index+1}. {item['title']} ({item['score']}점)"
                for index,item in enumerate(current["product_titles"][:10])
            )
            lines.extend(["","검색 키워드"])
            lines.extend(
                f"- {item}"
                for item in current["keyword_plan"]["primary_keywords"]
            )
            lines.extend(["","고객이 궁금해하는 내용"])
            lines.extend(
                f"- {item}"
                for item in current["customer_psychology"]["customer_questions"]
            )
            lines.extend(["","구매 전 보완할 정보"])
            lines.extend(
                f"- {item}"
                for item in current["customer_psychology"]["missing_answers"]
            )
            if not current["customer_psychology"]["missing_answers"]:
                lines.append("- 주요 정보가 입력되어 있습니다.")
            lines.extend(["","상세페이지 기획"])
            lines.extend(
                f"{item['cut_number']}컷 [{item['stage']}] {item['title']}\n"
                f"  목적: {item['objective']}"
                for item in current["page_plan"]
            )
            lines.extend(["","현재 보완사항"])
            lines.extend(f"- {item}" for item in score["issues"])
            if not score["issues"]:
                lines.append("- 큰 보완사항 없음")

            text.config(state="normal")
            text.delete("1.0","end")
            text.insert("1.0","\n".join(lines))
            text.config(state="disabled")
            self.status("v6.0 AI 상품기획 완료")

        def apply_plan():
            if not current:
                analyze()
            if not current:return
            self.snapshot()
            self.project=project_from_product_intelligence(
                current,
                self.project.images,
                style_var.get(),
            )
            self.current=0
            self.current_project_path=None
            for key,var in self.vars.items():
                var.set(self.project.fields.get(key,""))
            self.style.set(self.project.style)
            self.layout.set(self.project.layout)
            self.count.set(len(self.project.cuts))
            self.show()
            self.dirty=True
            dialog.destroy()
            messagebox.showinfo(
                "v6.0 기획안 적용 완료",
                f"{style_var.get()} 문구와 "
                f"{len(self.project.cuts)}컷 구성을 적용했습니다.\n\n"
                "첫 컷부터 한 장씩 검수해 주세요.",
            )
            self.status("v6.0 상품기획안을 프로젝트에 적용했습니다.")

        def save_report():
            if not current:
                analyze()
            if not current:return
            path=filedialog.asksaveasfilename(
                parent=dialog,
                defaultextension=".json",
                initialfile="v6_0_AI_상품기획보고서.json",
                filetypes=[("JSON 기획보고서","*.json")],
            )
            if path:
                export_product_intelligence_report(current,path)
                self.status("v6.0 상품기획 보고서 저장 완료")

        buttons=ttk.Frame(dialog,padding=(12,0,12,12))
        buttons.pack(fill="x")
        ttk.Button(buttons,text="기획 다시 분석",command=analyze).pack(side="left",padx=3)
        ttk.Button(buttons,text="보고서 저장",command=save_report).pack(side="right",padx=3)
        ttk.Button(buttons,text="기획안 프로젝트 적용",command=apply_plan).pack(side="right",padx=3)
        analyze()

    def v59_revision_approval_ui(self):
        if not self.project.cuts:
            return messagebox.showwarning(
                "초안 필요",
                "상세페이지 초안을 먼저 생성하세요.",
            )

        history_path=revision_history_path(
            self.current_project_path
        )
        dialog=tk.Toplevel(self.root)
        dialog.title("v5.9 컷 버전·최종승인")
        dialog.geometry("980x700")
        dialog.transient(self.root)

        tree=ttk.Treeview(
            dialog,
            columns=(
                "status",
                "revisions",
                "changed",
                "latest",
            ),
            show="tree headings",
            selectmode="browse",
        )
        tree.heading("#0",text="컷")
        tree.heading("status",text="검수 상태")
        tree.heading("revisions",text="버전 수")
        tree.heading("changed",text="최근 저장 후 변경")
        tree.heading("latest",text="최근 버전 시각")
        tree.column("#0",width=230)
        tree.column("status",width=100,anchor="center")
        tree.column("revisions",width=80,anchor="center")
        tree.column("changed",width=130,anchor="center")
        tree.column("latest",width=190)
        tree.pack(fill="both",expand=True,padx=12,pady=12)

        detail=tk.Text(dialog,height=12,wrap="word")
        detail.pack(fill="x",padx=12,pady=(0,12))

        def refresh():
            tree.delete(*tree.get_children())
            summary=revision_history_summary(
                self.project,
                history_path,
            )
            for index,item in enumerate(summary["cuts"]):
                tree.insert(
                    "",
                    "end",
                    iid=str(index),
                    text=f"{item['cut_number']}컷 · {item['title']}",
                    values=(
                        item["review_status"],
                        item["revision_count"],
                        "예" if item["changed_after_latest"] else "아니오",
                        item["latest_at"],
                    ),
                )
            if self.project.cuts:
                selected=min(
                    self.current,
                    len(self.project.cuts)-1,
                )
                tree.selection_set(str(selected))
                show_detail()

        def selected_index():
            selected=tree.selection()
            return int(selected[0]) if selected else None

        def show_detail(event=None):
            index=selected_index()
            detail.config(state="normal")
            detail.delete("1.0","end")
            if index is None:
                detail.insert("1.0","컷을 선택하세요.")
                detail.config(state="disabled")
                return
            revisions=list_cut_revisions(
                history_path,
                index,
            )
            cut=self.project.cuts[index]
            lines=[
                f"{index+1}컷 · {cut.title}",
                f"현재 검수 상태: {cut.review_status}",
                f"현재 메모: {cut.review_note or '-'}",
                f"저장된 버전: {len(revisions)}개",
                "",
            ]
            lines.extend(
                f"v{item['revision_number']} · "
                f"{item['created_at']} · "
                f"{item['reason']} · "
                f"{item['author']}"
                for item in reversed(revisions[-10:])
            )
            if not revisions:
                lines.append("저장된 버전이 없습니다.")
            detail.insert("1.0","\n".join(lines))
            detail.config(state="disabled")

        def snapshot_current():
            index=selected_index()
            if index is None:return
            reason=simpledialog.askstring(
                "현재 컷 버전 저장",
                "버전 저장 이유를 입력하세요.",
                initialvalue="수정본 저장",
                parent=dialog,
            )
            if reason is None:return
            result=snapshot_cut_revision(
                self.project,
                index,
                history_path,
                reason=reason,
                author="사용자",
                force=True,
            )
            messagebox.showinfo(
                "컷 버전 저장 완료",
                f"{index+1}컷 v{result['revision']['revision_number']}로 저장했습니다.",
                parent=dialog,
            )
            refresh()

        def snapshot_all():
            result=snapshot_all_cut_revisions(
                self.project,
                history_path,
                reason="전체 컷 버전 저장",
                author="사용자",
            )
            messagebox.showinfo(
                "전체 버전 저장 완료",
                f"새로 저장 {result['created_count']}개\n"
                f"변경 없음 {result['skipped_count']}개",
                parent=dialog,
            )
            refresh()

        def restore_revision_ui():
            index=selected_index()
            if index is None:return
            revisions=list_cut_revisions(
                history_path,
                index,
            )
            if not revisions:
                return messagebox.showinfo(
                    "복원 불가",
                    "저장된 버전이 없습니다.",
                    parent=dialog,
                )
            revision_number=simpledialog.askinteger(
                "컷 버전 복원",
                f"복원할 버전 번호를 입력하세요.\n"
                f"사용 가능: 1~{len(revisions)}",
                minvalue=1,
                maxvalue=len(revisions),
                parent=dialog,
            )
            if revision_number is None:return
            selected=revisions[revision_number-1]
            comparison=compare_current_cut_to_revision(
                self.project,
                index,
                selected,
            )
            if not messagebox.askyesno(
                "컷 버전 복원",
                f"현재 컷과 다른 항목이 "
                f"{comparison['difference_count']}개 있습니다.\n"
                f"복원 전 현재 버전도 자동 저장됩니다.\n\n"
                f"v{revision_number}로 복원할까요?",
                parent=dialog,
            ):return
            self.snapshot()
            restore_cut_revision(
                self.project,
                index,
                revision_number,
                history_path,
                snapshot_before_restore=True,
            )
            self.current=index
            self.show()
            refresh()
            self.status(
                f"{index+1}컷 v{revision_number} 복원 완료"
            )

        def compare_revision_ui():
            index=selected_index()
            if index is None:return
            revisions=list_cut_revisions(
                history_path,
                index,
            )
            if not revisions:
                return messagebox.showinfo(
                    "비교 불가",
                    "저장된 버전이 없습니다.",
                    parent=dialog,
                )
            revision_number=simpledialog.askinteger(
                "현재 컷과 버전 비교",
                f"비교할 버전 번호: 1~{len(revisions)}",
                minvalue=1,
                maxvalue=len(revisions),
                parent=dialog,
            )
            if revision_number is None:return
            comparison=compare_current_cut_to_revision(
                self.project,
                index,
                revisions[revision_number-1],
            )
            lines=[
                f"다른 항목: {comparison['difference_count']}개",
                "",
            ]
            lines.extend(
                f"- {item['field']}\n"
                f"  이전: {item['before']}\n"
                f"  현재: {item['after']}"
                for item in comparison["differences"]
            )
            if not comparison["differences"]:
                lines.append("- 현재 컷과 동일합니다.")
            messagebox.showinfo(
                "버전 비교 결과",
                "\n".join(lines[:35]),
                parent=dialog,
            )

        def final_gate_ui():
            gate=final_approval_gate(self.project)
            lines=[
                f"최종 승인 가능: {'예' if gate['ready'] else '아니오'}",
                f"전체 컷: {gate['review']['total']}",
                f"승인: {gate['review']['counts']['승인']}",
                f"수정 필요: {gate['review']['counts']['수정 필요']}",
                f"검수 전: {gate['review']['counts']['검수 전']}",
                "",
                "차단 항목",
            ]
            lines.extend(
                f"- {item}"
                for item in gate["blockers"]
            )
            if not gate["blockers"]:
                lines.append("- 없음")
            lines.extend(["","주의사항"])
            lines.extend(
                f"- {item}"
                for item in gate["warnings"]
            )
            if not gate["warnings"]:
                lines.append("- 없음")
            messagebox.showinfo(
                "최종 승인 조건 점검",
                "\n".join(lines),
                parent=dialog,
            )

        def export_final_ui():
            gate=final_approval_gate(self.project)
            if not gate["ready"]:
                return messagebox.showerror(
                    "최종본 저장 불가",
                    "\n".join(gate["blockers"]),
                    parent=dialog,
                )
            approver=simpledialog.askstring(
                "최종 승인자",
                "최종 승인자 이름을 입력하세요.",
                initialvalue="사용자",
                parent=dialog,
            )
            if not approver:return
            note=simpledialog.askstring(
                "최종 승인 메모",
                "최종 승인 메모를 입력하세요.",
                initialvalue="모든 컷 검수 완료",
                parent=dialog,
            ) or ""
            folder=filedialog.askdirectory(
                parent=dialog,
                title="최종 승인본 저장 폴더",
            )
            if not folder:return
            try:
                result=export_final_release_package(
                    self.project,
                    folder,
                    approver=approver,
                    approval_note=note,
                    history_path=history_path,
                )
            except Exception as error:
                return messagebox.showerror(
                    "최종 승인본 저장 오류",
                    str(error),
                    parent=dialog,
                )
            messagebox.showinfo(
                "최종 승인본 저장 완료",
                f"승인자: {approver}\n\n"
                f"{result['zip']}",
                parent=dialog,
            )
            self.status("v5.9 최종 승인본 저장 완료")

        def export_history_ui():
            path=filedialog.asksaveasfilename(
                parent=dialog,
                defaultextension=".json",
                initialfile="컷_버전이력_보고서.json",
                filetypes=[("JSON 보고서","*.json")],
            )
            if path:
                export_revision_report(
                    self.project,
                    history_path,
                    path,
                )
                self.status("컷 버전이력 보고서 저장 완료")

        tree.bind(
            "<<TreeviewSelect>>",
            show_detail,
        )

        row1=ttk.Frame(dialog,padding=(12,0,12,6))
        row1.pack(fill="x")
        ttk.Button(
            row1,
            text="현재 컷 버전 저장",
            command=snapshot_current,
        ).pack(side="left",padx=3)
        ttk.Button(
            row1,
            text="전체 컷 버전 저장",
            command=snapshot_all,
        ).pack(side="left",padx=3)
        ttk.Button(
            row1,
            text="이전 버전과 비교",
            command=compare_revision_ui,
        ).pack(side="left",padx=3)
        ttk.Button(
            row1,
            text="선택 버전 복원",
            command=restore_revision_ui,
        ).pack(side="left",padx=3)

        row2=ttk.Frame(dialog,padding=(12,0,12,12))
        row2.pack(fill="x")
        ttk.Button(
            row2,
            text="버전이력 보고서",
            command=export_history_ui,
        ).pack(side="left",padx=3)
        ttk.Button(
            row2,
            text="최종 승인 조건 점검",
            command=final_gate_ui,
        ).pack(side="right",padx=3)
        ttk.Button(
            row2,
            text="최종 승인본 저장",
            command=export_final_ui,
        ).pack(side="right",padx=3)

        refresh()

    def review_dashboard_ui(self):
        if not self.project.cuts:
            return messagebox.showwarning("초안 필요","상세페이지 초안을 먼저 생성하세요.")
        summary=review_summary(self.project)
        lines=[
            f"전체 컷: {summary['total']}",
            f"승인 진행률: {summary['approved_progress']}%",
            "",
            f"검수 전: {summary['counts']['검수 전']}",
            f"수정 필요: {summary['counts']['수정 필요']}",
            f"승인: {summary['counts']['승인']}",
            "",
            "검수 메모",
        ]
        if summary["notes"]:
            lines.extend(
                f"{item['cut']}컷 [{item['status']}] {item['note']}"
                for item in summary["notes"]
            )
        else:
            lines.append("- 등록된 메모 없음")

        dialog=tk.Toplevel(self.root)
        dialog.title("검수 현황")
        dialog.geometry("620x500")
        text=tk.Text(dialog,wrap="word")
        text.pack(fill="both",expand=True,padx=12,pady=12)
        text.insert("1.0","\n".join(lines))
        text.config(state="disabled")

        def save_report():
            path=filedialog.asksaveasfilename(
                parent=dialog,
                defaultextension=".json",
                filetypes=[("JSON 보고서","*.json")],
            )
            if path:
                export_review_report(self.project,path)
                self.status("검수 보고서 저장 완료")

        ttk.Button(dialog,text="검수 보고서 저장",command=save_report).pack(pady=(0,12))

    def export_approved_ui(self):
        if not self.project.cuts:
            return messagebox.showwarning("초안 필요","상세페이지 초안을 먼저 생성하세요.")
        folder=filedialog.askdirectory()
        if not folder:
            return
        try:
            result=export_approved_only(self.project,folder)
        except Exception as error:
            return messagebox.showerror("승인본 저장 오류",str(error))
        messagebox.showinfo(
            "승인본 저장 완료",
            f"승인된 컷 {result['approved_count']}장을 PNG와 PDF로 저장했습니다.",
        )
        self.status("승인본 저장 완료")





    def v55_preference_safety_ui(self):
        dialog=tk.Toplevel(self.root)
        dialog.title("v5.5 학습 안전관리")
        dialog.geometry("760x620")
        dialog.transient(self.root)

        text=tk.Text(dialog,wrap="word")
        text.pack(fill="both",expand=True,padx=12,pady=12)

        def refresh():
            profile=load_preference_profile()
            health=preference_profile_health(profile)
            comparison=preference_profile_comparison(self.project,profile)
            snapshots=list_preference_snapshots()
            lines=[
                f"전체 학습 표본: {health['sample_count']}개",
                f"사용 가능한 표본: {health['usable_count']}개",
                f"품질 낮은 표본: {health['weak_count']}개",
                f"평균 표본 품질: {health['average_quality']}점",
                f"프로필 상태: {'정상' if health['healthy'] else '확인 필요'}",
                "",
                "품목별 학습 현황",
            ]
            if health["categories"]:
                lines.extend(
                    f"- {category}: {count}개"
                    for category,count in sorted(health["categories"].items())
                )
            else:
                lines.append("- 학습 전")

            lines.extend([
                "",
                f"현재 품목: {comparison['category']}",
                f"추천 기준: {comparison['recommended_source']}",
                f"품목별 추천 스타일: {comparison['category_profile'].get('style','-')}",
                f"품목별 추천 레이아웃: {comparison['category_profile'].get('layout','-')}",
                "",
                f"전체 프로필과 품목별 프로필 차이: {len(comparison['differences'])}개",
            ])
            lines.extend(
                f"- {item['item']}: 전체 {item['global']} / 품목별 {item['category']}"
                for item in comparison["differences"]
            )
            lines.extend(["", f"저장된 복구 스냅샷: {len(snapshots)}개"])
            lines.extend(
                f"- {item['name']} / 표본 {item['sample_count']}개"
                for item in snapshots[:8]
            )

            text.config(state="normal")
            text.delete("1.0","end")
            text.insert("1.0","\n".join(lines))
            text.config(state="disabled")

        def snapshot_now():
            label=simpledialog.askstring(
                "프로필 스냅샷",
                "스냅샷 설명을 입력하세요.",
                initialvalue="수동백업",
                parent=dialog,
            )
            if label is None:
                return
            path=create_preference_snapshot(label=label)
            messagebox.showinfo("스냅샷 완료",f"취향 프로필을 백업했습니다.\n\n{path}",parent=dialog)
            refresh()

        def undo_latest():
            if not messagebox.askyesno(
                "최근 학습 취소",
                "가장 최근에 학습한 프로젝트 표본을 삭제할까요?",
                parent=dialog,
            ):
                return
            result=remove_latest_preference_sample()
            if not result["removed"]:
                return messagebox.showinfo("최근 학습 취소",result["reason"],parent=dialog)
            messagebox.showinfo(
                "최근 학습 취소 완료",
                f"{result['removed_sample'].get('source_name','프로젝트')} 표본을 삭제했습니다.",
                parent=dialog,
            )
            refresh()

        def restore_snapshot_ui():
            snapshots=list_preference_snapshots()
            if not snapshots:
                return messagebox.showinfo("스냅샷 복원","복원할 스냅샷이 없습니다.",parent=dialog)
            path=filedialog.askopenfilename(
                parent=dialog,
                title="취향 프로필 스냅샷 선택",
                initialdir=str(PREFERENCE_SNAPSHOT_DIR),
                filetypes=[("JSON 스냅샷","*.json")],
            )
            if not path:
                return
            try:
                result=restore_preference_snapshot(path)
            except Exception as error:
                return messagebox.showerror("스냅샷 복원 오류",str(error),parent=dialog)
            messagebox.showinfo(
                "스냅샷 복원 완료",
                f"선택한 프로필로 복원했습니다.\n"
                f"복원 전 프로필도 자동 백업했습니다.\n\n{result['backup_before_restore']}",
                parent=dialog,
            )
            refresh()

        def apply_category_profile():
            profile=load_preference_profile()
            recommendation=recommend_category_preference(self.project,profile)
            if not recommendation.get("available"):
                return messagebox.showinfo("적용 불가","학습된 품목별 취향이 없습니다.",parent=dialog)
            temporary={"summary":{
                "sample_count":recommendation.get("sample_count",0),
                "preferred_style":recommendation["style"],
                "preferred_layout":recommendation["layout"],
                "preferred_cut_count":recommendation["cut_count"],
                "preferred_title_size":recommendation["title_size"],
                "preferred_body_size":recommendation["body_size"],
                "preferred_text_align":recommendation["text_align"],
                "preferred_layout_variant":recommendation["layout_variant"],
                "preferred_image_scale":recommendation["image_scale"],
                "preferred_body_length":recommendation["body_length_target"],
                "brandless_ratio":1.0 if recommendation["brandless_preferred"] else 0.0,
                "common_shipping":recommendation["shipping"],
            }}
            self.snapshot()
            result=apply_preference_profile(self.project,temporary)
            self.style.set(self.project.style)
            self.layout.set(self.project.layout)
            self.show()
            messagebox.showinfo(
                "품목별 취향 적용",
                f"{recommendation['source']} 기준으로 적용했습니다.\n"
                f"적용 항목: {', '.join(result.get('changes',[]))}",
                parent=dialog,
            )
            refresh()

        buttons=ttk.Frame(dialog,padding=(12,0,12,12))
        buttons.pack(fill="x")
        ttk.Button(buttons,text="지금 스냅샷",command=snapshot_now).pack(side="left",padx=3)
        ttk.Button(buttons,text="최근 학습 취소",command=undo_latest).pack(side="left",padx=3)
        ttk.Button(buttons,text="스냅샷 복원",command=restore_snapshot_ui).pack(side="left",padx=3)
        ttk.Button(buttons,text="품목별 취향 적용",command=apply_category_profile).pack(side="right",padx=3)
        refresh()

    def v54_preference_ui(self):
        dialog=tk.Toplevel(self.root)
        dialog.title("v5.4 작업취향 학습")
        dialog.geometry("680x520")
        dialog.transient(self.root)
        text=tk.Text(dialog,wrap="word")
        text.pack(fill="both",expand=True,padx=12,pady=12)

        def refresh():
            profile=load_preference_profile()
            summary=profile.get("summary",{})
            consistency=preference_consistency_score(self.project,profile)
            lines=[
                f"학습 프로젝트 수: {summary.get('sample_count',0)}개",
                f"선호 스타일: {summary.get('preferred_style','학습 전')}",
                f"선호 레이아웃: {summary.get('preferred_layout','학습 전')}",
                f"선호 컷 수: {summary.get('preferred_cut_count','-')}",
                f"선호 제목 크기: {summary.get('preferred_title_size','-')}",
                f"선호 본문 크기: {summary.get('preferred_body_size','-')}",
                f"선호 정렬: {summary.get('preferred_text_align','-')}",
                f"브랜드 없이 제작 비율: {round(float(summary.get('brandless_ratio',0))*100)}%",
                "",
                f"현재 프로젝트 취향 일치도: {consistency.get('score',0)}점",
            ]
            lines.extend(f"- {issue}" for issue in consistency.get("issues",[]))
            text.config(state="normal"); text.delete("1.0","end"); text.insert("1.0","\n".join(lines)); text.config(state="disabled")

        def learn():
            if not self.project.cuts:
                return messagebox.showwarning("학습 불가","현재 프로젝트에 상세페이지 컷이 없습니다.",parent=dialog)
            self.project.fields=self.fields()
            profile=learn_project_preferences(self.project,source_name=self.project.fields.get("product",""))
            messagebox.showinfo("학습 완료",f"현재 프로젝트의 승인·수정 형식을 학습했습니다.\n누적 {profile['summary']['sample_count']}개",parent=dialog)
            refresh()

        def apply_profile():
            self.snapshot()
            result=apply_preference_profile(self.project)
            if not result["applied"]:
                return messagebox.showinfo("적용 불가",result["reason"],parent=dialog)
            for key,variable in self.vars.items(): variable.set(self.project.fields.get(key,""))
            self.style.set(self.project.style); self.layout.set(self.project.layout); self.show()
            messagebox.showinfo("취향 적용 완료","적용 항목: "+", ".join(result["changes"]),parent=dialog)
            refresh()

        def save_profile():
            profile=load_preference_profile()
            path=filedialog.asksaveasfilename(parent=dialog,defaultextension=".json",initialfile="농작AI_작업취향.json",filetypes=[("JSON","*.json")])
            if path: export_preference_profile(profile,path)

        buttons=ttk.Frame(dialog,padding=(12,0,12,12)); buttons.pack(fill="x")
        ttk.Button(buttons,text="현재 프로젝트 학습",command=learn).pack(side="left",padx=3)
        ttk.Button(buttons,text="취향 적용",command=apply_profile).pack(side="left",padx=3)
        ttk.Button(buttons,text="프로필 저장",command=save_profile).pack(side="right",padx=3)
        refresh()

    def v52_registration_package_ui(self):
        if not self.project.cuts:
            return messagebox.showwarning("상세페이지 필요","상세페이지 초안을 먼저 생성하세요.")
        folder=filedialog.askdirectory()
        if not folder:return
        self.project.fields=self.fields()
        result=export_registration_package(self.project,folder,"스마트스토어")
        messagebox.showinfo("v5.2 등록패키지 완료",f"상태: {result['validation']['status']}\n\n{result['zip']}")

    def v53_batch_registration_ui(self):
        project_folder=filedialog.askdirectory(title="농작 프로젝트 폴더 선택")
        if not project_folder:return
        output_folder=filedialog.askdirectory(title="결과 저장 폴더 선택")
        if not output_folder:return
        files=discover_project_files(project_folder)
        if not files:return messagebox.showinfo("배치 등록점검","프로젝트 파일을 찾지 못했습니다.")
        ready_only=messagebox.askyesno("배치 등록점검","등록 가능한 상품만 패키지를 생성할까요?")
        result=export_batch_registration_packages(files,output_folder,"스마트스토어",ready_only)
        audit=result["audit"]
        messagebox.showinfo(
            "v5.3 배치 등록점검 완료",
            f"전체 {audit['total']}개\n등록 가능 {audit['ready_count']}개\n"
            f"보완 필요 {audit['needs_work_count']}개\n오류 {audit['error_count']}개\n"
            f"패키지 생성 {result['package_count']}개\n\n{result['reports']['csv']}",
        )

    def v51_strategy_ui(self):
        if not self.project.cuts:
            return messagebox.showwarning("상세페이지 필요","상세페이지 초안을 먼저 생성하세요.")

        dialog=tk.Toplevel(self.root)
        dialog.title("v5.1 AI 판매전략 엔진")
        dialog.geometry("820x680")
        dialog.transient(self.root)

        channel=tk.StringVar(value="스마트스토어")
        top=ttk.Frame(dialog,padding=12)
        top.pack(fill="x")
        ttk.Label(top,text="판매 채널").pack(side="left")
        ttk.Combobox(
            top,
            textvariable=channel,
            values=["스마트스토어","쿠팡","일반 쇼핑몰"],
            state="readonly",
            width=20,
        ).pack(side="left",padx=8)

        text=tk.Text(dialog,wrap="word")
        text.pack(fill="both",expand=True,padx=12,pady=(0,12))
        current_strategy={}

        def run_analysis():
            nonlocal current_strategy
            self.project.fields=self.fields()
            current_strategy=build_sales_strategy(self.project,channel.get())
            score=current_strategy["strategy_score"]
            lines=[
                f"상품: {current_strategy['product']}",
                f"채널: {current_strategy['channel']}",
                f"판매전략 점수: {score['score']}점 / {score['grade']}등급",
                "",
                "항목별 점수",
            ]
            lines.extend(
                f"- {name}: {value}점"
                for name,value in score["dimensions"].items()
            )
            lines.extend(["","추천 상품명"])
            lines.extend(
                f"{index+1}. {item['title']} ({item['score']}점)"
                for index,item in enumerate(current_strategy["product_titles"][:5])
            )
            lines.extend(["","썸네일 제안"])
            lines.extend(
                f"- {item['name']}: {item['headline'].replace(chr(10),' / ')}"
                for item in current_strategy["thumbnail_concepts"]
            )
            lines.extend(["","우선 개선사항"])
            lines.extend(
                f"- {action}"
                for action in current_strategy["top_actions"]
            )
            if not current_strategy["top_actions"]:
                lines.append("- 큰 수정 없이 검수 단계로 이동할 수 있습니다.")

            text.config(state="normal")
            text.delete("1.0","end")
            text.insert("1.0","\n".join(lines))
            text.config(state="disabled")
            self.status("v5.1 판매전략 분석 완료")

        def apply_result():
            if not current_strategy:
                run_analysis()
            self.snapshot()
            apply_sales_strategy(
                self.project,
                current_strategy,
                apply_best_title=True,
                apply_cut_recommendations=True,
            )
            self.current=0
            self.show()
            messagebox.showinfo(
                "판매전략 적용 완료",
                "최적화 상품명을 프로젝트 정보에 저장하고\n컷 제목·스토리 단계·레이아웃 개선안을 적용했습니다.",
                parent=dialog,
            )
            self.status("v5.1 판매전략 적용 완료")

        def save_report():
            if not current_strategy:
                run_analysis()
            path=filedialog.asksaveasfilename(
                parent=dialog,
                defaultextension=".json",
                initialfile="v5_1_sales_strategy.json",
                filetypes=[("JSON 전략 보고서","*.json")],
            )
            if path:
                export_sales_strategy_report(current_strategy,path)
                self.status("v5.1 판매전략 보고서 저장 완료")

        buttons=ttk.Frame(dialog,padding=(12,0,12,12))
        buttons.pack(fill="x")
        ttk.Button(buttons,text="분석 실행",command=run_analysis).pack(side="left",padx=3)
        ttk.Button(buttons,text="전략 적용",command=apply_result).pack(side="right",padx=3)
        ttk.Button(buttons,text="보고서 저장",command=save_report).pack(side="right",padx=3)
        run_analysis()

    def v5_analysis_ui(self):
        if not self.project.images:
            return messagebox.showwarning("사진 필요","상품 사진을 먼저 불러오세요.")
        self.status("v5.0 AI가 상품사진을 분석 중...")
        self.root.update_idletasks()
        try:
            analysis=v5_analyze_product(self.project.images,self.fields())
        except Exception as error:
            return messagebox.showerror("v5.0 분석 오류",str(error))

        self.project.ai_analysis=analysis
        hero=analysis["hero_image"]
        visual=analysis["visual_identity"]
        copy_result=analysis["copy"]
        lines=[
            f"상품명 추정: {analysis['fields']['product']}",
            f"품목 분류: {analysis['fields']['category']}",
            f"분류 신뢰도: {round(analysis['confidence']*100)}%",
            f"대표사진: {Path(hero['selected_path']).name}",
            f"추천 스타일: {visual['style']} / {visual['layout']}",
            f"색상 계열: {visual['color_family']} ({visual['dominant_color']})",
            f"추천 상품명: {copy_result['recommended_product_name']}",
            f"메인 문구: {copy_result['main_copy']}",
            "",
            "주의사항",
        ]
        lines.extend(f"- {warning}" for warning in analysis.get("warnings",[]))
        if not analysis.get("warnings"):
            lines.append("- 별도 경고 없음")

        dialog=tk.Toplevel(self.root)
        dialog.title("v5.0 AI 자동 분석 결과")
        dialog.geometry("680x560")
        text=tk.Text(dialog,wrap="word")
        text.pack(fill="both",expand=True,padx=12,pady=12)
        text.insert("1.0","\n".join(lines))
        text.config(state="disabled")

        def apply_result():
            self.snapshot()
            apply_v5_analysis_to_project(self.project,analysis,overwrite_fields=False)
            for key,variable in self.vars.items():
                variable.set(self.project.fields.get(key,""))
            self.style.set(self.project.style)
            self.layout.set(self.project.layout)
            self.current=0
            self.show()
            dialog.destroy()
            self.status("v5.0 AI 분석 결과 적용 완료")

        def save_report():
            path=filedialog.asksaveasfilename(
                parent=dialog,
                defaultextension=".json",
                initialfile="v5_ai_analysis.json",
                filetypes=[("JSON 분석 보고서","*.json")],
            )
            if path:
                export_v5_analysis_report(analysis,path)
                self.status("v5.0 AI 분석 보고서 저장 완료")

        buttons=ttk.Frame(dialog,padding=(12,0,12,12))
        buttons.pack(fill="x")
        ttk.Button(buttons,text="분석 결과 적용",command=apply_result).pack(side="right",padx=3)
        ttk.Button(buttons,text="보고서 저장",command=save_report).pack(side="right",padx=3)

    def v5_build_ui(self):
        if not self.project.images:
            return messagebox.showwarning("사진 필요","상품 사진을 먼저 불러오세요.")
        self.status("v5.0 AI 엔진으로 상세페이지 자동 제작 중...")
        self.root.update_idletasks()
        try:
            project,result=build_v5_project(
                self.fields(),
                self.project.images,
                self.count.get(),
            )
        except Exception as error:
            return messagebox.showerror("v5.0 자동 제작 오류",str(error))

        self.snapshot()
        self.project=project
        self.last_workflow_result=result
        for key,variable in self.vars.items():
            variable.set(project.fields.get(key,""))
        self.style.set(project.style)
        self.layout.set(project.layout)
        self.current=0
        self.show()

        analysis=result["analysis"]
        messagebox.showinfo(
            "v5.0 AI 자동 제작 완료",
            f"상품명: {project.fields.get('product','')}\n"
            f"품목: {project.fields.get('category','')}\n"
            f"대표사진: {Path(analysis['hero_image']['selected_path']).name}\n"
            f"스타일: {project.style} / {project.layout}\n"
            f"품질 점수: {result['quality']['score']}점\n\n"
            "첫 컷부터 한 장씩 확인해 주세요.",
        )
        self.status("v5.0 AI 자동 제작 완료")

    def one_click_build_ui(self):
        if not self.project.images:
            return messagebox.showwarning("사진 필요", "상품 사진을 먼저 불러오세요.")

        self.status("상품 분석부터 사진 배치까지 자동 제작 중...")
        self.root.update_idletasks()

        try:
            project, result = build_one_click_project(
                self.fields(),
                self.project.images,
                self.count.get(),
                self.ai_config,
            )
        except Exception as error:
            return messagebox.showerror("자동 제작 오류", str(error))

        self.snapshot()
        self.project = project
        self.last_workflow_result = result

        for key, variable in self.vars.items():
            variable.set(self.project.fields.get(key, ""))
        self.style.set(self.project.style)
        self.layout.set(self.project.layout)
        self.current = 0
        self.show()

        summary = create_workflow_summary(self.project, result)
        lines = [
            f"상품명: {summary['product']}",
            f"품목: {summary['category']}",
            f"AI 분석: {summary['ai_provider']}",
            f"상세페이지 품질: {summary['quality_score']}점",
            f"스토리 구성: {summary['story_score']}점",
            f"사진 배치: {summary['image_usage_score']}점",
            "",
            "각 컷을 한 장씩 확인한 뒤 승인해 주세요.",
        ]
        messagebox.showinfo("한 번에 자동 제작 완료", "\n".join(lines))
        self.status("한 번에 자동 제작 완료")

    def export_one_click_ui(self):
        if not self.project.cuts:
            return messagebox.showwarning("초안 필요", "자동 제작 또는 초안 생성을 먼저 실행하세요.")
        folder = filedialog.askdirectory()
        if not folder:
            return

        result = self.last_workflow_result or {
            "analysis": self.project.ai_analysis or {},
            "quality": score_project_quality(self.project),
            "story_quality": analyze_story_flow(self.project),
            "image_usage": analyze_image_usage(self.project),
        }
        try:
            package = export_one_click_package(self.project, result, folder)
        except Exception as error:
            return messagebox.showerror("자동 패키지 저장 오류", str(error))

        messagebox.showinfo(
            "자동 패키지 저장 완료",
            f"PNG {package['png_count']}장, PDF, 프로젝트 파일과 검수 보고서를 저장했습니다.",
        )
        self.status("자동 제작 패키지 저장 완료")

    def auto_image_assign_ui(self):
        if not self.project.cuts or not self.project.images:
            return messagebox.showwarning("사진과 초안 필요", "상품 사진과 상세페이지 초안을 먼저 준비하세요.")
        recommendations = apply_recommended_images(self.project, avoid_duplicates=True)
        self.current = 0
        self.show()
        self.status(f"컷별 사진 자동 배치 완료: {len(recommendations)}컷")

    def image_usage_ui(self):
        if not self.project.cuts or not self.project.images:
            return messagebox.showwarning("사진과 초안 필요", "상품 사진과 상세페이지 초안을 먼저 준비하세요.")
        result = analyze_image_usage(self.project)
        lines = [
            f"사진 사용 점수: {result['score']}점",
            "",
            "반복 사용 사진",
        ]
        if result["duplicate_images"]:
            lines.extend(
                f"- {Path(item['path']).name}: {item['used_count']}회"
                for item in result["duplicate_images"]
            )
        else:
            lines.append("- 없음")

        lines.extend(["", "미사용 사진"])
        if result["unused_images"]:
            lines.extend(
                f"- {Path(item['path']).name}"
                for item in result["unused_images"]
            )
        else:
            lines.append("- 없음")

        if result["invalid_cuts"]:
            lines.extend(["", "사진 연결 오류 컷"])
            lines.append(", ".join(str(index) for index in result["invalid_cuts"]))

        dialog = tk.Toplevel(self.root)
        dialog.title("사진 사용 점검")
        dialog.geometry("620x500")
        text = tk.Text(dialog, wrap="word")
        text.pack(fill="both", expand=True, padx=12, pady=12)
        text.insert("1.0", "\n".join(lines))
        text.config(state="disabled")

        def save_report():
            path = filedialog.asksaveasfilename(
                parent=dialog,
                defaultextension=".json",
                filetypes=[("JSON 보고서", "*.json")],
            )
            if path:
                export_image_assignment_report(self.project, path)
                self.status("사진 배치 보고서 저장 완료")

        ttk.Button(dialog, text="보고서 저장", command=save_report).pack(pady=(0, 12))

    def story_flow_ui(self):
        self.project.fields = self.fields()
        if not self.project.cuts:
            return messagebox.showwarning("초안 필요", "상세페이지 초안을 먼저 생성하세요.")
        flow = apply_story_flow(self.project, overwrite_titles=True, reorder=True)
        self.current = 0
        self.show()
        self.status(f"상품 스토리 자동 구성 완료: {len(flow)}단계")

    def story_check_ui(self):
        if not self.project.cuts:
            return messagebox.showwarning("초안 필요", "상세페이지 초안을 먼저 생성하세요.")
        result = analyze_story_flow(self.project)
        lines = [
            f"스토리 점수: {result['score']}점",
            "",
            "현재 구성",
        ]
        lines.extend(
            f"{item['index']}. [{item['stage']}] {item['title']} / {item['layout']}"
            for item in result["actual"]
        )
        if result["deductions"]:
            lines.extend(["", "감점 항목"])
            lines.extend(
                f"- {item['points']}점: {item['reason']}"
                for item in result["deductions"]
            )

        dialog = tk.Toplevel(self.root)
        dialog.title("상품 스토리 점검")
        dialog.geometry("650x520")
        text = tk.Text(dialog, wrap="word")
        text.pack(fill="both", expand=True, padx=12, pady=12)
        text.insert("1.0", "\n".join(lines))
        text.config(state="disabled")

        def save_report():
            path = filedialog.asksaveasfilename(
                parent=dialog,
                defaultextension=".json",
                filetypes=[("JSON 보고서", "*.json")],
            )
            if path:
                export_storyboard(self.project, path)
                self.status("스토리보드 보고서 저장 완료")

        ttk.Button(dialog, text="스토리보드 저장", command=save_report).pack(pady=(0, 12))

    def auto_layout_ui(self):
        if not self.project.cuts:
            return messagebox.showwarning("초안 필요", "상세페이지 초안을 먼저 생성하세요.")
        self.snapshot()
        assigned = auto_assign_cut_layouts(self.project)
        self.show()
        self.status(f"컷별 레이아웃 자동배치 완료: {len(assigned)}컷")

    def apply_category_template_ui(self):
        self.project.fields = self.fields()
        if not self.project.cuts:
            return messagebox.showwarning("초안 필요", "상세페이지 초안을 먼저 생성하세요.")
        recommendation = apply_category_template(self.project, overwrite_titles=True)
        self.style.set(self.project.style)
        self.layout.set(self.project.layout)
        self.show()
        self.status(
            f"{recommendation['category']} 템플릿 적용: "
            f"{recommendation['style']} / {recommendation['layout']}"
        )

    def quality_score_ui(self):
        self.project.fields = self.fields()
        result = score_project_quality(self.project)
        lines = [
            f"품질 점수: {result['score']}점",
            f"등급: {result['grade']}",
            f"평가: {result['summary']}",
            "",
            "감점 항목",
        ]
        if result["deductions"]:
            lines.extend(
                f"- {item['points']}점: {item['reason']}"
                for item in result["deductions"]
            )
        else:
            lines.append("- 감점 항목 없음")

        dialog = tk.Toplevel(self.root)
        dialog.title("상세페이지 품질 점수")
        dialog.geometry("560x430")
        text = tk.Text(dialog, wrap="word")
        text.pack(fill="both", expand=True, padx=12, pady=12)
        text.insert("1.0", "\n".join(lines))
        text.config(state="disabled")

        def save_report():
            path = filedialog.asksaveasfilename(
                parent=dialog,
                defaultextension=".json",
                filetypes=[("JSON 보고서", "*.json")],
            )
            if path:
                export_quality_report(self.project, path)
                self.status("품질 점수 보고서 저장 완료")

        ttk.Button(dialog, text="보고서 저장", command=save_report).pack(pady=(0, 12))

    def project_library(self):
        dialog = tk.Toplevel(self.root)
        dialog.title("프로젝트 보관함")
        dialog.geometry("760x460")
        dialog.transient(self.root)

        search_var = tk.StringVar()
        top = ttk.Frame(dialog, padding=10)
        top.pack(fill="x")
        ttk.Entry(top, textvariable=search_var).pack(side="left", fill="x", expand=True)
        tree = ttk.Treeview(dialog, columns=("category", "cuts", "images", "updated"), show="tree headings")
        tree.heading("#0", text="상품명")
        tree.heading("category", text="품목")
        tree.heading("cuts", text="컷")
        tree.heading("images", text="사진")
        tree.heading("updated", text="수정일")
        tree.column("#0", width=220)
        tree.column("category", width=120)
        tree.column("cuts", width=60, anchor="center")
        tree.column("images", width=60, anchor="center")
        tree.column("updated", width=180)
        tree.pack(fill="both", expand=True, padx=10, pady=(0, 10))

        def refresh():
            tree.delete(*tree.get_children())
            for item in search_library(search_var.get()):
                tree.insert(
                    "",
                    "end",
                    iid=item["path"],
                    text=item["product"],
                    values=(item["category"], item["cuts"], item["images"], item["updated_at"]),
                )

        def open_selected():
            selected = tree.selection()
            if not selected:
                return
            path = selected[0]
            self.load_project_path(path)
            dialog.destroy()

        ttk.Button(top, text="검색", command=refresh).pack(side="left", padx=4)
        ttk.Button(top, text="현재 프로젝트 보관", command=self.save_library_ui).pack(side="left", padx=4)
        buttons = ttk.Frame(dialog, padding=(10, 0, 10, 10))
        buttons.pack(fill="x")
        ttk.Button(buttons, text="선택 프로젝트 열기", command=open_selected).pack(side="right")
        tree.bind("<Double-1>", lambda event: open_selected())
        refresh()

    def save_library_ui(self):
        self.project.fields = self.fields()
        if not self.project.fields.get("product", "").strip():
            return messagebox.showwarning("상품명 필요", "상품명을 입력한 뒤 보관하세요.")
        path = save_to_library(self.project)
        self.current_project_path = str(path)
        self.status(f"프로젝트 보관 완료: {path.name}")
        return path

    def recent_projects(self):
        items = load_recent_projects()
        if not items:
            return messagebox.showinfo("최근 작업", "최근 작업 기록이 없습니다.")
        dialog = tk.Toplevel(self.root)
        dialog.title("최근 작업")
        dialog.geometry("620x360")
        listbox = tk.Listbox(dialog)
        listbox.pack(fill="both", expand=True, padx=12, pady=12)
        for item in items:
            listbox.insert("end", f"{item['name']}  |  {item['updated_at']}")

        def open_selected():
            selected = listbox.curselection()
            if not selected:
                return
            self.load_project_path(items[selected[0]]["path"])
            dialog.destroy()

        ttk.Button(dialog, text="선택 열기", command=open_selected).pack(pady=(0, 12))
        listbox.bind("<Double-1>", lambda event: open_selected())

    def load_project_path(self, path):
        self.project = load_project(path)
        self.current_project_path = str(path)
        register_recent_project(path)
        for key, variable in self.vars.items():
            variable.set(self.project.fields.get(key, ""))
        self.style.set(self.project.style)
        self.layout.set(self.project.layout)
        self.background.set(self.project.custom_background)
        self.current = 0
        self.show()
        self.status(f"프로젝트 열기 완료: {Path(path).name}")

    def export_all_ui(self):
        if not self.project.cuts:
            return messagebox.showwarning("초안 필요", "상세페이지 초안을 먼저 생성하세요.")
        folder = filedialog.askdirectory()
        if not folder:
            return
        self.project.fields = self.fields()
        try:
            summary = export_all_formats(self.project, folder)
        except Exception as error:
            return messagebox.showerror("통합 내보내기 오류", str(error))
        messagebox.showinfo(
            "통합 내보내기 완료",
            f"PNG {summary['png_count']}장, PDF, 프로젝트 파일, 검수 요약을 저장했습니다."
        )
        self.status("통합 내보내기 완료")

    def ai_settings(self):
        dialog = tk.Toplevel(self.root)
        dialog.title("AI 연결 설정")
        dialog.transient(self.root)
        dialog.grab_set()

        mode = tk.StringVar(value=self.ai_config.mode)
        endpoint = tk.StringVar(value=self.ai_config.endpoint)
        api_key = tk.StringVar(value=self.ai_config.api_key)
        model = tk.StringVar(value=self.ai_config.model)

        ttk.Label(dialog, text="모드").grid(row=0, column=0, sticky="w", padx=12, pady=6)
        ttk.Combobox(dialog, textvariable=mode, values=["offline", "remote"], state="readonly", width=40).grid(row=0, column=1, padx=12, pady=6)
        ttk.Label(dialog, text="API 주소").grid(row=1, column=0, sticky="w", padx=12, pady=6)
        ttk.Entry(dialog, textvariable=endpoint, width=48).grid(row=1, column=1, padx=12, pady=6)
        ttk.Label(dialog, text="API 키").grid(row=2, column=0, sticky="w", padx=12, pady=6)
        ttk.Entry(dialog, textvariable=api_key, show="*", width=48).grid(row=2, column=1, padx=12, pady=6)
        ttk.Label(dialog, text="모델명").grid(row=3, column=0, sticky="w", padx=12, pady=6)
        ttk.Entry(dialog, textvariable=model, width=48).grid(row=3, column=1, padx=12, pady=6)

        def save():
            self.ai_config = AIConfig(
                mode=mode.get(),
                endpoint=endpoint.get().strip(),
                api_key=api_key.get().strip(),
                model=model.get().strip(),
            )
            save_ai_config(self.ai_config)
            dialog.destroy()
            self.status(f"AI 모드 저장: {self.ai_config.mode}")

        ttk.Button(dialog, text="저장", command=save).grid(row=4, column=0, columnspan=2, sticky="ew", padx=12, pady=12)

    def ai_analyze(self):
        if not self.project.images:
            return messagebox.showwarning("사진 필요", "먼저 상품 사진을 불러오세요.")
        self.status("AI 상품 분석 중...")
        self.root.update_idletasks()
        analysis = analyze_product(self.project.images, self.fields(), self.ai_config)
        self.project.ai_analysis = analysis
        merged = apply_analysis_fields(self.fields(), analysis, overwrite=False)
        for key, value in merged.items():
            if key in self.vars:
                self.vars[key].set(value)

        copy = analysis.get("copy", {})
        warnings = analysis.get("warnings", [])
        display = [
            f"분석 방식: {analysis.get('provider', 'unknown')}",
            f"신뢰도: {analysis.get('confidence', '표시 없음')}",
            "",
            "추천 상품명",
            str(copy.get("recommended_product_name", "")),
            "",
            "메인 카피",
            str(copy.get("main_copy", "")),
            "",
            "검색 키워드",
            ", ".join(copy.get("search_keywords", [])),
            "",
            "주의사항",
            "\n".join(f"- {item}" for item in warnings),
        ]
        self.analysis_text.delete("1.0", "end")
        self.analysis_text.insert("1.0", "\n".join(display))
        self.status(f"AI 분석 완료: {analysis.get('provider', 'unknown')}")

    def generate(self):
        if not self.project.images:
            return messagebox.showwarning("사진 필요", "사진을 먼저 불러오세요.")
        self.snapshot()
        self.project.fields = self.fields()
        self.project.style = self.style.get()
        self.project.layout = self.layout.get()
        self.project.custom_background = self.background.get()
        self.project.cuts = build_cuts(self.project.fields, self.count.get())
        for index, cut in enumerate(self.project.cuts):
            cut.photo_index = index % len(self.project.images)
        self.current = 0
        self.show()
        self.status("초안 생성 완료")

    def render_current(self):
        cut = self.project.cuts[self.current]
        return render_cut(
            self.project.images[cut.photo_index],
            self.current,
            cut,
            self.project.style,
            self.project.layout,
            self.project.custom_background,
        )

    def show(self):
        if not self.project.cuts:
            return
        image = self.render_current()
        image.thumbnail((680, 730))
        self.tk_image = ImageTk.PhotoImage(image)
        self.preview.config(image=self.tk_image)
        cut = self.project.cuts[self.current]
        self.page.config(text=f"{self.current + 1} / {len(self.project.cuts)}")
        self.title.set(cut.title)
        self.body.delete("1.0", "end")
        self.body.insert("1.0", cut.body)
        self.scale.set(cut.image_scale)
        self.title_size.set(cut.title_size)
        self.body_size.set(cut.body_size)
        self.align.set(cut.text_align)
        self.cut_layout.set(getattr(cut, "layout_variant", "기본 카드형"))
        self.story_stage.set(getattr(cut, "story_stage", "상품 소개"))
        self.approved.set(cut.approved)

    def previous(self):
        if self.project.cuts:
            self.current = (self.current - 1) % len(self.project.cuts)
            self.show()

    def next(self):
        if self.project.cuts:
            self.current = (self.current + 1) % len(self.project.cuts)
            self.show()

    def apply(self):
        if not self.project.cuts:
            return
        self.snapshot()
        cut = self.project.cuts[self.current]
        cut.title = self.title.get().strip() or cut.title
        cut.body = self.body.get("1.0", "end").strip() or cut.body
        cut.image_scale = float(self.scale.get())
        cut.title_size = int(self.title_size.get())
        cut.body_size = int(self.body_size.get())
        cut.text_align = self.align.get()
        cut.layout_variant = self.cut_layout.get()
        cut.story_stage = self.story_stage.get()
        self.show()
        self.status("수정 적용")

    def move_image(self, dx: int, dy: int):
        if not self.project.cuts:
            return
        self.snapshot()
        cut = self.project.cuts[self.current]
        cut.image_offset_x += dx
        cut.image_offset_y += dy
        self.show()

    def approve(self):
        if self.project.cuts:
            self.project.cuts[self.current].approved = self.approved.get()

    def duplicate_current(self):
        if not self.project.cuts:
            return
        self.snapshot()
        self.project.cuts.insert(self.current + 1, duplicate_cut(self.project.cuts[self.current]))
        self.current += 1
        self.show()

    def delete_current(self):
        if not self.project.cuts:
            return
        self.snapshot()
        self.project.cuts.pop(self.current)
        self.current = max(0, min(self.current, len(self.project.cuts) - 1))
        self.show()

    def move_cut(self, direction: int):
        new_index = self.current + direction
        if not self.project.cuts or new_index < 0 or new_index >= len(self.project.cuts):
            return
        self.snapshot()
        self.project.cuts[self.current], self.project.cuts[new_index] = self.project.cuts[new_index], self.project.cuts[self.current]
        self.current = new_index
        self.show()

    def validate_ui(self):
        self.project.fields = self.fields()
        issues = validate_project(self.project)
        messagebox.showinfo("등록 전 점검", "\n".join(f"[{item['level']}] {item['message']}" for item in issues))

    def export_png(self):
        if not self.project.cuts:
            return
        folder = filedialog.askdirectory()
        if not folder:
            return
        for index, cut in enumerate(self.project.cuts):
            render_cut(
                self.project.images[cut.photo_index],
                index,
                cut,
                self.project.style,
                self.project.layout,
                self.project.custom_background,
            ).save(Path(folder) / f"{index + 1:02d}_{cut.title}.png")
        self.status("PNG 저장 완료")

    def export_pdf(self):
        if not self.project.cuts:
            return
        path = filedialog.asksaveasfilename(defaultextension=".pdf", filetypes=[("PDF", "*.pdf")])
        if not path:
            return
        pages = [
            render_cut(
                self.project.images[cut.photo_index],
                index,
                cut,
                self.project.style,
                self.project.layout,
                self.project.custom_background,
            )
            for index, cut in enumerate(self.project.cuts)
        ]
        pages[0].save(path, save_all=True, append_images=pages[1:])
        self.status("PDF 저장 완료")

    def save(self):
        self.project.fields = self.fields()
        path = filedialog.asksaveasfilename(defaultextension=".nongjak.json", filetypes=[("농작 프로젝트", "*.nongjak.json")])
        if path:
            save_project(self.project, path)
            self.current_project_path = path
            register_recent_project(path)
            create_backup(self.project, path)
            self.last_saved_fingerprint=project_fingerprint(self.project)
            self.dirty=False
            save_session_state(self.project,self.current,False)
            self.status("프로젝트 저장 및 백업 완료")

    def open(self):
        path = filedialog.askopenfilename(filetypes=[("농작 프로젝트", "*.nongjak.json")])
        if not path:
            return
        self.load_project_path(path)
        return
        for key, variable in self.vars.items():
            variable.set(self.project.fields.get(key, ""))
        self.style.set(self.project.style)
        self.layout.set(self.project.layout)
        self.background.set(self.project.custom_background)
        self.current = 0
        self.show()

    def new(self):
        if self.project.cuts or self.project.images:
            try:
                create_backup(self.project, self.current_project_path)
            except Exception:
                pass
        self.project = Project(fields={}, images=[], cuts=[])
        self.current_project_path = None
        self.dirty=False
        for variable in self.vars.values():
            variable.set("")
        self.preview.config(image="")
        self.page.config(text="0 / 0")
        self.analysis_text.delete("1.0", "end")
        self.status("새 프로젝트 시작")
