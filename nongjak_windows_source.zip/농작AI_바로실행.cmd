﻿@echo off
cd /d "%~dp0"
call "ONE_CLICK_START.cmd"
