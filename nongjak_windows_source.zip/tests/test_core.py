import json
import sys
import tempfile
import copy
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from PIL import Image
from nongjak.core import (
    AIConfig,
    Project,
    Cut,
    export_project_with_checkpoint,
    inspect_cut_checkpoint,
    analyze_product,
    apply_analysis_fields,
    build_cuts,
    load_ai_config,
    load_project,
    render_cut,
    save_ai_config,
    save_project,
    save_to_library,
    list_library_projects,
    search_library,
    register_recent_project,
    load_recent_projects,
    create_backup,
    export_all_formats,
    recommend_template,
    apply_category_template,
    score_project_quality,
    export_quality_report,
    STYLE_PRESETS,
    CUT_LAYOUT_VARIANTS,
    recommend_cut_layout,
    auto_assign_cut_layouts,
    analyze_image_visual_features,
    infer_category_and_product,
    v5_analyze_product,
    apply_v5_analysis_to_project,
    build_v5_project,
    export_v5_analysis_report,
    generate_channel_product_titles,
    score_sales_strategy,
    recommend_cut_improvements,
    generate_thumbnail_concepts,
    build_sales_strategy,
    apply_sales_strategy,
    export_sales_strategy_report,
    parse_option_text,
    build_channel_registration_data,
    export_registration_package,
    discover_project_files,
    batch_registration_audit,
    registration_issue_summary,
    export_batch_registration_report,
    export_batch_registration_packages,
    approved_cut_statistics,
    build_preference_sample,
    summarize_preference_samples,
    learn_project_preferences,
    load_preference_profile,
    recommend_from_preference_profile,
    apply_preference_profile,
    preference_consistency_score,
    export_preference_profile,
    reset_preference_profile,
    score_preference_sample,
    enrich_preference_sample,
    preference_profile_health,
    rebuild_preference_profile,
    remove_latest_preference_sample,
    create_preference_snapshot,
    list_preference_snapshots,
    restore_preference_snapshot,
    recommend_category_preference,
    preference_profile_comparison,
    WorkspaceConfig,
    save_workspace_config,
    load_workspace_config,
    ensure_workspace_folders,
    apply_workspace_defaults,
    create_workspace_project,
    save_startup_history,
    load_startup_history,
    save_session_state,
    load_session_state,
    _candidate_from_project,
    select_best_recovery_candidate,
    create_autosave_snapshot,
    archive_recovery_state,
    export_startup_dashboard_report,
    list_project_templates,
    validate_project_template,
    find_project_template,
    project_from_template,
    create_template_from_project,
    upsert_custom_project_template,
    load_custom_project_templates,
    recommend_project_templates,
    export_template_pack,
    import_template_pack,
    template_library_summary,
    delete_custom_project_template,
    snapshot_cut_revision,
    snapshot_all_cut_revisions,
    list_cut_revisions,
    restore_cut_revision,
    compare_cut_revisions,
    revision_history_summary,
    final_approval_gate,
    create_final_approval_record,
    validate_final_approval_record,
    export_final_release_package,
    export_revision_report,
    set_cut_review,
    generate_product_title_set,
    generate_search_keyword_plan,
    analyze_customer_purchase_psychology,
    generate_copy_style_variants,
    build_intelligent_page_plan,
    product_intelligence_score,
    build_product_intelligence,
    project_from_product_intelligence,
    export_product_intelligence_report,
    estimate_text_lines,
    cut_design_diagnostics,
    project_design_quality,
    recommend_cut_design_settings,
    apply_cut_design_settings,
    auto_optimize_project_design,
    build_design_contact_sheet,
    export_design_quality_report,
    thumbnail_text_candidates,
    select_thumbnail_source_image,
    render_thumbnail_variant,
    thumbnail_quality_score,
    generate_thumbnail_set,
    build_thumbnail_contact_sheet,
    generate_ad_copy,
    ad_banner_quality_score,
    render_ad_banner,
    generate_ad_banner_set,
    build_ad_banner_contact_sheet,
)


with tempfile.TemporaryDirectory() as directory:
    directory = Path(directory)
    image_path = directory / "전남_초당옥수수_01.jpg"
    Image.new("RGB", (1200, 1000), (220, 190, 60)).save(image_path)

    analysis = analyze_product([str(image_path)], {}, AIConfig(mode="offline"))
    assert analysis["provider"] == "offline"
    assert analysis["fields"]["product"] == "초당옥수수"
    merged = apply_analysis_fields({}, analysis)
    assert merged["category"] == "농산물"

    config_path = directory / "ai.json"
    save_ai_config(AIConfig(mode="remote", endpoint="http://localhost/test", model="demo"), config_path)
    loaded_config = load_ai_config(config_path)
    assert loaded_config.mode == "remote"
    assert loaded_config.model == "demo"

    project = Project(
        fields=merged,
        images=[str(image_path)],
        cuts=build_cuts(merged, 8),
        ai_analysis=analysis,
    )
    rendered = render_cut(image_path, 0, project.cuts[0], "프리미엄", "균형형")
    assert rendered.size == (900, 1200)

    project_path = directory / "project.nongjak.json"
    save_project(project, project_path)
    loaded = load_project(project_path)
    assert loaded.ai_analysis["fields"]["product"] == "초당옥수수"
    assert len(loaded.cuts) == 8

    library_dir = directory / "library"
    recent_file = directory / "recent.json"
    saved_library = save_to_library(project, library_dir, recent_file)
    assert saved_library.exists()
    assert len(list_library_projects(library_dir)) == 1
    assert search_library("초당", library_dir)
    register_recent_project(saved_library, recent_file)
    assert load_recent_projects(recent_file)[0]["path"] == str(saved_library.resolve())
    backup = create_backup(project, backup_dir=directory / "backups", keep=3)
    assert backup.exists()
    export_dir = directory / "export"
    summary = export_all_formats(project, export_dir)
    assert summary["png_count"] == 8
    assert Path(summary["pdf"]).exists()

    template = recommend_template("농산물", [str(image_path)])
    assert template["style"] in STYLE_PRESETS
    applied = apply_category_template(project)
    assert project.style == applied["style"]
    quality = score_project_quality(project)
    assert 0 <= quality["score"] <= 100
    report_path = export_quality_report(project, directory / "quality.json")
    assert report_path.exists()
    layouts = auto_assign_cut_layouts(project)
    assert len(layouts) == len(project.cuts)
    assert all(layout in CUT_LAYOUT_VARIANTS for layout in layouts)
    for idx, variant in enumerate(CUT_LAYOUT_VARIANTS):
        project.cuts[0].layout_variant = variant
        rendered_variant = render_cut(image_path, idx, project.cuts[0], "프리미엄", "균형형")
        assert rendered_variant.size == (900, 1200)


    v5_feature = analyze_image_visual_features(image_path)
    assert v5_feature["orientation"] == "가로"
    assert v5_feature["resolution_score"] > 0

    classification = infer_category_and_product([str(image_path)], {})
    assert classification["category"] == "농산물"

    v5_analysis = v5_analyze_product(
        [str(image_path)],
        {"origin": "전남", "shipping": "한진택배"},
    )
    assert v5_analysis["engine_version"] == "5.0"
    assert v5_analysis["fields"]["product"] == "옥수수"
    assert v5_analysis["hero_image"]["selected_index"] == 0
    assert v5_analysis["visual_identity"]["style"] in STYLE_PRESETS

    v5_project = Project(
        fields={"origin": "전남", "shipping": "한진택배"},
        images=[str(image_path)],
        cuts=build_cuts({"product": "옥수수"}, 8),
    )
    apply_v5_analysis_to_project(v5_project, v5_analysis)
    assert v5_project.style == v5_analysis["visual_identity"]["style"]
    assert v5_project.ai_analysis["engine_version"] == "5.0"

    built_project, built_result = build_v5_project(
        {"origin": "전남", "shipping": "한진택배"},
        [str(image_path)],
        8,
    )
    assert len(built_project.cuts) == 8
    assert built_result["quality"]["score"] >= 0

    v5_report = export_v5_analysis_report(
        v5_analysis,
        directory / "v5_analysis.json",
    )
    assert v5_report.exists()

    title_candidates = generate_channel_product_titles(
        built_project.fields,
        built_project.ai_analysis,
        "스마트스토어",
    )
    assert len(title_candidates) >= 2
    assert title_candidates[0]["score"] >= title_candidates[-1]["score"]
    sales_score = score_sales_strategy(built_project)
    assert 0 <= sales_score["score"] <= 100
    improvements = recommend_cut_improvements(built_project)
    assert isinstance(improvements, list)
    thumbnails = generate_thumbnail_concepts(built_project, "스마트스토어")
    assert len(thumbnails) == 3
    strategy = build_sales_strategy(built_project, "스마트스토어")
    assert strategy["engine_version"] == "5.1"
    assert strategy["product_titles"]
    apply_sales_strategy(built_project, strategy, True, True)
    assert built_project.fields["optimized_product_name"]
    strategy_report = export_sales_strategy_report(
        strategy,
        directory / "v5_1_strategy.json",
    )
    assert strategy_report.exists()
    built_project.fields.update({"options":"100g, 200g, 300g","price":"10100","weight":"100g","customer_service":"010-0000-0000"})
    assert len(parse_option_text(built_project.fields["options"]))==3
    assert build_channel_registration_data(built_project)["package_version"]=="5.3"
    package=export_registration_package(built_project,directory/"single_registration")
    assert Path(package["zip"]).exists()
    project_dir=directory/"registration_projects"; project_dir.mkdir()
    file1=project_dir/"product1.nongjak.json"; file2=project_dir/"product2.nongjak.json"
    save_project(built_project,file1)
    second=Project.from_dict(built_project.to_dict()); second.fields["product"]="두 번째 상품"; second.fields["origin"]=""; save_project(second,file2)
    discovered=discover_project_files(project_dir); assert len(discovered)==2
    audit=batch_registration_audit(discovered); assert audit["total"]==2
    assert isinstance(registration_issue_summary(audit)["most_common_missing"],list)
    report=export_batch_registration_report(audit,directory/"registration_report"); assert Path(report["csv"]).exists()
    batch=export_batch_registration_packages(discovered,directory/"batch_registration"); assert batch["package_count"]==2
    built_project.cuts[0].approved=True
    built_project.cuts[0].title_size=38
    built_project.cuts[0].body_size=34
    built_project.cuts[0].text_align="left"
    preference_path=directory/"preference.json"
    profile=learn_project_preferences(built_project,preference_path,"테스트 상품")
    assert profile["summary"]["sample_count"]==1
    loaded_profile=load_preference_profile(preference_path)
    recommendation=recommend_from_preference_profile(built_project,loaded_profile)
    assert recommendation["available"] is True
    target=Project.from_dict(built_project.to_dict())
    target.style="심플"; target.layout="사진 크게"
    applied=apply_preference_profile(target,loaded_profile)
    assert applied["applied"] is True
    consistency=preference_consistency_score(target,loaded_profile)
    assert consistency["score"]>=80
    exported_profile=export_preference_profile(loaded_profile,directory/"preference_export.json")
    assert exported_profile.exists()

print("ALL_CORE_TESTS_OK")


def test_checkpoint_reuse_and_repair():
    from tempfile import TemporaryDirectory
    from PIL import Image
    with TemporaryDirectory() as temp:
        root = Path(temp)
        image_path = root / "source.png"
        Image.new("RGB", (1000, 1000), "white").save(image_path)

        project = Project(
            fields={"product": "체크포인트 테스트"},
            images=[str(image_path)],
            cuts=[
                Cut("첫 번째", "설명", 0),
                Cut("두 번째", "설명", 0),
            ],
        )

        first = export_project_with_checkpoint(project, root / "out")
        assert first["regenerated_count"] == 2
        assert first["reused_count"] == 0
        assert first["inspection"]["complete"] is True

        second = export_project_with_checkpoint(project, root / "out")
        assert second["reused_count"] == 2
        assert second["regenerated_count"] == 0

        checkpoint_data = json.loads(Path(second["checkpoint"]).read_text(encoding="utf-8"))
        damaged = Path(checkpoint_data["cuts"][1]["path"])
        damaged.write_bytes(b"broken")
        inspection = inspect_cut_checkpoint(root / "out", 2)
        assert inspection["damaged"] == [2]

        repaired = export_project_with_checkpoint(project, root / "out")
        assert repaired["reused_count"] == 1
        assert repaired["regenerated_count"] == 1
        assert repaired["inspection"]["complete"] is True


test_checkpoint_reuse_and_repair()


def test_v55_preference_safety():
    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as temp:
        root = Path(temp)
        profile_path = root / "profile.json"
        snapshot_dir = root / "snapshots"

        project = Project(
            fields={"product":"테스트 양파","category":"농산물","shipping":"한진택배"},
            images=[],
            cuts=[
                Cut("산지직송","신선하게 보내드립니다.",0,approved=True,review_status="승인"),
                Cut("꼼꼼한 선별","좋은 상품만 선별합니다.",0,approved=True,review_status="승인"),
            ],
            style="감성",
            layout="균형형",
        )
        sample = enrich_preference_sample(build_preference_sample(project,"테스트"))
        assert sample["sample_quality"]["usable"] is True

        profile = rebuild_preference_profile([sample], profile_path)
        assert profile["health"]["usable_count"] == 1
        assert "농산물" in profile["category_summaries"]

        snapshot = create_preference_snapshot(profile, snapshot_dir, "테스트백업")
        assert snapshot.exists()
        snapshots = list_preference_snapshots(snapshot_dir)
        assert len(snapshots) == 1

        project2 = Project(
            fields={"product":"테스트 김","category":"수산가공식품"},
            images=[],
            cuts=[Cut("바삭한 김","맛있게 즐기세요.",0)],
            style="홈쇼핑",
            layout="사진 크게",
        )
        sample2 = enrich_preference_sample(build_preference_sample(project2,"김"))
        profile2 = rebuild_preference_profile([sample, sample2], profile_path)
        assert profile2["health"]["sample_count"] == 2

        result = remove_latest_preference_sample(profile_path)
        assert result["removed"] is True
        assert result["profile"]["health"]["sample_count"] == 1

        restored = restore_preference_snapshot(snapshot, profile_path)
        assert restored["restored"] is True
        restored_profile = load_preference_profile(profile_path)
        assert len(restored_profile["samples"]) == 1

        recommendation = recommend_category_preference(project, restored_profile)
        assert recommendation["available"] is True
        comparison = preference_profile_comparison(project, restored_profile)
        assert comparison["category"] == "농산물"


test_v55_preference_safety()


def test_v57_workspace_and_recovery():
    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as temp:
        root=Path(temp)
        config_path=root/"workspace.json"
        history_path=root/"history.json"
        session_path=root/"session.json"
        autosave_dir=root/"autosave"

        config=WorkspaceConfig(
            workspace_root=str(root/"work"),
            default_shipping="한진택배",
            default_style="감성",
            default_layout="균형형",
            default_cut_count=8,
        )
        save_workspace_config(config,config_path)
        loaded=load_workspace_config(config_path)
        assert loaded.default_shipping=="한진택배"
        paths=ensure_workspace_folders(loaded)
        assert Path(paths["projects"]).exists()
        assert Path(paths["outputs"]).exists()

        project=create_workspace_project("테스트 상품","농산물",loaded)
        assert project.fields["shipping"]=="한진택배"
        assert project.style=="감성"

        blank=Project(fields={},images=[],cuts=[])
        apply_workspace_defaults(blank,loaded)
        assert blank.fields["shipping"]=="한진택배"

        save_startup_history("테스트",{"value":1},history_path)
        assert load_startup_history(history_path)[0]["event"]=="테스트"

        save_session_state(project,0,True,session_path)
        session=load_session_state(session_path)
        candidate=_candidate_from_project(
            session["project_object"],"세션",str(session_path),
            session.get("saved_at",""),True,0,
        )
        best=select_best_recovery_candidate([candidate])
        assert best["product"]=="테스트 상품"
        assert best["dirty"] is True

        autosave_dir.mkdir()
        autosave_path=create_autosave_snapshot(project,autosave_dir,keep=3)
        assert autosave_path.exists()

        archive_dir=root/"archive"
        archived=archive_recovery_state(session_path,archive_dir)
        assert archived and archived.exists()

        report=export_startup_dashboard_report(root/"startup_report.json",loaded)
        assert report.exists()


test_v57_workspace_and_recovery()


def test_v58_project_template_library():
    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as temp:
        root=Path(temp)
        custom_path=root/"templates.json"

        templates=list_project_templates(True,False,custom_path)
        assert len(templates)>=6
        assert all(validate_project_template(item)["valid"] for item in templates)

        agriculture=find_project_template("builtin_agriculture_origin_8",custom_path)
        assert agriculture is not None
        project=project_from_template(
            agriculture,
            product_name="초당옥수수",
            origin="전남 무안",
            shipping="한진택배",
        )
        assert len(project.cuts)==8
        assert project.fields["product"]=="초당옥수수"
        assert "초당옥수수" in project.cuts[0].body
        assert project.ai_analysis["template_id"]=="builtin_agriculture_origin_8"

        custom=create_template_from_project(
            project,
            "나만의 옥수수 템플릿",
            "산지직송 옥수수용",
        )
        stored=upsert_custom_project_template(custom,custom_path)
        assert len(stored)==1
        loaded=load_custom_project_templates(custom_path)
        assert loaded[0]["name"]=="나만의 옥수수 템플릿"

        recommendations=recommend_project_templates(
            "농산물",
            "초당옥수수",
            custom_path,
        )
        assert recommendations[0]["recommendation_score"]>=60

        pack=root/"template_pack.json"
        export_template_pack([custom],pack)
        assert pack.exists()

        other_path=root/"other_templates.json"
        imported=import_template_pack(pack,other_path)
        assert imported["imported_count"]==1
        assert len(load_custom_project_templates(other_path))==1

        summary=template_library_summary(custom_path)
        assert summary["custom_count"]==1
        assert summary["builtin_count"]>=6

        assert delete_custom_project_template(custom["template_id"],custom_path) is True
        assert load_custom_project_templates(custom_path)==[]


test_v58_project_template_library()


def test_v59_revision_and_final_approval():
    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as temp:
        root=Path(temp)
        history_path=root/"history.json"

        image_path=root/"source.png"
        Image.new("RGB",(1000,1000),"white").save(image_path)
        project=Project(
            fields={
                "product":"검수 테스트",
                "category":"식품",
                "origin":"국내산",
                "feature1":"좋은 품질",
                "feature2":"안전한 포장",
                "shipping":"한진택배",
            },
            images=[str(image_path)],
            cuts=[
                Cut(
                    "첫 번째 컷",
                    "처음 문구",
                    0,
                    approved=False,
                    review_status="검수 전",
                ),
                Cut(
                    "두 번째 컷",
                    "두 번째 문구",
                    0,
                    approved=False,
                    review_status="검수 전",
                ),
            ],
        )

        first=snapshot_cut_revision(
            project,
            0,
            history_path,
            reason="초안",
        )
        assert first["created"] is True
        assert first["revision_count"]==1

        same=snapshot_cut_revision(
            project,
            0,
            history_path,
            reason="변경 없음",
        )
        assert same["created"] is False

        project.cuts[0].body="수정 문구"
        second=snapshot_cut_revision(
            project,
            0,
            history_path,
            reason="문구 수정",
        )
        assert second["created"] is True
        assert second["revision_count"]==2

        revisions=list_cut_revisions(history_path,0)
        assert len(revisions)==2
        comparison=compare_cut_revisions(
            revisions[0],
            revisions[1],
        )
        assert comparison["different"] is True
        assert any(
            item["field"]=="body"
            for item in comparison["differences"]
        )

        restored=restore_cut_revision(
            project,
            0,
            1,
            history_path,
        )
        assert restored["restored"] is True
        assert project.cuts[0].body=="처음 문구"

        all_result=snapshot_all_cut_revisions(
            project,
            history_path,
            reason="전체 저장",
        )
        assert all_result["total"]==2

        summary=revision_history_summary(
            project,
            history_path,
        )
        assert summary["total_revisions"]>=3

        gate_before=final_approval_gate(project)
        assert gate_before["ready"] is False

        for cut in project.cuts:
            set_cut_review(
                cut,
                "승인",
                "검수 완료",
            )
        gate_after=final_approval_gate(project)
        assert gate_after["ready"] is True

        record=create_final_approval_record(
            project,
            "테스트 승인자",
            "최종 승인",
        )
        assert record["approver"]=="테스트 승인자"
        assert validate_final_approval_record(
            project,
            record,
        )["valid"] is True

        project.cuts[0].body="승인 후 변경"
        assert validate_final_approval_record(
            project,
            record,
        )["valid"] is False
        project.cuts[0].body="처음 문구"

        release=export_final_release_package(
            project,
            root/"release",
            "테스트 승인자",
            "최종 승인",
            history_path,
        )
        assert Path(release["zip"]).exists()
        assert Path(release["approval_record"]).exists()
        assert Path(release["review_report"]).exists()

        report=export_revision_report(
            project,
            history_path,
            root/"revision_report.json",
        )
        assert report.exists()


test_v59_revision_and_final_approval()


def test_v60_product_intelligence():
    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as temp:
        root=Path(temp)
        image1=root/"전남_초당옥수수_대표.png"
        image2=root/"초당옥수수_단면.png"
        image3=root/"초당옥수수_포장.png"
        Image.new("RGB",(1200,900),(235,205,80)).save(image1)
        Image.new("RGB",(1000,1000),(250,225,95)).save(image2)
        Image.new("RGB",(900,1200),(210,180,90)).save(image3)

        fields={
            "product":"초당옥수수",
            "category":"농산물",
            "origin":"전남 무안",
            "feature1":"높은 당도와 아삭한 식감",
            "feature2":"당일수확 후 산지직송",
            "shipping":"한진택배",
        }
        images=[str(image1),str(image2),str(image3)]

        titles=generate_product_title_set(fields,{},20)
        assert len(titles)>=15
        assert titles[0]["score"]>=titles[-1]["score"]

        keywords=generate_search_keyword_plan(fields,{})
        assert "초당옥수수" in keywords["primary_keywords"]

        psychology=analyze_customer_purchase_psychology(fields)
        assert len(psychology["customer_questions"])>=4
        assert "중량·용량 정보" in psychology["missing_answers"]

        variants=generate_copy_style_variants(fields)
        assert len(variants)==6
        assert "홈쇼핑형" in variants

        plan=build_intelligent_page_plan(fields,psychology,8)
        assert len(plan)==8
        assert plan[0]["cut_number"]==1

        score=product_intelligence_score(fields,images,plan)
        assert 0<=score["score"]<=100

        intelligence=build_product_intelligence(images,fields,8)
        assert intelligence["engine_version"]=="6.0"
        assert len(intelligence["product_titles"])>=15
        assert len(intelligence["page_plan"])==8

        project=project_from_product_intelligence(
            intelligence,
            images,
            "프리미엄형",
        )
        assert len(project.cuts)==8
        assert project.fields["optimized_product_name"]
        assert project.ai_analysis["selected_copy_style"]=="프리미엄형"

        report=export_product_intelligence_report(
            intelligence,
            root/"v60_report.json",
        )
        assert report.exists()


test_v60_product_intelligence()


def test_v61_design_quality_engine():
    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as temp:
        root=Path(temp)
        image_path=root/"product.png"
        Image.new("RGB",(1200,1000),(220,180,90)).save(image_path)

        project=Project(
            fields={
                "product":"디자인 테스트 상품",
                "category":"농산물",
                "origin":"전남",
                "feature1":"신선한 품질",
                "feature2":"꼼꼼한 선별",
                "shipping":"한진택배",
            },
            images=[str(image_path)],
            cuts=[
                Cut("짧", "짧음", 0, title_size=16, body_size=60, image_scale=2.2, story_stage="상품 소개"),
                Cut("핵심 장점을 확인하세요", "좋은 품질과 꼼꼼한 선별을 안내합니다.", 0, story_stage="핵심 장점"),
                Cut("산지 안내", "전남에서 준비했습니다.", 0, story_stage="산지·원산지"),
                Cut("품질 근거", "실제 상품 사진으로 상태를 확인하세요.", 0, story_stage="품질 근거"),
                Cut("활용 제안", "다양한 요리에 활용하세요.", 0, story_stage="활용 제안"),
                Cut("상품 구성", "옵션과 구성을 확인하세요.", 0, story_stage="상품 구성"),
                Cut("포장 배송", "꼼꼼하게 포장합니다.", 0, story_stage="포장·배송"),
                Cut("주문 안내", "주문 전 정보를 확인하세요.", 0, story_stage="구매 안내"),
            ],
            style="심플",
            layout="균형형",
        )

        assert estimate_text_lines("가나다라마바사",3)>=3
        diagnostic=cut_design_diagnostics(project.cuts[0],0,8)
        assert diagnostic["score"]<70
        assert diagnostic["issues"]

        before=project_design_quality(project)
        assert 0<=before["score"]<=100
        settings=recommend_cut_design_settings(project.cuts[0],0,8)
        assert settings["layout_variant"]=="풀블리드형"

        copied=copy.deepcopy(project.cuts[0])
        changes=apply_cut_design_settings(copied,settings)
        assert changes
        assert copied.layout_variant=="풀블리드형"

        optimized=auto_optimize_project_design(project)
        assert optimized["changed_cut_count"]>=1
        assert optimized["after"]["score"]>=optimized["before"]["score"]
        assert project.style=="감성"
        assert project.custom_background=="#F1E8DB"

        sheet=build_design_contact_sheet(
            project,
            root/"contact_sheet.png",
        )
        assert sheet.exists()
        with Image.open(sheet) as image:
            assert image.width==900

        report=export_design_quality_report(
            project,
            root/"design_report.json",
        )
        assert report.exists()


test_v61_design_quality_engine()


def test_v62_thumbnail_engine():
    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as temp:
        root=Path(temp)
        image1=root/"옥수수_대표.png"
        image2=root/"옥수수_포장.png"
        Image.new("RGB",(1400,1100),(235,205,75)).save(image1)
        Image.new("RGB",(1000,1300),(210,180,80)).save(image2)

        project=Project(
            fields={
                "product":"초당옥수수",
                "category":"농산물",
                "origin":"전남 무안",
                "feature1":"높은 당도와 아삭한 식감",
                "feature2":"당일수확 산지직송",
                "shipping":"한진택배",
            },
            images=[str(image1),str(image2)],
            cuts=[],
            style="감성",
            layout="균형형",
            ai_analysis={},
        )

        candidates=thumbnail_text_candidates(project)
        assert len(candidates)>=4
        selected=select_thumbnail_source_image(project)
        assert Path(selected["path"]).exists()

        thumb=render_thumbnail_variant(
            project,
            "상품집중형",
            "초당옥수수",
            "높은 당도와 아삭한 식감",
            "스마트스토어",
        )
        assert thumb.size==(1000,1000)

        quality=thumbnail_quality_score(
            "초당옥수수",
            "높은 당도와 아삭한 식감",
            "상품집중형",
            "스마트스토어",
        )
        assert 0<=quality["score"]<=100

        result=generate_thumbnail_set(
            project,
            root/"thumbnails",
            "스마트스토어",
        )
        assert len(result["outputs"])==3
        assert all(Path(item["path"]).exists() for item in result["outputs"])
        assert result["original_source_unchanged"] is True
        assert image1.exists()

        sheet=build_thumbnail_contact_sheet(
            result,
            root/"comparison.png",
        )
        assert sheet.exists()
        with Image.open(sheet) as image:
            assert image.width==1080


test_v62_thumbnail_engine()


def test_v63_ad_banner_engine():
    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as temp:
        root=Path(temp)
        image_path=root/"product.png"
        Image.new("RGB",(1400,1100),(225,190,75)).save(image_path)

        project=Project(
            fields={
                "product":"초당옥수수",
                "category":"농산물",
                "origin":"전남 무안",
                "feature1":"높은 당도와 아삭한 식감",
                "feature2":"당일수확 산지직송",
                "shipping":"한진택배",
            },
            images=[str(image_path)],
            cuts=[],
            style="감성",
            layout="균형형",
            ai_analysis={},
        )

        copy_data=generate_ad_copy(project,"신상품")
        assert "초당옥수수" in copy_data["headline"]

        quality=ad_banner_quality_score(
            copy_data["headline"],
            copy_data["subcopy"],
            "스마트스토어 가로배너",
        )
        assert 0<=quality["score"]<=100

        banner=render_ad_banner(
            project,
            "스마트스토어 가로배너",
            "신상품",
        )
        assert banner.size==(1200,400)

        result=generate_ad_banner_set(
            project,
            root/"ads",
            "인스타그램 정사각형",
        )
        assert len(result["outputs"])==4
        assert all(Path(item["path"]).exists() for item in result["outputs"])
        assert result["original_source_unchanged"] is True
        assert image_path.exists()

        sheet=build_ad_banner_contact_sheet(
            result,
            root/"ad_comparison.png",
        )
        assert sheet.exists()
        with Image.open(sheet) as image:
            assert image.width==420


test_v63_ad_banner_engine()
