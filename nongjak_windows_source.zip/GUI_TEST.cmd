@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Nongjak AI GUI Test
set "PY_CMD="
py -3 -c "import sys; assert sys.version_info >= (3,10)" >nul 2>&1
if not errorlevel 1 set "PY_CMD=py -3"
if not defined PY_CMD (
  python -c "import sys; assert sys.version_info >= (3,10)" >nul 2>&1
  if not errorlevel 1 set "PY_CMD=python"
)
if not defined PY_CMD (
  echo Python not found.
  pause
  exit /b 1
)
%PY_CMD% -c "import tkinter as tk; from tkinter import messagebox; r=tk.Tk(); r.withdraw(); messagebox.showinfo('Nongjak AI GUI Test','GUI test succeeded.'); r.destroy()"
if errorlevel 1 pause
