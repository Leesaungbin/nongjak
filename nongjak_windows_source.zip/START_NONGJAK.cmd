@echo off
cd /d "%~dp0"
call "%~dp0ONE_CLICK_START.cmd"
