﻿@echo off
cd /d "%~dp0"
call "SETUP_FIRST.cmd"
