from __future__ import annotations

import sys
import traceback
from datetime import datetime
from pathlib import Path


def write_startup_error(error: BaseException) -> Path:
    log_dir = Path(__file__).resolve().parent / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    path = log_dir / "startup_error.log"
    with path.open("a", encoding="utf-8") as file:
        file.write("\n" + "=" * 70 + "\n")
        file.write(datetime.now().isoformat(timespec="seconds") + "\n")
        file.write(f"Python: {sys.version}\n")
        file.write("".join(traceback.format_exception(type(error), error, error.__traceback__)))
    return path


def main() -> int:
    try:
        import tkinter as tk
        from tkinter import messagebox
        from nongjak.ui import App

        root = tk.Tk()
        App(root)
        root.mainloop()
        return 0
    except Exception as error:
        log_path = write_startup_error(error)
        try:
            import tkinter as tk
            from tkinter import messagebox

            hidden = tk.Tk()
            hidden.withdraw()
            messagebox.showerror(
                "농작 AI 실행 오류",
                "프로그램 실행 중 오류가 발생했습니다.\n\n"
                f"오류: {error}\n\n"
                f"오류 기록: {log_path}\n\n"
                "ONE_CLICK_START.cmd으로 다시 실행해 주세요.",
            )
            hidden.destroy()
        except Exception:
            print("농작 AI 실행 오류:", error)
            print("오류 기록:", log_path)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
