@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Build Nongjak AI EXE

set "PY_CMD="
py -3 -c "import sys; assert sys.version_info >= (3,10)" >nul 2>&1
if not errorlevel 1 set "PY_CMD=py -3"
if not defined PY_CMD (
  python -c "import sys; assert sys.version_info >= (3,10)" >nul 2>&1
  if not errorlevel 1 set "PY_CMD=python"
)
if not defined PY_CMD (
  echo Python not found.
  pause
  exit /b 1
)

%PY_CMD% -m pip install --user pyinstaller
if errorlevel 1 goto :fail

%PY_CMD% -m PyInstaller --noconfirm --clean --windowed --onedir --name NongjakAI app.py
if errorlevel 1 goto :fail

echo.
echo EXE BUILD COMPLETED.
echo Open dist\NongjakAI\NongjakAI.exe
pause
exit /b 0

:fail
echo EXE BUILD FAILED.
pause
exit /b 1
