@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Nongjak AI v6.3.1

set "PY_CMD="
py -3 -c "import sys; assert sys.version_info >= (3,10)" >nul 2>&1
if not errorlevel 1 set "PY_CMD=py -3"

if not defined PY_CMD (
  python -c "import sys; assert sys.version_info >= (3,10)" >nul 2>&1
  if not errorlevel 1 set "PY_CMD=python"
)

if not defined PY_CMD (
  echo ERROR: Python 3.10 or newer was not found.
  echo Install Python from python.org and enable Add Python to PATH.
  echo.
  start "" "https://www.python.org/downloads/windows/"
  pause
  exit /b 1
)

%PY_CMD% "%~dp0one_click_start.py"
set "EXIT_CODE=%ERRORLEVEL%"
if not "%EXIT_CODE%"=="0" (
  echo.
  echo Nongjak AI could not start. Error code: %EXIT_CODE%
  echo Opening the startup log now.
  if exist "%~dp0logs\startup_error.log" start "" notepad "%~dp0logs\startup_error.log"
  pause
)
exit /b %EXIT_CODE%
