@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Nongjak AI Optional Setup

echo This setup is optional.
echo ONE_CLICK_START.cmd installs Pillow automatically when needed.
echo.
call "%~dp0ONE_CLICK_START.cmd"
exit /b %ERRORLEVEL%
